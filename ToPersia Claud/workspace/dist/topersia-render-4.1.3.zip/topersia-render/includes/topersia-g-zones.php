<?php
/**
 * ToPersia — نواحی نمایش دستهٔ G
 *
 * پانزده شورت‌کد که محتوای هر ناحیهٔ صفحهٔ موجودیت جغرافیایی را می‌سازند.
 *
 * ── مرز معماری ────────────────────────────────────────────────────────
 * المنتور اسکلت چیدمان می‌سازد. این فایل محتوای هر ناحیه را تولید می‌کند.
 * المنتور نباید ۵۷ متا و ۳۴ رابطه را بشناسد؛ اگر بشناسد، هر تغییر داده
 * یعنی ویرایش دستی قالب و شکستن قاعدهٔ تک‌تولیدکنندهٔ P5-D145 — چون همان
 * داده باید در JSON-LD هم برود.
 *
 * ── قواعد ثابت ────────────────────────────────────────────────────────
 * هر بخش بدون داده کامل ناپدید می‌شود؛ سرفصل خالی نمی‌ماند.
 * عدد با رقم فارسی و جداکنندهٔ ٬ · سال بدون جداکننده · لاتین مونو و LTR.
 * هیچ رنگ ثابتی اینجا نوشته نمی‌شود؛ رنگ از توکن‌های --tp-* می‌آید.
 * letter-spacing روی متن فارسی ممنوع است.
 * دادهٔ زنده — هوا و وضعیت ذخیره — در HTML کش‌شده نمی‌آید.
 *
 * @package topersia-render
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* =========================================================================
   ۱ — ابزارهای پایه
   ========================================================================= */

/** شناسهٔ پست جاری، با احترام به حلقهٔ المنتور و JetEngine. */
if ( ! function_exists( 'topersia_g_pid' ) ) {
	function topersia_g_pid( $atts = array() ) {

		if ( ! empty( $atts['id'] ) ) {
			return absint( $atts['id'] );
		}

		if ( function_exists( 'get_the_ID' ) ) {
			$id = get_the_ID();

			if ( $id ) {
				return absint( $id );
			}
		}

		return 0;
	}
}

/** رقم لاتین به رقم فارسی. */
if ( ! function_exists( 'topersia_g_fa' ) ) {
	function topersia_g_fa( $text ) {

		$latin   = array( '0', '1', '2', '3', '4', '5', '6', '7', '8', '9' );
		$persian = array( '۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹' );

		return str_replace( $latin, $persian, (string) $text );
	}
}

/**
 * جداکنندهٔ هزارگان با U+066C.
 *
 * فقط روی بخش صحیح اعمال می‌شود؛ بخش اعشاری دست‌نخورده می‌ماند.
 */
if ( ! function_exists( 'topersia_g_sep' ) ) {
	function topersia_g_sep( $number ) {

		$raw = trim( (string) $number );

		if ( '' === $raw ) {
			return '';
		}

		$sign = '';

		if ( '-' === substr( $raw, 0, 1 ) ) {
			$sign = '-';
			$raw  = substr( $raw, 1 );
		}

		$parts    = explode( '.', $raw, 2 );
		$integer  = preg_replace( '/[^0-9]/', '', $parts[0] );
		$fraction = isset( $parts[1] ) ? preg_replace( '/[^0-9]/', '', $parts[1] ) : '';

		if ( '' === $integer ) {
			return (string) $number;
		}

		$grouped = '';
		$length  = strlen( $integer );

		for ( $i = 0; $i < $length; $i++ ) {

			if ( $i > 0 && 0 === ( ( $length - $i ) % 3 ) ) {
				$grouped .= '٬';
			}

			$grouped .= $integer[ $i ];
		}

		return $sign . $grouped . ( '' !== $fraction ? '.' . $fraction : '' );
	}
}

/**
 * آیا این مقدار «پر» است؟
 *
 * قطبیت عمدی: هر چیزی جز خالی و «نادرست صریح»، پر است. شکست باید به سمت
 * نمایش باشد نه ناپدیدشدن — همان قاعده‌ای که topersia_active_rows دارد.
 */
if ( ! function_exists( 'topersia_g_filled' ) ) {
	function topersia_g_filled( $value ) {

		if ( is_array( $value ) ) {
			return ! empty( $value );
		}

		$value = trim( (string) $value );

		if ( '' === $value ) {
			return false;
		}

		return ! in_array( $value, array( '0', 'false', 'no', 'off' ), true );
	}
}

/** آیا این سوییچر روشن است؟ */
if ( ! function_exists( 'topersia_g_flag_on' ) ) {
	function topersia_g_flag_on( $value ) {

		if ( is_bool( $value ) ) {
			return $value;
		}

		$value = strtolower( trim( (string) $value ) );

		return in_array( $value, array( '1', 'true', 'yes', 'on' ), true );
	}
}

/** متای خام — بدون پاک‌سازی، چون ریپیتر و گالری آرایه‌اند. */
if ( ! function_exists( 'topersia_g_raw' ) ) {
	function topersia_g_raw( $post_id, $key ) {

		if ( ! $post_id || ! function_exists( 'get_post_meta' ) ) {
			return '';
		}

		return get_post_meta( $post_id, $key, true );
	}
}

/** متن ساده و امن. */
if ( ! function_exists( 'topersia_g_text' ) ) {
	function topersia_g_text( $post_id, $key ) {

		$value = topersia_g_raw( $post_id, $key );

		if ( is_array( $value ) || is_object( $value ) ) {
			return '';
		}

		return trim( wp_strip_all_tags( (string) $value ) );
	}
}

/**
 * مقدار یک فیلد، آمادهٔ نمایش، بر پایهٔ «نوع» نه نوع پست.
 *
 * @param string $name نام فیلد.
 * @param mixed  $raw  مقدار خام.
 * @return string HTML
 */
if ( ! function_exists( 'topersia_g_value' ) ) {
	function topersia_g_value( $name, $raw ) {

		$map   = topersia_g_map();
		$field = isset( $map[ $name ] ) ? $map[ $name ] : array( 'kind' => 'text', 'unit' => '' );
		$kind  = isset( $field['kind'] ) ? $field['kind'] : 'text';
		$unit  = isset( $field['unit'] ) ? $field['unit'] : '';

		if ( is_array( $raw ) ) {
			$raw = implode( '، ', array_filter( array_map( 'strval', $raw ) ) );
		}

		$raw = trim( (string) $raw );

		if ( '' === $raw ) {
			return '';
		}

		switch ( $kind ) {

			case 'number':
				$out = topersia_g_fa( topersia_g_sep( $raw ) );

				if ( '' !== $unit ) {
					$out .= ' <i class="tp-u">' . esc_html( $unit ) . '</i>';
				}

				return $out;

			case 'year':
				return topersia_g_fa( preg_replace( '/[^0-9۰-۹]/u', '', $raw ) );

			case 'latin':
				return '<span class="tp-lat" dir="ltr">' . esc_html( $raw ) . '</span>';

			case 'choice':
				$glossary = isset( $field['glossary'] ) ? $field['glossary'] : '';

				return esc_html( topersia_g_glossary_label( $glossary, $raw ) );

			case 'flag':
				return esc_html( isset( $field['label'] ) ? $field['label'] : $raw );
		}

		return esc_html( $raw );
	}
}

/**
 * پوستهٔ یک بخش. بدنهٔ خالی یعنی هیچ خروجی — نه سرفصل خالی.
 */
if ( ! function_exists( 'topersia_g_section' ) ) {
	function topersia_g_section( $id, $title, $kicker, $body, $class = 'tp-rail-card' ) {

		$body = trim( (string) $body );

		if ( '' === $body ) {
			return '';
		}

		$head = '';

		if ( '' !== (string) $title ) {

			$head = '<div class="tp-rail-card__head">'
				. '<h3 id="' . esc_attr( $id ) . 'Title">' . esc_html( $title ) . '</h3>'
				. ( '' !== (string) $kicker ? '<span class="tp-k">' . esc_html( $kicker ) . '</span>' : '' )
				. '</div>';
		}

		return '<section id="' . esc_attr( $id ) . '" class="' . esc_attr( $class ) . '"'
			. ( '' !== (string) $title ? ' aria-labelledby="' . esc_attr( $id ) . 'Title"' : '' )
			. '>' . $head . '<div class="tp-rail-card__body">' . $body . '</div></section>';
	}
}

/** فیلدهای یک ناحیه که این پست واقعاً دارد، به ترتیب نقشه. */
if ( ! function_exists( 'topersia_g_zone_fields' ) ) {
	function topersia_g_zone_fields( $post_id, $zone, $exclude = array() ) {

		$out = array();

		foreach ( topersia_g_map() as $name => $field ) {

			if ( ! isset( $field['zone'] ) || $field['zone'] !== $zone ) {
				continue;
			}

			if ( in_array( $name, $exclude, true ) ) {
				continue;
			}

			$raw = topersia_g_raw( $post_id, $name );

			if ( ! topersia_g_filled( $raw ) ) {
				continue;
			}

			$out[ $name ] = $raw;
		}

		return $out;
	}
}

/* =========================================================================
   ۲ — روابط
   ========================================================================= */

/** پیکربندی یک گروه رابطه برای این نوع پست. */
if ( ! function_exists( 'topersia_g_group' ) ) {
	function topersia_g_group( $post_id, $key ) {

		$type = function_exists( 'get_post_type' ) ? get_post_type( $post_id ) : '';
		$map  = topersia_g_relmap();

		if ( ! $type || ! isset( $map[ $type ][ $key ] ) ) {
			return array();
		}

		return $map[ $type ][ $key ];
	}
}

/**
 * نشانیِ عمومی — یا رشتهٔ خالی اگر آن نوع صفحه ندارد.
 *
 * شهرستان موجودیتِ زیرساخت است: قالب و صفحه ندارد (`P5-D172`). پیوند به
 * آن یعنی ۴۰۴ برای کاربر و پیوندِ شکسته برای خزنده. هر جا نشانی خالی
 * برگردد، کارت `<article>` می‌شود نه `<a>`.
 *
 * مبنا خودِ نقشهٔ رابطه است، نه فهرست جدا: نوعی که در `topersia_g_relmap()`
 * مدخل دارد، صفحه دارد. یک منبع حقیقت.  P5-D210
 */
if ( ! function_exists( 'topersia_g_public_url' ) ) {
	function topersia_g_public_url( $post_id ) {

		$type = function_exists( 'get_post_type' ) ? get_post_type( $post_id ) : '';
		$map  = topersia_g_relmap();

		if ( '' === $type || ! isset( $map[ $type ] ) ) {
			return '';
		}

		return (string) get_permalink( $post_id );
	}
}

if ( ! function_exists( 'topersia_g_sort_entities' ) ) {
	/**
	 * ترتیب کارت‌های موجودیتِ ماندگار — یک قاعده برای همه.  P5-D211
	 *
	 *   ۱ `display_priority` نزولی
	 *   ۲ جانشین نوع — شهر و روستا: `population` نزولی
	 *   ۳ الفبای فارسی
	 *
	 * `display_priority` هنوز فیلد نیست. این‌جا **ساخته نمی‌شود**: متا
	 * خوانده می‌شود و نبودش صفر حساب می‌شود. روزی که در JetEngine ساخته
	 * شود، بی‌هیچ تغییری در کد اثر می‌گذارد.
	 *
	 * الفبا با `Collator` فارسی است، نه `strcmp`: «آ» و «ا» و «ء» در
	 * بایت‌ها فاصله دارند ولی در الفبا کنار هم‌اند. اگر `intl` نبود،
	 * `strcoll` جای آن می‌نشیند — بدتر از Collator، بهتر از بایت.
	 */
	function topersia_g_sort_entities( $ids ) {

		$ids = array_values( array_unique( array_map( 'absint', (array) $ids ) ) );

		if ( count( $ids ) < 2 ) {
			return $ids;
		}

		$rank = array();

		foreach ( $ids as $one ) {

			$view = topersia_g_view_id( $one );

			$rank[ $one ] = array(
				'priority' => (float) topersia_g_raw( $view, 'display_priority' ),
				'fallback' => (float) topersia_g_raw( $view, 'population' ),
				'name'     => (string) topersia_g_name( $view ),
			);
		}

		$collator = class_exists( 'Collator' ) ? new Collator( 'fa' ) : null;

		usort( $ids, function ( $a, $b ) use ( $rank, $collator ) {

			if ( $rank[ $a ]['priority'] !== $rank[ $b ]['priority'] ) {
				return $rank[ $a ]['priority'] < $rank[ $b ]['priority'] ? 1 : -1;
			}

			if ( $rank[ $a ]['fallback'] !== $rank[ $b ]['fallback'] ) {
				return $rank[ $a ]['fallback'] < $rank[ $b ]['fallback'] ? 1 : -1;
			}

			return $collator
				? (int) $collator->compare( $rank[ $a ]['name'], $rank[ $b ]['name'] )
				: strcoll( $rank[ $a ]['name'], $rank[ $b ]['name'] );
		} );

		return $ids;
	}
}

if ( ! function_exists( 'topersia_g_chain_ids' ) ) {
	/**
	 * زنجیرهٔ رابطه — چند پله پشت سر هم.  P5-D210
	 *
	 * استان شهر ندارد؛ شهرستان دارد. ولی شهرستان موجودیتِ زیرساخت است و
	 * صفحه ندارد (`P5-D172`)، پس آنچه روی صفحهٔ استان باید بیاید شهرهای
	 * آن است: ۷۲ (استان→شهرستان) و بعد ۷۳ (شهرستان→شهر).
	 *
	 * هر پله روی **همهٔ** نتیجه‌های پلهٔ قبل اجرا می‌شود و تکراری‌ها یک‌بار
	 * می‌مانند — دو شهرستان می‌توانند به یک شهر وصل باشند.
	 *
	 * @param array $chain فهرست مرتبِ spec ها.
	 * @return array شناسه‌ها.
	 */
	function topersia_g_chain_ids( $post_id, $chain ) {

		if ( ! is_array( $chain ) || ! $chain ) {
			return array();
		}

		$cur = array( absint( $post_id ) );

		foreach ( $chain as $spec ) {

			$next = array();

			foreach ( $cur as $one ) {
				foreach ( topersia_g_rel_ids( $one, array( $spec ) ) as $found ) {
					$next[ $found ] = $found;
				}
			}

			$cur = array_values( $next );

			if ( ! $cur ) {
				return array();
			}
		}

		return $cur;
	}
}

/**
 * شناسه‌های طرف مقابل یک یا چند رابطه.
 *
 * جهت از export گرفته می‌شود، نه از سند روابط.  P5-D170
 */
if ( ! function_exists( 'topersia_g_rel_ids' ) ) {
	function topersia_g_rel_ids( $post_id, $rels ) {

		$ids = array();

		if ( ! is_array( $rels ) || ! function_exists( 'topersia_relation' ) ) {
			return $ids;
		}

		foreach ( $rels as $spec ) {

			$id  = isset( $spec['id'] ) ? absint( $spec['id'] ) : 0;
			$dir = isset( $spec['dir'] ) ? $spec['dir'] : 'children';

			if ( ! $id ) {
				continue;
			}

			$relation = topersia_relation( $id );

			if ( ! $relation ) {
				continue;
			}

			$found = ( 'parents' === $dir )
				? $relation->get_parents( $post_id, 'ids' )
				: $relation->get_children( $post_id, 'ids' );

			if ( empty( $found ) || ! is_array( $found ) ) {
				continue;
			}

			foreach ( $found as $one ) {

				$one = absint( $one );

				if ( $one ) {
					$ids[ $one ] = $one;
				}
			}
		}

		return array_values( $ids );
	}
}

/** شناسه را به نسخهٔ زبان جاری می‌برد. */
if ( ! function_exists( 'topersia_g_view_id' ) ) {
	function topersia_g_view_id( $post_id ) {

		if ( ! function_exists( 'apply_filters' ) ) {
			return $post_id;
		}

		$type = function_exists( 'get_post_type' ) ? get_post_type( $post_id ) : '';

		if ( ! $type ) {
			return $post_id;
		}

		$view = apply_filters( 'wpml_object_id', $post_id, $type, true );

		return $view ? absint( $view ) : absint( $post_id );
	}
}

/** نام نمایشی یک موجودیت. */
if ( ! function_exists( 'topersia_g_name' ) ) {
	function topersia_g_name( $post_id ) {

		foreach ( array( 'official_name_fa', 'name_fa' ) as $key ) {

			$value = topersia_g_text( $post_id, $key );

			if ( '' !== $value ) {
				return $value;
			}
		}

		return function_exists( 'get_the_title' ) ? (string) get_the_title( $post_id ) : '';
	}
}

/** برچسب نوع موجودیت — «کوه»، «تالاب» — از برچسب مفرد نوع پست. */
if ( ! function_exists( 'topersia_g_kind_label' ) ) {
	function topersia_g_kind_label( $post_id ) {

		$type = function_exists( 'get_post_type' ) ? get_post_type( $post_id ) : '';

		if ( ! $type || ! function_exists( 'get_post_type_object' ) ) {
			return '';
		}

		$object = get_post_type_object( $type );

		if ( ! $object || empty( $object->labels->singular_name ) ) {
			return '';
		}

		return (string) $object->labels->singular_name;
	}
}

/* =========================================================================
   ۳ — تاریخ شمسی
   ========================================================================= */

/**
 * میلادی به شمسی.
 *
 * چرا الگوریتم و نه intl: افزونهٔ intl روی این میزبان تضمین‌شده نیست و
 * وابستگی‌ای که ممکن است نباشد، یعنی تاریخ ناپدید یا خطای مرگبار.
 */
if ( ! function_exists( 'topersia_g_jalali' ) ) {
	function topersia_g_jalali( $gy, $gm, $gd ) {

		$g_days = array( 0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334 );

		$gy2 = ( $gm > 2 ) ? ( $gy + 1 ) : $gy;

		$days = 355666 + ( 365 * $gy ) + ( (int) ( ( $gy2 + 3 ) / 4 ) )
			- ( (int) ( ( $gy2 + 99 ) / 100 ) ) + ( (int) ( ( $gy2 + 399 ) / 400 ) )
			+ $gd + $g_days[ $gm - 1 ];

		$jy   = -1595 + ( 33 * ( (int) ( $days / 12053 ) ) );
		$days %= 12053;

		$jy   += 4 * ( (int) ( $days / 1461 ) );
		$days %= 1461;

		if ( $days > 365 ) {
			$jy   += (int) ( ( $days - 1 ) / 365 );
			$days  = ( $days - 1 ) % 365;
		}

		if ( $days < 186 ) {
			$jm = 1 + (int) ( $days / 31 );
			$jd = 1 + ( $days % 31 );
		} else {
			$jm = 7 + (int) ( ( $days - 186 ) / 30 );
			$jd = 1 + ( ( $days - 186 ) % 30 );
		}

		return array( $jy, $jm, $jd );
	}
}

/** تاریخ فیلد date جت‌انجین — چه timestamp باشد چه Y-m-d — به متن شمسی. */
if ( ! function_exists( 'topersia_g_date_fa' ) ) {
	function topersia_g_date_fa( $value ) {

		$value = trim( (string) $value );

		if ( '' === $value ) {
			return '';
		}

		if ( preg_match( '/^\d{4}-\d{2}-\d{2}/', $value ) ) {
			$gy = (int) substr( $value, 0, 4 );
			$gm = (int) substr( $value, 5, 2 );
			$gd = (int) substr( $value, 8, 2 );
		} elseif ( preg_match( '/^\d{9,11}$/', $value ) ) {
			$gy = (int) gmdate( 'Y', (int) $value );
			$gm = (int) gmdate( 'n', (int) $value );
			$gd = (int) gmdate( 'j', (int) $value );
		} else {
			return '';
		}

		if ( $gm < 1 || $gm > 12 || $gd < 1 || $gd > 31 ) {
			return '';
		}

		$months = array(
			'فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور',
			'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند',
		);

		list( $jy, $jm, $jd ) = topersia_g_jalali( $gy, $gm, $gd );

		return topersia_g_fa( $jd ) . ' ' . $months[ $jm - 1 ] . ' ' . topersia_g_fa( $jy );
	}
}

/* =========================================================================
   ۴ — شورت‌کدهای ناحیه
   ========================================================================= */

/** [tp_hero] — تصویر، نام سه‌زبانه، نام محلی، خلاصه. */
if ( ! function_exists( 'topersia_g_sc_hero' ) ) {
	function topersia_g_sc_hero( $atts = array() ) {

		$pid = topersia_g_pid( $atts );

		if ( ! $pid ) {
			return '';
		}

		$fa = topersia_g_name( $pid );
		$en = topersia_g_text( $pid, 'official_name_en' );
		$ar = topersia_g_text( $pid, 'official_name_ar' );

		if ( '' === $en ) {
			$en = topersia_g_text( $pid, 'name_en' );
		}

		if ( '' === $ar ) {
			$ar = topersia_g_text( $pid, 'name_ar' );
		}

		$local = topersia_g_text( $pid, 'name_local' );
		$alt   = topersia_g_text( $pid, 'alternative_names' );
		$lead  = topersia_g_text( $pid, 'short_summary' );
		$kind  = topersia_g_kind_label( $pid );

		$image = '';
		$hero  = topersia_g_raw( $pid, 'hero_image' );

		if ( topersia_g_filled( $hero ) && function_exists( 'wp_get_attachment_image' ) ) {

			$image = wp_get_attachment_image(
				is_array( $hero ) ? absint( reset( $hero ) ) : absint( $hero ),
				'full',
				false,
				array(
					'class'         => 'tp-hero__img',
					'loading'       => 'eager',
					'fetchpriority' => 'high',
				)
			);
		}

		$names = array();

		if ( '' !== $en ) {
			$names[] = '<span lang="en" dir="ltr">' . esc_html( $en ) . '</span>';
		}

		if ( '' !== $ar ) {
			$names[] = '<em lang="ar">' . esc_html( $ar ) . '</em>';
		}

		$others = array_filter( array( $local, $alt ) );

		$out = '<header class="tp-hero">'
			. '<div class="tp-hero__fallback" aria-hidden="true"></div>'
			. $image
			. '<div class="tp-hero__overlay" aria-hidden="true"></div>'
			. '<div class="tp-hero__in"><div class="tp-hero__copy">';

		if ( '' !== $kind ) {
			$out .= '<p class="tp-eyebrow">' . esc_html( $kind ) . '</p>';
		}

		$out .= '<h1>' . esc_html( $fa ) . '</h1>';

		if ( $names ) {
			$out .= '<p class="tp-hero__alt">' . implode( ' · ', $names ) . '</p>';
		}

		if ( $others ) {
			$out .= '<p class="tp-altnames">' . esc_html( implode( ' · ', $others ) ) . '</p>';
		}

		if ( '' !== $lead ) {
			$out .= '<p class="tp-hero__lead">' . esc_html( $lead ) . '</p>';
		}

		return $out . '</div></div></header>';
	}
}

/**
 * [tp_actionbar] — اشتراک · ذخیره · دنبال‌کردن · منبع ترجیحی گوگل.
 *
 * یک عنصر است، نه دو نسخه. جابه‌جایی میان ستون کناری و بالای مسیر راهنما
 * را matchMedia انجام می‌دهد. وضعیت «ذخیره‌شده» عمداً در HTML نمی‌آید چون
 * صفحه کش تمام‌صفحه می‌شود.
 */
if ( ! function_exists( 'topersia_g_sc_actionbar' ) ) {
	function topersia_g_sc_actionbar( $atts = array() ) {

		$pid = topersia_g_pid( $atts );

		if ( ! $pid ) {
			return '';
		}

		$uid = topersia_g_text( $pid, 'entity_uid' );

		return '<div class="tp-actionbar" data-tp-actionbar data-tp-entity="' . esc_attr( $uid ) . '">'
			. '<div class="tp-actions">'
			. '<button class="tp-act" type="button" data-tp-share>'
			. '<span>' . esc_html__( 'اشتراک', 'topersia' ) . '</span></button>'
			. '<button class="tp-act" type="button" data-tp-save aria-pressed="false">'
			. '<span>' . esc_html__( 'ذخیره', 'topersia' ) . '</span></button>'
			. '<button class="tp-act" type="button" data-tp-follow>'
			. '<span>' . esc_html__( 'دنبال‌کردن', 'topersia' ) . '</span></button>'
			. '</div>'
			. '<p class="tp-act__note" role="status" aria-live="polite"></p>'
			. topersia_g_gps_link()
			. '</div>';
	}
}

/**
 * منبع ترجیحی گوگل — پیوند، نه دکمه.  P5-D207
 *
 * مرجع بصری `<button>` داشت، ولی این کار یک **ناوبری** است نه کنشِ
 * درون‌صفحه‌ای: کاربر به تنظیمات گوگل می‌رود. با `<a>` کلیک میانی و
 * «باز کردن در برگهٔ تازه» و صفحه‌کلید همه خودبه‌خود کار می‌کنند و
 * هیچ جاوااسکریپتی لازم نیست.
 *
 * اسکریپت رسمی گوگل عمداً نیامده: یک وابستگی بیرونی روی هر صفحهٔ
 * جغرافیا، برای پیوندی که یک آدرس ثابت است.
 *
 * `nofollow` چون توصیهٔ ما به گوگل نیست، و `noopener` چون مقصد بیرونی
 * است. آیکون همان G مرجع است و `aria-hidden` می‌ماند — معنایش در متن
 * پیوند آمده، نه در تصویر.
 */
if ( ! function_exists( 'topersia_g_gps_link' ) ) {
	function topersia_g_gps_link() {

		$icon = '<svg class="tp-g" viewBox="0 0 48 48" aria-hidden="true" focusable="false">'
			. '<path fill="#4285F4" d="M45.1 24.5c0-1.6-.1-3.2-.4-4.7H24v8.9h11.8c-.5 2.7-2 5-4.4 6.6v5.5h7.1c4.2-3.8 6.6-9.5 6.6-16.3z"/>'
			. '<path fill="#34A853" d="M24 46c5.9 0 10.9-2 14.5-5.2l-7.1-5.5c-2 1.3-4.5 2.1-7.4 2.1-5.7 0-10.6-3.9-12.3-9.1H4.4v5.7C8 41.4 15.4 46 24 46z"/>'
			. '<path fill="#FBBC05" d="M11.7 28.3c-.4-1.3-.7-2.7-.7-4.3s.3-3 .7-4.3v-5.7H4.4A22 22 0 0 0 2 24c0 3.6.9 6.9 2.4 9.9l7.3-5.6z"/>'
			. '<path fill="#EA4335" d="M24 10.6c3.2 0 6.1 1.1 8.4 3.3l6.3-6.3C34.9 4 29.9 2 24 2 15.4 2 8 6.6 4.4 13.9l7.3 5.7c1.7-5.2 6.6-9 12.3-9z"/>'
			. '</svg>';

		return '<a class="tp-gps-btn" href="https://www.google.com/preferences/source?q=topersia.com"'
			. ' rel="nofollow noopener" target="_blank">'
			. $icon
			. '<span class="tp-gps-btn__t">' . esc_html__( 'ToPersia را منبع ترجیحی گوگل کنید', 'topersia' ) . '</span>'
			. '<span class="tp-gps-btn__s">' . esc_html__( 'مطالب ما را بیشتر در نتایج گوگل و AI Mode ببینید', 'topersia' ) . '</span>'
			. '</a>';
	}
}

/** [tp_crumbs] — مسیر راهنما از سلسله‌مراتب رابطه. */
if ( ! function_exists( 'topersia_g_sc_crumbs' ) ) {
	function topersia_g_sc_crumbs( $atts = array() ) {

		$pid = topersia_g_pid( $atts );

		if ( ! $pid ) {
			return '';
		}

		$group = topersia_g_group( $pid, 'crumbs' );
		$chain = array();
		$cur   = $pid;

		if ( ! empty( $group['rels'] ) ) {

			foreach ( $group['rels'] as $spec ) {

				$found = topersia_g_rel_ids( $cur, array( $spec ) );

				if ( empty( $found ) ) {
					break;
				}

				$parent = absint( reset( $found ) );

				if ( empty( $spec['skip'] ) ) {
					$chain[] = $parent;
				}

				$cur = $parent;
			}
		}

		$items = array( '<a href="' . esc_url( home_url( '/' ) ) . '">ToPersia</a>' );

		foreach ( array_reverse( $chain ) as $ancestor ) {

			$view = topersia_g_view_id( $ancestor );

			$items[] = '<a href="' . esc_url( get_permalink( $view ) ) . '">'
				. esc_html( topersia_g_name( $view ) ) . '</a>';
		}

		$items[] = '<span aria-current="page">' . esc_html( topersia_g_name( $pid ) ) . '</span>';

		return '<p class="tp-crumb" aria-label="' . esc_attr__( 'مسیر راهنما', 'topersia' ) . '">'
			. implode( '<span>›</span>', $items ) . '</p>';
	}
}

/**
 * آیا این پست کارت «مرکز» دارد؟ یک خانه از چهار خانهٔ آمار را می‌گیرد.
 */
if ( ! function_exists( 'topersia_g_capital_id' ) ) {
	function topersia_g_capital_id( $post_id ) {

		$group = topersia_g_group( $post_id, 'capital' );

		if ( empty( $group['rels'] ) ) {
			return 0;
		}

		$ids = topersia_g_rel_ids( $post_id, $group['rels'] );

		return empty( $ids ) ? 0 : absint( reset( $ids ) );
	}
}

/**
 * نام فیلدهایی که کارت آمار مصرف می‌کند.
 *
 * تولیدکنندهٔ واحد: کارت آمار این را مصرف می‌کند و کارت حقایق همین را
 * کنار می‌گذارد. اگر هر کدام حساب خودش را می‌کرد، فیلدی که «مرکز» جایش
 * را تنگ کرده بود بی‌صدا از هر دو کارت می‌افتاد — همان اتفاقی که در
 * آزمون T-1 برای climate_type افتاد.
 */
if ( ! function_exists( 'topersia_g_stat_keys' ) ) {
	/**
	 * والدِ مکانیِ بی‌واسطه — همان پلهٔ اولِ مسیر راهنما.
	 *
	 * از همان نقشهٔ `crumbs` می‌آید که `[tp_crumbs]` استفاده می‌کند، نه از
	 * فهرست جدا. پله‌های `skip` (مثل شهرستان — `P5-D172`) رد می‌شوند و
	 * اولین والدِ دیدنی برمی‌گردد.
	 *
	 * @return string نام، یا رشتهٔ خالی.
	 */
	function topersia_g_place_parent( $post_id ) {

		$group = topersia_g_group( $post_id, 'crumbs' );

		if ( empty( $group['rels'] ) ) {
			return '';
		}

		$cur = $post_id;

		foreach ( $group['rels'] as $spec ) {

			$found = topersia_g_rel_ids( $cur, array( $spec ) );

			if ( empty( $found ) ) {
				return '';
			}

			$parent = absint( reset( $found ) );

			if ( empty( $spec['skip'] ) ) {
				return topersia_g_name( topersia_g_view_id( $parent ) );
			}

			$cur = $parent;
		}

		return '';
	}
}

/**
 * پاورقی کارت: والد مکانی · یک واقعیت کلیدی.
 *
 * اگر هیچ‌کدام نبود، خودِ پاورقی هم نیست — نه جعبهٔ خالی، نه جداکنندهٔ
 * بی‌طرف. همان قاعدهٔ ناپدیدشدن که در کل قالب هست.
 */
if ( ! function_exists( 'topersia_g_card_foot' ) ) {
	function topersia_g_card_foot( $item ) {

		$place = isset( $item['place'] ) ? (string) $item['place'] : '';
		$fact  = isset( $item['fact'] ) ? (string) $item['fact'] : '';

		if ( '' === $place && '' === $fact ) {
			return '';
		}

		return '<span class="tp-card__foot">'
			. ( '' !== $place ? '<span class="tp-card__place">' . esc_html( $place ) . '</span>' : '' )
			. ( '' !== $fact ? '<span class="tp-card__fact">' . esc_html( $fact ) . '</span>' : '' )
			. '</span>';
	}
}

/**
 * برچسب نوعِ اعضای یک گروه — از واژه‌نامه، نه ثابت.  P5-D210
 *
 * «شهر» در متن دکمه نباید سخت‌کد شود: همین شورت‌کد برای روستا و محله و
 * استان هم کار می‌کند. برچسب از نخستین عضو گرفته می‌شود، چون اعضای یک
 * گروه هم‌نوع‌اند.
 */
if ( ! function_exists( 'topersia_g_group_kind' ) ) {
	function topersia_g_group_kind( $result ) {

		if ( ! empty( $result['items'][0]['kind'] ) ) {
			return (string) $result['items'][0]['kind'];
		}

		return esc_html__( 'مورد', 'topersia' );
	}
}

/**
 * دکمهٔ «مشاهدهٔ همهٔ N …» — جای شمارندهٔ خاموش.  P5-D210
 *
 * شمارنده عددی بود که کاری نمی‌کرد. همان عدد حالا فهرست کامل را باز و
 * بسته می‌کند. اگر همه‌چیز در اسلایدر جا شده، دکمه نمی‌آید.
 */
if ( ! function_exists( 'topersia_g_all_toggle' ) ) {
	function topersia_g_all_toggle( $uid, $result ) {

		$total = isset( $result['total'] ) ? (int) $result['total'] : 0;
		$shown = isset( $result['items'] ) ? count( $result['items'] ) : 0;

		if ( $total <= $shown ) {
			return '<span class="tp-count">' . topersia_g_fa( $total ) . ' '
				. esc_html( topersia_g_group_kind( $result ) ) . '</span>';
		}

		return '<button type="button" class="tp-more tp-all-btn"'
			. ' data-tp-all="' . esc_attr( $uid ) . '"'
			. ' aria-expanded="false" aria-controls="' . esc_attr( $uid . 'all' ) . '">'
			. esc_html( sprintf(
				/* translators: ۱ شمار، ۲ برچسب نوع */
				__( 'مشاهدهٔ همهٔ %1$s %2$s', 'topersia' ),
				topersia_g_fa( $total ),
				topersia_g_group_kind( $result )
			) )
			. '</button>';
	}
}

/**
 * فهرست فشردهٔ همهٔ اعضا — در DOM، پنهان.  P5-D210
 *
 * پنهان است نه غایب: خزنده و جست‌وجوی درون‌صفحه‌ای هر دو می‌بینندش، و
 * بازکردنش هیچ درخواستی نمی‌زند. فقط نام و پیوند — کارت کامل برای
 * فهرستِ سی‌تایی هم سنگین است هم بی‌فایده.
 */
if ( ! function_exists( 'topersia_g_all_list' ) ) {
	function topersia_g_all_list( $uid, $result ) {

		$total = isset( $result['total'] ) ? (int) $result['total'] : 0;
		$shown = isset( $result['items'] ) ? count( $result['items'] ) : 0;

		if ( $total <= $shown || empty( $result['all'] ) ) {
			return '';
		}

		$rows = '';

		foreach ( $result['all'] as $one ) {

			$rows .= '' !== $one['url']
				? '<li><a href="' . esc_url( $one['url'] ) . '">' . esc_html( $one['name'] ) . '</a></li>'
				: '<li><span>' . esc_html( $one['name'] ) . '</span></li>';
		}

		return '<ul class="tp-all" id="' . esc_attr( $uid . 'all' ) . '" hidden>' . $rows . '</ul>';
	}
}

/**
 * نوار زیر اسلایدر — راهنما و دو دکمهٔ پیمایش.
 *
 * با یک کارت اصلاً نمی‌آید: دکمهٔ قبلی/بعدی وقتی جایی برای رفتن نیست،
 * فقط سر می‌دواند.
 */
if ( ! function_exists( 'topersia_g_slider_bar' ) ) {
	function topersia_g_slider_bar( $uid, $count ) {

		if ( $count < 2 ) {
			return '';
		}

		return '<div class="tp-slider-bar">'
			. '<p class="tp-slider-hint">' . esc_html__( 'برای دیدن بقیه بکشید یا از دکمه‌ها استفاده کنید', 'topersia' ) . '</p>'
			. '<div class="tp-slider-nav">'
			. '<button type="button" class="tp-slider-btn" data-tp-slide="prev" data-tp-for="' . esc_attr( $uid ) . '"'
			. ' aria-label="' . esc_attr__( 'قبلی', 'topersia' ) . '">‹</button>'
			. '<button type="button" class="tp-slider-btn" data-tp-slide="next" data-tp-for="' . esc_attr( $uid ) . '"'
			. ' aria-label="' . esc_attr__( 'بعدی', 'topersia' ) . '">›</button>'
			. '</div></div>';
	}
}

/**
 * یک واقعیت کلیدی — نخستین فیلدِ ناحیهٔ `card` که مقدار دارد.
 *
 * فهرست دستی ندارد: همان `topersia_g_zone_fields()` را می‌خواند که
 * `[tp_stats]` می‌خواند، پس ترتیبِ اهمیت از نقشهٔ فیلد می‌آید نه از حدس
 * ما، و برای هر نوع پست خودبه‌خود درست است.
 *
 * مختصات و بهترین فصل کنار گذاشته می‌شوند — یکی زیر نقشه می‌نشیند و
 * دیگری در جدول فصل‌ها، و هیچ‌کدام روی کارت معنا نمی‌دهند.
 *
 * @return string مقدارِ قالب‌بندی‌شده، یا رشتهٔ خالی.
 */
if ( ! function_exists( 'topersia_g_key_fact' ) ) {
	function topersia_g_key_fact( $post_id ) {

		$fields = topersia_g_zone_fields( $post_id, 'card', array( 'geo_coordinates', 'best_season' ) );

		foreach ( array_keys( $fields ) as $name ) {

			$raw = topersia_g_raw( $post_id, $name );

			if ( '' === $raw || null === $raw || array() === $raw ) {
				continue;
			}

			$value = trim( wp_strip_all_tags( topersia_g_value( $name, $raw ) ) );

			if ( '' !== $value ) {
				return $value;
			}
		}

		return '';
	}
}

if ( ! function_exists( 'topersia_g_stat_keys' ) ) {
	function topersia_g_stat_keys( $post_id ) {

		$slots = 4 - ( topersia_g_capital_id( $post_id ) ? 1 : 0 );

		$fields = topersia_g_zone_fields( $post_id, 'card', array( 'geo_coordinates', 'best_season' ) );

		/*
		 * ترتیب کارت آمار صریح است، نه ترتیبِ نقشهٔ فیلد.  P5-D208
		 *
		 * خواسته: مرکز · جمعیت · مساحت · اقلیم. با ترتیبِ نقشه،
		 * `province_code` پیش از `climate_type` می‌افتاد و خانهٔ چهارم را
		 * می‌گرفت. کد استان جای خودش کارت حقایق است — و چون آن کارت هرچه
		 * را آمار نبرده نشان می‌دهد، همین‌که از این فهرست بیرون بماند
		 * خودبه‌خود آن‌جا می‌رود.
		 *
		 * فهرست برای هر سیزده نوع پست یکی است؛ هر نوع هرچه را دارد از آن
		 * برمی‌دارد. آنچه نامش این‌جا نیست، به ترتیبِ نقشه ته صف می‌رود —
		 * پس نوع تازه بی‌صدا خالی نمی‌ماند.
		 */
		$order = array( 'population', 'area_km2', 'climate_type', 'elevation_m', 'founded_year' );

		$ranked = array();

		foreach ( $order as $name ) {
			if ( isset( $fields[ $name ] ) ) { $ranked[] = $name; }
		}

		foreach ( array_keys( $fields ) as $name ) {
			if ( ! in_array( $name, $ranked, true ) ) { $ranked[] = $name; }
		}

		return array_slice( $ranked, 0, max( 0, $slots ) );
	}
}

/** [tp_stats] — کارت آمار: مرکز (رابطهٔ یک‌به‌یک) + سه حقیقت سرخط. */
if ( ! function_exists( 'topersia_g_sc_stats' ) ) {
	function topersia_g_sc_stats( $atts = array() ) {

		$pid = topersia_g_pid( $atts );

		if ( ! $pid ) {
			return '';
		}

		$cells   = array();
		$capital = topersia_g_capital_id( $pid );

		if ( $capital ) {

			$group = topersia_g_group( $pid, 'capital' );
			$view  = topersia_g_view_id( $capital );

			$cells[] = array(
				isset( $group['title'] ) ? $group['title'] : '',
				'<a href="' . esc_url( get_permalink( $view ) ) . '">'
					. esc_html( topersia_g_name( $view ) ) . '</a>',
			);
		}

		/* مختصات زیر نقشه می‌نشیند و بهترین فصل در جدول فصل‌ها. */
		$map = topersia_g_map();

		foreach ( topersia_g_stat_keys( $pid ) as $name ) {

			$cells[] = array( $map[ $name ]['label'], topersia_g_value( $name, topersia_g_raw( $pid, $name ) ) );
		}

		if ( empty( $cells ) ) {
			return '';
		}

		$out = '';

		foreach ( $cells as $cell ) {

			$out .= '<div class="tp-stat" role="listitem">'
				. '<span class="tp-stat__k">' . esc_html( $cell[0] ) . '</span>'
				. '<b class="tp-stat__v">' . $cell[1] . '</b></div>';
		}

		return '<div class="tp-stats-wrap"><div class="tp-stats" role="list" aria-label="'
			. esc_attr__( 'اطلاعات کلیدی', 'topersia' ) . '">' . $out . '</div></div>';
	}
}

/** [tp_facts] — هر فیلد کارتی که در آمار نیامده، و فهرست جزئیات. */
if ( ! function_exists( 'topersia_g_sc_facts' ) ) {
	function topersia_g_sc_facts( $atts = array() ) {

		$pid = topersia_g_pid( $atts );

		if ( ! $pid ) {
			return '';
		}

		$zone = isset( $atts['zone'] ) ? $atts['zone'] : 'both';
		$map  = topersia_g_map();
		$body = '';

		if ( 'details' !== $zone ) {

			/* دقیقاً همان چیزی که کارت آمار برد، دوباره نمی‌آید — نه یکی بیشتر. */
			$taken  = array_merge( topersia_g_stat_keys( $pid ), array( 'geo_coordinates', 'best_season' ) );
			$fields = topersia_g_zone_fields( $pid, 'card', $taken );

			if ( $fields ) {

				$grid = '';

				foreach ( $fields as $name => $raw ) {

					$grid .= '<div class="tp-fact"><span>' . esc_html( $map[ $name ]['label'] ) . '</span>'
						. '<b>' . topersia_g_value( $name, $raw ) . '</b></div>';
				}

				$body .= '<div class="tp-geo-grid">' . $grid . '</div>';
			}
		}

		if ( 'card' !== $zone ) {

			$details = topersia_g_zone_fields( $pid, 'details' );

			if ( $details ) {

				$list = '';

				foreach ( $details as $name => $raw ) {

					$list .= '<div class="tp-detail"><h4>' . esc_html( $map[ $name ]['label'] ) . '</h4>'
						. '<p>' . topersia_g_value( $name, $raw ) . '</p></div>';
				}

				$body .= '<div class="tp-details">' . $list . '</div>';
			}
		}

		return topersia_g_section( 'tp-geo', 'اطلاعات جغرافیایی', 'GEO', $body );
	}
}

/** [tp_badges] — سوییچرهای درست، جفت‌شده با سالشان. */
if ( ! function_exists( 'topersia_g_sc_badges' ) ) {
	function topersia_g_sc_badges( $atts = array() ) {

		$pid = topersia_g_pid( $atts );

		if ( ! $pid ) {
			return '';
		}

		$body = '';

		foreach ( topersia_g_map() as $name => $field ) {

			if ( 'badge' !== $field['zone'] || 'flag' !== $field['kind'] ) {
				continue;
			}

			if ( ! topersia_g_flag_on( topersia_g_raw( $pid, $name ) ) ) {
				continue;
			}

			$year = '';

			if ( ! empty( $field['year'] ) ) {

				$raw = topersia_g_raw( $pid, $field['year'] );

				if ( topersia_g_filled( $raw ) ) {
					$year = ' <span>· ' . topersia_g_value( $field['year'], $raw ) . '</span>';
				}
			}

			$body .= '<span class="tp-badge">' . esc_html( $field['label'] ) . $year . '</span>';
		}

		if ( '' === $body ) {
			return '';
		}

		return topersia_g_section( 'tp-badges', 'نشان‌ها', 'STATUS', '<div class="tp-badges">' . $body . '</div>' );
	}
}

/**
 * [tp_seasons] — جدول چهار فصل.
 *
 * فیلد best_season یک select تک‌مقداری روی واژه‌نامهٔ ۳۴ است
 * (spring · summer · autumn · winter · all_year) — نه بازهٔ متنی ماه.
 * پس ماه‌های همان فصل روشن می‌شوند و تطبیق زیررشته‌ای انجام نمی‌شود؛
 * «دی» زیررشتهٔ «اردیبهشت» است و آن مسیر یک بار هزینه داده.
 */
if ( ! function_exists( 'topersia_g_sc_seasons' ) ) {
	function topersia_g_sc_seasons( $atts = array() ) {

		$pid = topersia_g_pid( $atts );

		if ( ! $pid ) {
			return '';
		}

		$value = trim( (string) topersia_g_raw( $pid, 'best_season' ) );

		if ( '' === $value ) {
			return '';
		}

		$seasons = array(
			'spring' => array( 'بهار', array( 'فروردین', 'اردیبهشت', 'خرداد' ) ),
			'summer' => array( 'تابستان', array( 'تیر', 'مرداد', 'شهریور' ) ),
			'autumn' => array( 'پاییز', array( 'مهر', 'آبان', 'آذر' ) ),
			'winter' => array( 'زمستان', array( 'دی', 'بهمن', 'اسفند' ) ),
		);

		$all = ( 'all_year' === $value );

		if ( ! $all && ! isset( $seasons[ $value ] ) ) {
			return '';
		}

		$grid = '';

		foreach ( $seasons as $key => $season ) {

			$on    = ( $all || $key === $value );
			$class = 'tp-season tp-season--' . $key . ( $on ? ' has-on' : '' );
			$cells = '<div class="tp-season__h">' . esc_html( $season[0] ) . '</div>';

			foreach ( $season[1] as $month ) {
				$cells .= '<div class="tp-month' . ( $on ? ' is-on' : '' ) . '">' . esc_html( $month ) . '</div>';
			}

			$grid .= '<div class="' . esc_attr( $class ) . '">' . $cells . '</div>';
		}

		$caption = topersia_g_glossary_label( '34', $value );

		$body = '<div class="tp-seasons" role="img" aria-label="'
			. esc_attr( 'بهترین زمان سفر: ' . $caption ) . '">' . $grid . '</div>'
			. '<p class="tp-seasons__cap">' . esc_html( $caption ) . '</p>';

		return topersia_g_section( 'tp-season', 'بهترین زمان سفر', 'WHEN', $body );
	}
}

/**
 * [tp_weather] — هوای سه روز.
 *
 * فقط پوسته و جای خالی. دادهٔ زنده نباید در HTML کش‌شده بیاید، پس پس از
 * بارگذاری از یک نقطهٔ REST با کش نیم‌ساعته خوانده می‌شود. مبنای مکان همان
 * geo_coordinates خود رکورد است؛ فیلد تازه‌ای لازم نیست.
 */
if ( ! function_exists( 'topersia_g_sc_weather' ) ) {
	function topersia_g_sc_weather( $atts = array() ) {

		$pid = topersia_g_pid( $atts );

		if ( ! $pid ) {
			return '';
		}

		$coords = topersia_g_text( $pid, 'geo_coordinates' );

		if ( '' === $coords ) {
			return '';
		}

		$body = '<div class="tp-wx" data-tp-weather data-tp-coords="' . esc_attr( $coords ) . '">'
			. '<div class="tp-wx__day is-load"></div>'
			. '<div class="tp-wx__day is-load"></div>'
			. '<div class="tp-wx__day is-load"></div></div>'
			. '<p class="tp-wx__src">' . esc_html__( 'در حال گرفتن داده…', 'topersia' ) . '</p>';

		return topersia_g_section( 'tp-weather', 'هوای این روزها', 'FORECAST', $body );
	}
}

/** [tp_map] — نقشه با پاپ‌آپ و مختصات زیرش. */
if ( ! function_exists( 'topersia_g_sc_map' ) ) {
	function topersia_g_sc_map( $atts = array() ) {

		$pid = topersia_g_pid( $atts );

		if ( ! $pid ) {
			return '';
		}

		$coords = topersia_g_text( $pid, 'geo_coordinates' );

		if ( '' === $coords ) {
			return '';
		}

		$uid = 'tpmap' . $pid;

		$body = '<div class="tp-map-inner" data-tp-map data-tp-coords="' . esc_attr( $coords ) . '">'
			. '<svg class="tp-map-svg" viewBox="0 0 320 230" role="img" aria-label="'
			. esc_attr__( 'نمای شماتیک نقشه', 'topersia' ) . '">'
			. '<defs><pattern id="' . esc_attr( $uid ) . '" width="24" height="24" patternUnits="userSpaceOnUse">'
			. '<path d="M24 0H0V24" fill="none" stroke="currentColor" stroke-opacity=".16" stroke-width="1"/>'
			. '</pattern></defs>'
			. '<rect width="320" height="230" fill="url(#' . esc_attr( $uid ) . ')"/>'
			. '<path d="M40 60 C 80 40, 140 50, 190 42 C 240 36, 280 60, 290 100'
			. ' C 296 140, 260 180, 210 190 C 160 200, 100 195, 60 175 C 30 160, 22 110, 40 60 Z"'
			. ' fill="none" stroke="currentColor" stroke-width="1.6" stroke-dasharray="4 3" opacity=".65"/>'
			. '<circle cx="150" cy="118" r="3" fill="currentColor" opacity=".35"/>'
			. '</svg>'
			. '<div class="tp-map-pop" role="note"><b>' . esc_html( topersia_g_name( $pid ) ) . '</b></div>'
			. '<button class="tp-map-pin" type="button" aria-label="'
			. esc_attr__( 'نمایش اطلاعات نشانگر', 'topersia' ) . '"></button></div>'
			. '<div class="tp-map-coord"><span class="tp-lbl">'
			. esc_html__( 'مختصات مرکز', 'topersia' ) . '</span>'
			. '<span class="tp-lat" dir="ltr">' . esc_html( $coords ) . '</span></div>'
			. '<button class="tp-map-btn" type="button" data-tp-map-open>'
			. esc_html__( 'باز کردن نقشهٔ کامل', 'topersia' ) . '</button>';

		return topersia_g_section( 'tp-map', 'نقشه', 'MAP', $body, 'tp-rail-card tp-rail-card--flush' );
	}
}

/** سازندهٔ مشترک بخش‌های رابطه. */
if ( ! function_exists( 'topersia_g_rel_items' ) ) {
	function topersia_g_rel_items( $post_id, $key, $limit ) {

		$group = topersia_g_group( $post_id, $key );

		/* گروه یا `rels` دارد یا `chain` — زنجیره چند پله را پشت سر هم
		   می‌رود، مثل استان→شهرستان→شهر.  P5-D210 */
		if ( ! empty( $group['chain'] ) ) {
			$ids = topersia_g_chain_ids( $post_id, $group['chain'] );
		} elseif ( ! empty( $group['rels'] ) ) {
			$ids = topersia_g_rel_ids( $post_id, $group['rels'] );
		} else {
			return array( 'items' => array(), 'total' => 0, 'group' => $group );
		}

		/* یک ترتیب برای همهٔ کارت‌های موجودیت ماندگار.  P5-D211 */
		$ids   = topersia_g_sort_entities( $ids );
		$total = count( $ids );
		$items = array();
		$all   = array();

		foreach ( $ids as $n => $one ) {

			$view = topersia_g_view_id( $one );
			$name = topersia_g_name( $view );
			$url  = topersia_g_public_url( $view );

			/* فهرست فشرده همهٔ N را دارد، اسلایدر فقط سرِ صف را */
			$all[] = array( 'name' => $name, 'url' => $url );

			if ( $n >= $limit ) {
				continue;
			}

			$items[] = array(
				'kind'  => topersia_g_kind_label( $view ),
				'name'  => $name,
				'url'   => $url,
				'sum'   => topersia_g_text( $view, 'short_summary' ),
				'place' => topersia_g_place_parent( $view ),
				'fact'  => topersia_g_key_fact( $view ),
			);
		}

		return array( 'items' => $items, 'total' => $total, 'group' => $group, 'all' => $all );
	}
}

/** [tp_slider rel="..."] — اسلاید کارت برای یک گروه رابطه. */
if ( ! function_exists( 'topersia_g_sc_slider' ) ) {
	function topersia_g_sc_slider( $atts = array() ) {

		$pid = topersia_g_pid( $atts );
		$key = isset( $atts['rel'] ) ? trim( (string) $atts['rel'] ) : '';

		if ( ! $pid || '' === $key ) {
			return '';
		}

		/* هشت کارت در اسلایدر؛ بقیه در فهرست فشرده.  P5-D210 */
		$limit  = isset( $atts['limit'] ) ? absint( $atts['limit'] ) : 8;
		$result = topersia_g_rel_items( $pid, $key, $limit );

		if ( empty( $result['items'] ) ) {
			return '';
		}

		$cards = '';
		$no    = 0;

		foreach ( $result['items'] as $item ) {

			$no ++;

			/*
			 * نوعی که صفحهٔ عمومی ندارد، پیوند هم نمی‌گیرد: کارتش
			 * `<article>` است و حالت هاور ندارد.  P5-D210
			 */
			$linked = '' !== $item['url'];
			$open   = $linked
				? '<a class="tp-card" href="' . esc_url( $item['url'] ) . '">'
				: '<article class="tp-card tp-card--flat">';

			$cards .= $open
				. '<span class="tp-card__art" aria-hidden="true">'
				. '<span class="tp-card__no">' . topersia_g_fa( $no ) . '</span></span>'
				. '<div class="tp-card__body">'
				. ( '' !== $item['kind'] ? '<span class="tp-card__tag">' . esc_html( $item['kind'] ) . '</span>' : '' )
				. '<b class="tp-card__title">' . esc_html( $item['name'] ) . '</b>'
				. ( '' !== $item['sum'] ? '<span class="tp-card__desc">' . esc_html( $item['sum'] ) . '</span>' : '' )
				. topersia_g_card_foot( $item )
				. '</div>'
				. ( $linked ? '</a>' : '</article>' );
		}

		$group = $result['group'];
		$title = isset( $group['title'] ) ? $group['title'] : '';
		$uid   = 'tpsl' . $pid . preg_replace( '/[^a-z0-9]+/i', '', $key );

		return '<section id="' . esc_attr( 'tp-rel-' . $key ) . '" class="tp-section">'
			. ( '' !== $title ? '<div class="tp-section-head"><h2>' . esc_html( $title ) . '</h2>'
				. topersia_g_all_toggle( $uid, $result ) . '</div>' : '' )
			. '<div class="tp-slider-wrap"><div class="tp-slider" id="' . esc_attr( $uid ) . '">' . $cards . '</div></div>'
			. topersia_g_slider_bar( $uid, count( $result['items'] ) )
			. topersia_g_all_list( $uid, $result )
			. '</section>';
	}
}

/** [tp_relgrid rel="..."] — شبکهٔ دوستونی با دکمهٔ ادامه. */
if ( ! function_exists( 'topersia_g_sc_relgrid' ) ) {
	function topersia_g_sc_relgrid( $atts = array() ) {

		$pid = topersia_g_pid( $atts );
		$key = isset( $atts['rel'] ) ? trim( (string) $atts['rel'] ) : '';

		if ( ! $pid || '' === $key ) {
			return '';
		}

		$limit  = isset( $atts['limit'] ) ? absint( $atts['limit'] ) : 6;
		$result = topersia_g_rel_items( $pid, $key, $limit );

		if ( empty( $result['items'] ) ) {
			return '';
		}

		$grid = '';

		foreach ( $result['items'] as $item ) {

			$grid .= '<a href="' . esc_url( $item['url'] ) . '">'
				. ( '' !== $item['kind'] ? '<span class="tp-kind">' . esc_html( $item['kind'] ) . '</span>' : '' )
				. '<b>' . esc_html( $item['name'] ) . '</b></a>';
		}

		$rest = $result['total'] - count( $result['items'] );
		$more = '';

		if ( $rest > 0 ) {

			$more = '<button class="tp-more" type="button" data-tp-more="' . esc_attr( $key ) . '"'
				. ' data-tp-rest="' . esc_attr( $rest ) . '">'
				. topersia_g_fa( $rest ) . ' ' . esc_html__( 'مورد دیگر', 'topersia' ) . '</button>';
		}

		$group = $result['group'];

		return topersia_g_section(
			'tp-' . $key,
			isset( $group['title'] ) ? $group['title'] : '',
			isset( $group['kicker'] ) ? $group['kicker'] : '',
			'<div class="tp-grid">' . $grid . '</div>' . $more
		);
	}
}

/** [tp_gallery] — گالری از featured_image_gallery. */
if ( ! function_exists( 'topersia_g_sc_gallery' ) ) {
	function topersia_g_sc_gallery( $atts = array() ) {

		$pid = topersia_g_pid( $atts );

		if ( ! $pid ) {
			return '';
		}

		$raw = topersia_g_raw( $pid, 'featured_image_gallery' );

		if ( is_string( $raw ) ) {
			$raw = array_filter( array_map( 'trim', explode( ',', $raw ) ) );
		}

		if ( ! is_array( $raw ) || empty( $raw ) ) {
			return '';
		}

		$items = '';

		foreach ( $raw as $attachment ) {

			$attachment = absint( is_array( $attachment ) && isset( $attachment['id'] ) ? $attachment['id'] : $attachment );

			if ( ! $attachment ) {
				continue;
			}

			$image = function_exists( 'wp_get_attachment_image' )
				? wp_get_attachment_image( $attachment, 'medium_large', false, array( 'loading' => 'lazy' ) )
				: '';

			if ( '' === $image ) {
				continue;
			}

			$caption = function_exists( 'wp_get_attachment_caption' ) ? (string) wp_get_attachment_caption( $attachment ) : '';

			$items .= '<figure class="tp-gallery__item">' . $image
				. ( '' !== $caption ? '<figcaption class="tp-gallery__label">' . esc_html( $caption ) . '</figcaption>' : '' )
				. '</figure>';
		}

		if ( '' === $items ) {
			return '';
		}

		return '<section id="tp-gallery-sec" class="tp-section">'
			. '<div class="tp-section-head"><h2>' . esc_html__( 'گالری', 'topersia' ) . '</h2>'
			. '<button class="tp-more" type="button" data-tp-gallery-open>'
			. esc_html__( 'گالری کامل', 'topersia' ) . '</button></div>'
			. '<div class="tp-gallery">' . $items . '</div></section>';
	}
}

/**
 * تولیدکنندهٔ واحد ردیف‌های ریپیتر.
 *
 * ردیف بازنشسته هرگز حذف نمی‌شود؛ وضعیتش عوض می‌شود و هسته آن را فیلتر
 * می‌کند. اگر این فیلتر نباشد، یک ردیف بازنشسته هم در صفحه و هم در
 * JSON-LD منتشر می‌شود.  P5-D121 · P5-D145
 */
if ( ! function_exists( 'topersia_g_rows' ) ) {
	function topersia_g_rows( $post_id, $key ) {

		$rows = topersia_g_raw( $post_id, $key );

		if ( ! is_array( $rows ) ) {
			return array();
		}

		if ( function_exists( 'topersia_active_rows' ) ) {
			return topersia_active_rows( $rows );
		}

		/* هسته نیست — همان قطبیت را دستی نگه می‌داریم. */
		$out = array();

		foreach ( $rows as $row ) {

			if ( ! is_array( $row ) ) {
				continue;
			}

			$status = '';

			foreach ( $row as $sub => $value ) {

				if ( '_row_status' === substr( $sub, -11 ) ) {
					$status = $value;
					break;
				}
			}

			if ( 'not_applicable' !== $status ) {
				$out[] = $row;
			}
		}

		return $out;
	}
}

/** [tp_audio] — روایت صوتی از ریپیتر. */
if ( ! function_exists( 'topersia_g_sc_audio' ) ) {
	function topersia_g_sc_audio( $atts = array() ) {

		$pid = topersia_g_pid( $atts );

		if ( ! $pid ) {
			return '';
		}

		$rows = topersia_g_rows( $pid, 'audio_narration' );
		$body = '';

		foreach ( $rows as $row ) {

			$title = isset( $row['audio_title'] ) ? trim( wp_strip_all_tags( (string) $row['audio_title'] ) ) : '';
			$url   = isset( $row['audio_external_url'] ) ? trim( (string) $row['audio_external_url'] ) : '';
			$time  = isset( $row['audio_duration'] ) ? trim( (string) $row['audio_duration'] ) : '';

			if ( '' === $url && ! empty( $row['audio_file'] ) && function_exists( 'wp_get_attachment_url' ) ) {

				$file = is_array( $row['audio_file'] ) && isset( $row['audio_file']['id'] )
					? $row['audio_file']['id']
					: $row['audio_file'];

				$url = (string) wp_get_attachment_url( absint( $file ) );
			}

			if ( '' === $title || '' === $url ) {
				continue;
			}

			$body .= '<a href="' . esc_url( $url ) . '"><b>' . esc_html( $title ) . '</b>'
				. ( '' !== $time ? '<span>' . topersia_g_fa( $time ) . '</span>' : '' ) . '</a>';
		}

		if ( '' === $body ) {
			return '';
		}

		return topersia_g_section( 'tp-audio', 'روایت صوتی', 'LISTEN', '<div class="tp-audio">' . $body . '</div>' );
	}
}

/** [tp_faq] — همان دادهٔ پرسش‌ها که در JSON-LD می‌رود. */
if ( ! function_exists( 'topersia_g_sc_faq' ) ) {
	function topersia_g_sc_faq( $atts = array() ) {

		$pid = topersia_g_pid( $atts );

		if ( ! $pid ) {
			return '';
		}

		$rows = topersia_g_rows( $pid, 'faq_items' );
		$body = '';

		foreach ( $rows as $row ) {

			$question = isset( $row['faq_question'] ) ? trim( wp_strip_all_tags( (string) $row['faq_question'] ) ) : '';
			$answer   = isset( $row['faq_answer'] ) ? trim( wp_strip_all_tags( (string) $row['faq_answer'] ) ) : '';

			if ( '' === $question || '' === $answer ) {
				continue;
			}

			$body .= '<details class="tp-faq__item"><summary>' . esc_html( $question ) . '</summary>'
				. '<p>' . esc_html( $answer ) . '</p></details>';
		}

		if ( '' === $body ) {
			return '';
		}

		return '<section id="tp-faq" class="tp-section tp-faq">'
			. '<div class="tp-section-head"><h2>' . esc_html__( 'پرسش‌های متداول', 'topersia' ) . '</h2></div>'
			. $body . '</section>';
	}
}

/** [tp_sources] — منابع، راستی‌آزمایی، شناسهٔ موجودیت. */
if ( ! function_exists( 'topersia_g_sc_sources' ) ) {
	function topersia_g_sc_sources( $atts = array() ) {

		$pid = topersia_g_pid( $atts );

		if ( ! $pid ) {
			return '';
		}

		$body = '';
		$list = '';

		foreach ( topersia_g_rows( $pid, 'source_references' ) as $row ) {

			$name = isset( $row['source_name'] ) ? trim( wp_strip_all_tags( (string) $row['source_name'] ) ) : '';
			$url  = isset( $row['source_url'] ) ? trim( (string) $row['source_url'] ) : '';

			if ( '' === $name ) {
				continue;
			}

			$list .= '<li>' . ( '' !== $url
				? '<a href="' . esc_url( $url ) . '" rel="nofollow noopener">' . esc_html( $name ) . '</a>'
				: esc_html( $name ) ) . '</li>';
		}

		if ( '' !== $list ) {
			$body .= '<ol>' . $list . '</ol>';
		}

		$verified = topersia_g_date_fa( topersia_g_raw( $pid, 'last_verified_date' ) );

		if ( '' !== $verified ) {

			$body .= '<span class="tp-verified">✓ '
				. esc_html__( 'آخرین راستی‌آزمایی:', 'topersia' ) . ' ' . esc_html( $verified ) . '</span>';
		}

		$rows   = '';
		$status = topersia_g_text( $pid, 'content_status' );
		$uid    = topersia_g_text( $pid, 'entity_uid' );
		$ref    = topersia_g_text( $pid, 'external_reference_uri' );

		if ( '' !== $status ) {

			$rows .= '<div><span>' . esc_html__( 'وضعیت محتوا', 'topersia' ) . '</span>'
				. '<b>' . esc_html( topersia_g_glossary_label( '37', $status ) ) . '</b></div>';
		}

		if ( '' !== $uid ) {

			$rows .= '<div><span>' . esc_html__( 'شناسهٔ موجودیت', 'topersia' ) . '</span>'
				. '<b class="tp-lat" dir="ltr">' . esc_html( $uid ) . '</b></div>';
		}

		if ( '' !== $ref ) {

			$rows .= '<div><span>' . esc_html__( 'مرجع خارجی', 'topersia' ) . '</span>'
				. '<a class="tp-lat" dir="ltr" href="' . esc_url( $ref ) . '" rel="nofollow noopener">'
				. esc_html( $ref ) . '</a></div>';
		}

		if ( '' !== $rows ) {
			$body .= '<div class="tp-uid">' . $rows . '</div>';
		}

		if ( '' !== $body ) {
			$body = '<div class="tp-sources-rail">' . $body . '</div>';
		}

		return topersia_g_section( 'tp-sources', 'منابع و راستی‌آزمایی', 'PROVENANCE', $body );
	}
}

/* =========================================================================
   ۵ — آهنگساز صفحه
   =========================================================================

   چرا این شورت‌کد وجود دارد:

   قرار اولیه این بود که المنتور اسکلت چیدمان بسازد و هسته محتوا. سه دور
   آزمون زنده نشان داد این مرز جواب نمی‌دهد: کانتینر المنتور CSS خودش را
   با همان ویژگی ما می‌نویسد و بعد از فایل ما بار می‌شود، سربرگ نمی‌تواند
   از جعبه بیرون بزند، و ترتیب موبایل باید از میان دو لایه پوشش رد شود.
   هر دور، یک ترفند ویژگی تازه لازم داشت — و ترفند روی ۱۹۴٬۰۰۰ صفحه
   یعنی بدهی.

   حالا لایهٔ نمایش کل بدنه را می‌سازد و المنتور دقیقاً یک ویجت دارد.
   چیزی از دست نمی‌رود، چون از P5-D179 به بعد چیدمان هم در CSS بود و
   المنتور جز یک درخت کانتینر که با ما می‌جنگید چیزی نمی‌داد.  P5-D183
   ========================================================================= */

/**
 * نمایش هر گروه رابطه: ستون · تولیدکننده · شناسه · نام در نوار بخش‌ها.
 *
 * ترتیب همین آرایه، ترتیب نشستن بخش‌ها در هر ستون است.
 *
 * `capital` و `crumbs` اینجا نیستند چون بخش مستقل نمی‌سازند — اولی در
 * کارت آمار می‌نشیند و دومی در مسیر راهنما.
 */
if ( ! function_exists( 'topersia_g_rel_zones' ) ) {
	function topersia_g_rel_zones() {

		$zones = array(
			/* `counties` عمداً نیست: شهرستان صفحه ندارد و روی صفحهٔ استان
			   جای شهرها را می‌گرفت.  P5-D210 */
			'cities'     => array( 'main', 'topersia_g_sc_slider',  'tp-rel-cities',     'شهرها' ),
			'districts'  => array( 'main', 'topersia_g_sc_slider',  'tp-rel-districts',  'محله‌ها' ),
			'villages'   => array( 'main', 'topersia_g_sc_slider',  'tp-rel-villages',   'روستاها' ),
			'provinces'  => array( 'main', 'topersia_g_sc_slider',  'tp-rel-provinces',  'استان‌ها' ),
			'culture'    => array( 'main', 'topersia_g_sc_culture', 'tp-culture',        'فرهنگ و غذا' ),
			'nature'     => array( 'rail', 'topersia_g_sc_relgrid', 'tp-nature',     'طبیعت' ),
			'ancient'    => array( 'rail', 'topersia_g_sc_relgrid', 'tp-ancient',    'باستانی' ),
			'practical'  => array( 'rail', 'topersia_g_sc_relgrid', 'tp-practical',  'سفر عملی' ),
			'border'     => array( 'rail', 'topersia_g_sc_relgrid', 'tp-border',     'گذرهای مرزی' ),
			'subranges'  => array( 'rail', 'topersia_g_sc_relgrid', 'tp-subranges',  'زیرشاخه‌ها' ),
			'capital-of' => array( 'rail', 'topersia_g_sc_relgrid', 'tp-capital-of', 'مرکزیت' ),
			'neighbors'  => array( 'rail', 'topersia_g_sc_relgrid', 'tp-neighbors',  'هم‌مرزها' ),
			'routes'     => array( 'rail', 'topersia_g_sc_relgrid', 'tp-routes',     'مسیرها' ),
		);

		if ( function_exists( 'apply_filters' ) ) {
			$zones = apply_filters( 'topersia_g_rel_zones', $zones );
		}

		return $zones;
	}
}

/**
 * فهرست نواحی، به همان ترتیبی که در صفحه می‌نشینند.
 *
 * بخش‌های رابطه‌ای از نقشهٔ همین نوع پست ساخته می‌شوند، نه از فهرست ثابت.
 * قالب دستهٔ G یکی است ولی سیزده نوع پست ساختار رابطهٔ متفاوتی دارند؛ فهرست
 * ثابتِ استان‌شکل یعنی شهر و روستا و کوه بخش‌های خودشان را هرگز نگیرند.
 */
if ( ! function_exists( 'topersia_g_layout' ) ) {
	function topersia_g_layout( $post_id = 0 ) {

		$type = ( $post_id && function_exists( 'get_post_type' ) ) ? get_post_type( $post_id ) : '';
		$map  = topersia_g_relmap();
		$has  = ( $type && isset( $map[ $type ] ) ) ? $map[ $type ] : array();

		$rel = array( 'main' => array(), 'rail' => array() );

		foreach ( topersia_g_rel_zones() as $key => $zone ) {

			if ( empty( $has[ $key ] ) ) {
				continue;
			}

			$rel[ $zone[0] ][] = array(
				'fn'   => $zone[1],
				'atts' => array( 'rel' => $key ),
				'id'   => $zone[2],
				'nav'  => $zone[3],
			);
		}

		$layout = array(

			'main' => array_merge(
				array(
					array( 'fn' => 'topersia_g_sc_gallery', 'atts' => array(), 'id' => 'tp-gallery-sec', 'nav' => 'گالری' ),
				),
				$rel['main'],
				array(
					array( 'fn' => 'topersia_g_sc_faq', 'atts' => array(), 'id' => 'tp-faq', 'nav' => 'پرسش‌ها' ),
				)
			),

			'rail' => array_merge(
				array(
					array( 'fn' => 'topersia_g_sc_actionbar', 'atts' => array(), 'id' => '', 'nav' => '' ),
					array( 'fn' => 'topersia_g_sc_map',      'atts' => array(), 'id' => 'tp-map',     'nav' => 'نقشه' ),
					array( 'fn' => 'topersia_g_sc_weather',  'atts' => array(), 'id' => 'tp-weather', 'nav' => '' ),
					array( 'fn' => 'topersia_g_sc_seasons',  'atts' => array(), 'id' => 'tp-season',  'nav' => 'زمان سفر' ),
					array( 'fn' => 'topersia_g_sc_facts',    'atts' => array(), 'id' => 'tp-geo',     'nav' => 'جغرافیا' ),
					array( 'fn' => 'topersia_g_sc_badges',   'atts' => array(), 'id' => 'tp-badges',  'nav' => '' ),
				),
				$rel['rail'],
				array(
					array( 'fn' => 'topersia_g_sc_audio',   'atts' => array(), 'id' => 'tp-audio',   'nav' => '' ),
					array( 'fn' => 'topersia_g_sc_sources', 'atts' => array(), 'id' => 'tp-sources', 'nav' => 'منابع' ),
				)
			),
		);

		if ( function_exists( 'apply_filters' ) ) {
			$layout = apply_filters( 'topersia_g_layout', $layout, $post_id );
		}

		return $layout;
	}
}

/**
 * [tp_page] — کل بدنهٔ صفحهٔ موجودیت.
 *
 * نوار بخش‌ها از روی نواحی‌ای ساخته می‌شود که واقعاً محتوا داشتند، نه از
 * یک فهرست ثابت. لینک به بخشی که وجود ندارد، بدترین نوع ناوبری است.
 */
if ( ! function_exists( 'topersia_g_sc_page' ) ) {
	function topersia_g_sc_page( $atts = array() ) {

		$pid = topersia_g_pid( $atts );

		if ( ! $pid ) {
			return '';
		}

		$layout = topersia_g_layout( $pid );
		$nav    = array();
		$cols   = array( 'main' => '', 'rail' => '' );

		foreach ( $cols as $key => $ignored ) {

			if ( empty( $layout[ $key ] ) ) {
				continue;
			}

			foreach ( $layout[ $key ] as $zone ) {

				if ( ! function_exists( $zone['fn'] ) ) {
					continue;
				}

				$html = call_user_func( $zone['fn'], array_merge( $zone['atts'], array( 'id' => $pid ) ) );

				if ( '' === trim( (string) $html ) ) {
					continue;
				}

				$cols[ $key ] .= $html;

				if ( '' !== $zone['nav'] && '' !== $zone['id'] ) {
					$nav[ $zone['id'] ] = $zone['nav'];
				}
			}
		}

		$snav = '';

		if ( count( $nav ) > 1 ) {

			$links = '';

			foreach ( $nav as $id => $label ) {
				$links .= '<a href="#' . esc_attr( $id ) . '">' . esc_html( $label ) . '</a>';
			}

			$snav = '<nav class="tp-snav" aria-label="' . esc_attr__( 'ناوبری بخش‌های صفحه', 'topersia' ) . '">'
				. '<div class="tp-wrap tp-snav__in">' . $links . '</div></nav>';
		}

		$body = '';

		if ( '' !== $cols['main'] || '' !== $cols['rail'] ) {

			$body = '<div class="tp-wrap"><div class="tp-content">'
				. '<div class="tp-main">' . $cols['main'] . '</div>'
				. '<aside class="tp-rail" aria-label="' . esc_attr__( 'اطلاعات مکمل', 'topersia' ) . '">'
				. $cols['rail'] . '</aside>'
				. '</div></div>';
		}

		return '<div class="tp-page">'
			. topersia_g_sc_hero( array( 'id' => $pid ) )
			. topersia_g_sc_stats( array( 'id' => $pid ) )
			. $snav
			. '<div class="tp-wrap">' . topersia_g_sc_crumbs( array( 'id' => $pid ) ) . '</div>'
			. $body
			. topersia_g_mobilebar( $pid, $nav )
			. topersia_g_modals( $pid )
			. '</div>';
	}
}

/**
 * نوار پایین موبایل و برگهٔ بخش‌ها.
 *
 * نوار افقی دسکتاپ روی موبایل بد کار می‌کند: بیست برچسب در یک خط اسکرولی
 * که باید افقی گشت تا مقصد پیدا شود. جایش چهار میان‌بر ثابت و یک برگهٔ
 * شماره‌گذاری‌شده می‌آید.
 *
 * برگه از همان `$nav` تغذیه می‌شود که نوار دسکتاپ می‌سازد، پس هیچ‌وقت به
 * بخشی که رندر نشده لینک نمی‌دهد.  P5-D192
 */
if ( ! function_exists( 'topersia_g_mobilebar' ) ) {
	function topersia_g_mobilebar( $post_id, $nav ) {

		if ( ! is_array( $nav ) || count( $nav ) < 2 ) {
			return '';
		}

		$icons = array(
			'top'  => '<path d="M12 19V5M5 12l7-7 7 7"/>',
			'pin'  => '<path d="M12 21s7-6.4 7-11a7 7 0 1 0-14 0c0 4.6 7 11 7 11z"/><circle cx="12" cy="10" r="2.6"/>',
			'save' => '<path d="M6 3h12v18l-6-4.5L6 21z"/>',
			'list' => '<path d="M4 6h16M4 12h16M4 18h16"/>',
		);

		$svg = function ( $key ) use ( $icons ) {
			return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7"'
				. ' stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">'
				. $icons[ $key ] . '</svg>';
		};

		/* میان‌بر دوم به اولین بخشِ ستون اصلی می‌رود، هرچه که باشد. */
		$first = '';
		foreach ( $nav as $id => $ignored ) {
			if ( 'tp-map' !== $id ) { $first = $id; break; }
		}

		$row = '<button type="button" data-tp-go="top">' . $svg( 'top' )
			. '<span>' . esc_html__( 'بالا', 'topersia' ) . '</span></button>';

		if ( $first ) {
			$row .= '<button type="button" data-tp-go="' . esc_attr( $first ) . '">' . $svg( 'pin' )
				. '<span>' . esc_html( $nav[ $first ] ) . '</span></button>';
		}

		if ( isset( $nav['tp-map'] ) ) {
			$row .= '<button type="button" data-tp-go="tp-map">' . $svg( 'pin' )
				. '<span>' . esc_html__( 'نقشه', 'topersia' ) . '</span></button>';
		}

		$row .= '<button type="button" data-tp-go="save">' . $svg( 'save' )
			. '<span>' . esc_html__( 'ذخیره', 'topersia' ) . '</span></button>'
			. '<button type="button" data-tp-sheet-open>' . $svg( 'list' )
			. '<span>' . esc_html__( 'بخش‌ها', 'topersia' ) . '</span></button>';

		$items = '';
		foreach ( $nav as $id => $label ) {
			$items .= '<li><a href="#' . esc_attr( $id ) . '">' . esc_html( $label ) . '</a></li>';
		}

		return '<nav class="tp-mnav" aria-label="' . esc_attr__( 'ناوبری موبایل', 'topersia' ) . '">'
			. '<div class="tp-mnav__row">' . $row . '</div></nav>'
			. '<div class="tp-sheet" id="tpSheet">'
			. '<div class="tp-sheet__bd" data-tp-close></div>'
			. '<div class="tp-sheet__p" role="dialog" aria-modal="true" aria-label="'
			. esc_attr__( 'بخش‌های صفحه', 'topersia' ) . '">'
			. '<h2>' . esc_html__( 'بخش‌های این صفحه', 'topersia' ) . '</h2>'
			. '<ol>' . $items . '</ol></div></div>';
	}
}

/**
 * [tp_culture] — شبکهٔ شش خانوادهٔ فرهنگی.
 *
 * گروه `culture` سیزده رابطه دارد و به‌صورت یک اسلایدر تخت، تودهٔ بی‌شکلی
 * می‌شود. اینجا به شش خانواده تقسیم می‌شود که هرکدام آیکون و شمار دارد.
 * خانوادهٔ هر رابطه در نقشه نشسته (`fam`) و از نوعِ سرِ دیگر مشتق شده.
 *
 * خانوادهٔ بی‌نتیجه کارت نمی‌سازد، و اگر هیچ خانواده‌ای پر نشود کل بخش
 * ناپدید می‌شود — همان قاعدهٔ همیشگی.  P5-D192
 */
if ( ! function_exists( 'topersia_g_families' ) ) {
	function topersia_g_families() {

		$fam = array(
			'artisanat' => array( 'صنایع دستی', 'ARTISANAT',
				'<path d="M12 2l1.8 5.6H20l-4.7 3.4 1.8 5.6L12 13.2 6.9 16.6 8.7 11 4 7.6h6.2z"/>' ),
			'cuisine'   => array( 'خوراک محلی', 'CUISINE',
				'<path d="M3 11h18M5 11V8a3 3 0 016 0v3M13 11V8a3 3 0 016 0v3M4 11v8M20 11v8"/>' ),
			'music'     => array( 'موسیقی و آیین', 'MUSIC & RITUAL',
				'<path d="M9 18V5l10-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="16" cy="16" r="3"/>' ),
			'festivals' => array( 'جشنواره', 'FESTIVALS',
				'<path d="M4 20l6-14 8 6-14 8z"/><path d="M14 4l1.5 1.5M18 8l1.5 1.5M17 3l.8.8"/>' ),
			'seasonal'  => array( 'رویداد فصلی و مذهبی', 'SEASONAL',
				'<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M8 3v4M16 3v4M3 11h18"/>' ),
			'heritage'  => array( 'زبان و پوشاک', 'HERITAGE',
				'<path d="M12 3l4 2v4a8 8 0 01-4 7 8 8 0 01-4-7V5z"/>' ),
		);

		if ( function_exists( 'apply_filters' ) ) {
			$fam = apply_filters( 'topersia_g_families', $fam );
		}

		return $fam;
	}
}

if ( ! function_exists( 'topersia_g_sc_culture' ) ) {
	function topersia_g_sc_culture( $atts = array() ) {

		$pid = topersia_g_pid( $atts );

		if ( ! $pid ) {
			return '';
		}

		$group = topersia_g_group( $pid, 'culture' );

		if ( empty( $group['rels'] ) ) {
			return '';
		}

		/* رابطه‌ها را به خانواده‌شان تقسیم کن، با حفظ ترتیب نقشه */
		$buckets = array();
		foreach ( $group['rels'] as $spec ) {
			if ( empty( $spec['fam'] ) ) { continue; }
			$buckets[ $spec['fam'] ][] = $spec;
		}

		if ( ! $buckets ) {
			return '';
		}

		$cards = '';

		foreach ( topersia_g_families() as $key => $meta ) {

			if ( empty( $buckets[ $key ] ) ) {
				continue;
			}

			$ids = topersia_g_rel_ids( $pid, $buckets[ $key ] );

			if ( ! $ids ) {
				continue;
			}

			$chips = '';
			foreach ( $ids as $rel_id ) {
				$view   = topersia_g_view_id( $rel_id );
				$chips .= '<li><a href="' . esc_url( get_permalink( $view ) ) . '">'
					. esc_html( topersia_g_name( $view ) ) . '</a></li>';
			}

			$cards .= '<article class="tp-cult">'
				. '<span class="tp-cult__no">' . topersia_g_fa( count( $ids ) ) . '</span>'
				. '<div class="tp-cult__head">'
				. '<span class="tp-cult__icon" aria-hidden="true">'
				. '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"'
				. ' stroke-linecap="round" stroke-linejoin="round">' . $meta[2] . '</svg></span>'
				. '<div class="tp-cult__title">'
				. '<span class="tp-k">' . esc_html( $meta[1] ) . '</span>'
				. '<h3>' . esc_html( $meta[0] ) . '</h3>'
				. '</div></div>'
				. '<ul class="tp-cult__list">' . $chips . '</ul>'
				. '</article>';
		}

		if ( '' === $cards ) {
			return '';
		}

		return topersia_g_section(
			'tp-culture',
			isset( $group['title'] ) ? $group['title'] : '',
			isset( $group['kicker'] ) ? $group['kicker'] : '',
			'<div class="tp-cult-grid">' . $cards . '</div>'
		);
	}
}

/**
 * مودال نقشه و مودال گالری.
 *
 * هیچ‌کدام دادهٔ تازه نمی‌خواهند: نقشه همان مختصاتِ کارت نقشه را بزرگ
 * نشان می‌دهد و گالری همان `featured_image_gallery` را.
 *
 * هر مودال فقط وقتی ساخته می‌شود که ناحیهٔ متناظرش محتوا داشته باشد،
 * وگرنه دکمه‌ای که بازش کند روی صفحه نیست.  P5-D192
 */
if ( ! function_exists( 'topersia_g_modals' ) ) {
	function topersia_g_modals( $post_id ) {

		$out    = '';
		$name   = topersia_g_name( $post_id );
		$coords = (string) topersia_g_raw( $post_id, 'geo_coordinates' );

		if ( '' !== (string) $coords ) {

			$out .= '<div class="tp-modal" id="tpMapModal" role="dialog" aria-modal="true"'
				. ' aria-labelledby="tpMapModalTitle">'
				. '<div class="tp-modal__bd" data-tp-close></div>'
				. '<div class="tp-modal__card">'
				. '<div class="tp-modal__head">'
				. '<h3 id="tpMapModalTitle">' . esc_html( sprintf(
					/* translators: %s نام موجودیت */
					__( 'نقشهٔ %s', 'topersia' ), $name ) ) . '</h3>'
				. '<button class="tp-modal__close" type="button" data-tp-close'
				. ' aria-label="' . esc_attr__( 'بستن', 'topersia' ) . '">&times;</button>'
				. '</div>'
				. '<div class="tp-modal__map" role="img" aria-label="'
				. esc_attr( sprintf( __( 'نمای بزرگ نقشهٔ %s', 'topersia' ), $name ) ) . '">'
				. '<svg viewBox="0 0 800 480" aria-hidden="true" class="tp-map-svg">'
				. '<path d="M90 130 C 200 80, 340 100, 470 84 C 590 72, 700 130, 720 220'
				. ' C 740 320, 620 400, 500 420 C 380 440, 220 430, 140 390'
				. ' C 70 350, 50 220, 90 130 Z" fill="none" stroke="currentColor"'
				. ' stroke-width="2" stroke-dasharray="6 5" opacity=".6"/></svg>'
				. '<div class="tp-map-pin"></div>'
				. '</div>'
				. '<div class="tp-modal__meta">'
				. '<span class="tp-lbl">' . esc_html__( 'مختصات مرکز', 'topersia' ) . '</span> '
				. '<span class="tp-lat" dir="ltr">' . esc_html( $coords ) . '</span>'
				. '</div></div></div>';
		}

		/* همان منبعِ [tp_gallery]، فقط در اندازهٔ بزرگ‌تر */
		$raw = topersia_g_raw( $post_id, 'featured_image_gallery' );

		if ( is_string( $raw ) ) {
			$raw = array_filter( array_map( 'trim', explode( ',', $raw ) ) );
		}

		$items = '';
		$shots = 0;

		if ( is_array( $raw ) ) {
			foreach ( $raw as $attachment ) {

				$attachment = absint( is_array( $attachment ) && isset( $attachment['id'] ) ? $attachment['id'] : $attachment );

				if ( ! $attachment ) {
					continue;
				}

				$image = function_exists( 'wp_get_attachment_image' )
					? wp_get_attachment_image( $attachment, 'large', false, array( 'loading' => 'lazy' ) )
					: '';

				if ( '' === $image ) {
					continue;
				}

				$caption = function_exists( 'wp_get_attachment_caption' ) ? (string) wp_get_attachment_caption( $attachment ) : '';

				$shots ++;
				$items .= '<figure class="tp-gmodal__item">' . $image
					. ( '' !== $caption ? '<figcaption class="tp-gmodal__cap">' . esc_html( $caption ) . '</figcaption>' : '' )
					. '</figure>';
			}
		}

		if ( '' !== $items ) {

			$out .= '<div class="tp-gmodal" id="tpGalleryModal" role="dialog" aria-modal="true"'
				. ' aria-labelledby="tpGalleryModalTitle">'
				. '<div class="tp-gmodal__head">'
				. '<h3 class="tp-gmodal__title" id="tpGalleryModalTitle">'
				. esc_html( sprintf(
					/* translators: %s نام موجودیت */
					__( 'گالری کامل %s', 'topersia' ), $name ) )
				. ' <small>' . esc_html( sprintf(
					/* translators: %s شمار تصویر */
					__( '%s تصویر', 'topersia' ), topersia_g_fa( $shots ) ) ) . '</small></h3>'
				. '<button class="tp-gmodal__close" type="button" data-tp-close'
				. ' aria-label="' . esc_attr__( 'بستن گالری', 'topersia' ) . '">&times;</button>'
				. '</div>'
				. '<div class="tp-gmodal__grid">' . $items . '</div></div>';
		}

		return $out;
	}
}

/* =========================================================================
   ۶ — ثبت
   ========================================================================= */

if ( ! function_exists( 'topersia_g_register' ) ) {
	function topersia_g_register() {

		$shortcodes = array(
			'tp_page'      => 'topersia_g_sc_page',
			'tp_culture'   => 'topersia_g_sc_culture',
			'tp_hero'      => 'topersia_g_sc_hero',
			'tp_actionbar' => 'topersia_g_sc_actionbar',
			'tp_crumbs'    => 'topersia_g_sc_crumbs',
			'tp_stats'     => 'topersia_g_sc_stats',
			'tp_facts'     => 'topersia_g_sc_facts',
			'tp_badges'    => 'topersia_g_sc_badges',
			'tp_seasons'   => 'topersia_g_sc_seasons',
			'tp_weather'   => 'topersia_g_sc_weather',
			'tp_map'       => 'topersia_g_sc_map',
			'tp_slider'    => 'topersia_g_sc_slider',
			'tp_relgrid'   => 'topersia_g_sc_relgrid',
			'tp_gallery'   => 'topersia_g_sc_gallery',
			'tp_audio'     => 'topersia_g_sc_audio',
			'tp_faq'       => 'topersia_g_sc_faq',
			'tp_sources'   => 'topersia_g_sc_sources',
		);

		foreach ( $shortcodes as $tag => $callback ) {

			/* پیشوند tp_ کوتاه است؛ گارد لازم است تا افزونهٔ دیگری بی‌صدا برنده نشود. */
			if ( function_exists( 'shortcode_exists' ) && shortcode_exists( $tag ) ) {

				if ( function_exists( 'topersia_log' ) ) {
					topersia_log( 'شورت‌کد ' . $tag . ' از قبل ثبت شده بود؛ ثبت نشد.', 'warning', 'render' );
				}

				continue;
			}

			add_shortcode( $tag, $callback );
		}
	}
}

if ( function_exists( 'topersia_render_ready' ) && topersia_render_ready() ) {
	topersia_g_register();
}
