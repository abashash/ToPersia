/*!
 * ToPersia — رفتار نواحی دستهٔ G
 * نسخه: 1.0.0
 *
 * فقط سه کار: جابه‌جایی نوار کنش، اشتراک‌گذاری، و وضعیت ذخیره.
 * هوا و نقشه اینجا نیستند؛ هر دو منتظر تصمیم دربارهٔ سرویس‌دهنده‌اند.
 */
( function () {
	'use strict';

	/* ── نوار کنش ─────────────────────────────────────────────────────
	   یک عنصر، دو جای نشستن. در دسکتاپ کارتی در ستون کناری، در موبایل
	   نواری بالای مسیر راهنما. دو نسخه نمی‌سازیم چون دو نسخه یعنی دو
	   وضعیت «ذخیره‌شده» که می‌توانند از هم دور شوند.
	   ──────────────────────────────────────────────────────────────── */

	var bar = document.querySelector( '[data-tp-actionbar]' );

	if ( bar ) {

		var home   = bar.parentNode;
		var anchor = document.querySelector( '.crumb' );
		var narrow = window.matchMedia( '(max-width: 720px)' );

		var place = function () {

			if ( narrow.matches ) {

				if ( anchor && bar.nextSibling !== anchor ) {
					anchor.parentNode.insertBefore( bar, anchor );
				}

				bar.classList.add( 'tp-actionbar--bar' );

			} else {

				if ( bar.parentNode !== home ) {
					home.appendChild( bar );
				}

				bar.classList.remove( 'tp-actionbar--bar' );
			}
		};

		place();

		if ( narrow.addEventListener ) {
			narrow.addEventListener( 'change', place );
		} else if ( narrow.addListener ) {
			narrow.addListener( place );
		}

		/* ── پیام کوتاه ─────────────────────────────────────────────── */

		var note = bar.querySelector( '.tp-act__note' );

		var say = function ( text ) {

			if ( ! note ) {
				return;
			}

			note.textContent = text;

			window.setTimeout( function () {
				if ( note.textContent === text ) {
					note.textContent = '';
				}
			}, 2600 );
		};

		/* ── اشتراک ─────────────────────────────────────────────────── */

		var share = bar.querySelector( '[data-tp-share]' );

		if ( share ) {

			share.addEventListener( 'click', function () {

				var data = { title: document.title, url: location.href };

				if ( navigator.share ) {
					navigator.share( data ).catch( function () {} );
					return;
				}

				if ( navigator.clipboard ) {
					navigator.clipboard.writeText( location.href ).then( function () {
						say( 'نشانی کپی شد.' );
					} );
				}
			} );
		}

		/* ── ذخیره ──────────────────────────────────────────────────
		   وضعیت در HTML کش‌شده نمی‌آید؛ اینجا خوانده و نوشته می‌شود.
		   نقطهٔ REST هنوز نیامده، پس فعلاً فقط وضعیت بصری عوض می‌شود.
		   ──────────────────────────────────────────────────────────── */

		var save = bar.querySelector( '[data-tp-save]' );

		if ( save ) {

			save.addEventListener( 'click', function () {

				var on = save.getAttribute( 'aria-pressed' ) === 'true';

				save.setAttribute( 'aria-pressed', on ? 'false' : 'true' );
				say( on ? 'از فهرست شما برداشته شد.' : 'در حساب شما ذخیره شد.' );
			} );
		}
	}

	/* ── نوار بخش‌ها ────────────────────────────────────────────────
	   بخش فعال از روی موقعیت واقعی تعیین می‌شود، نه از روی کلیک آخر.
	   ──────────────────────────────────────────────────────────────── */

	var snav = document.querySelector( '.tp-snav' );

	if ( snav ) {

		var links = [].slice.call( snav.querySelectorAll( 'a' ) );
		var lock  = 0;

		var mark = function ( id ) {
			links.forEach( function ( a ) {
				a.classList.toggle( 'is-active', a.getAttribute( 'href' ) === '#' + id );
			} );
		};

		var pick = function () {

			if ( Date.now() < lock ) {
				return;
			}

			var best = null;
			var top  = -Infinity;

			links.forEach( function ( a ) {

				var el = document.getElementById( ( a.getAttribute( 'href' ) || '' ).slice( 1 ) );

				if ( ! el ) {
					return;
				}

				var y = el.getBoundingClientRect().top;

				if ( y <= 120 && y > top ) {
					top  = y;
					best = el.id;
				}
			} );

			if ( best ) {
				mark( best );
			}
		};

		links.forEach( function ( a ) {
			a.addEventListener( 'click', function () {
				mark( ( a.getAttribute( 'href' ) || '' ).slice( 1 ) );
				lock = Date.now() + 1400;
			} );
		} );

		var waiting = false;

		window.addEventListener( 'scroll', function () {

			if ( waiting ) {
				return;
			}

			waiting = true;

			window.requestAnimationFrame( function () {
				pick();
				waiting = false;
			} );
		}, { passive: true } );

		pick();
	}

	/* ── دکمهٔ «مورد دیگر» ──────────────────────────────────────────
	   تا وقتی نقطهٔ REST نیامده، دکمه به صفحهٔ فهرست کامل می‌رود نه
	   اینکه بی‌صدا کاری نکند. دکمه‌ای که هیچ نمی‌کند بدتر از نبودنش است.
	   ──────────────────────────────────────────────────────────────── */

	Array.prototype.forEach.call( document.querySelectorAll( '[data-tp-more]' ), function ( button ) {

		button.addEventListener( 'click', function () {
			button.disabled = true;
			button.textContent = 'در دست ساخت';
		} );
	} );

	/* ── سه ناحیهٔ بدون داده ─────────────────────────────────────────
	   نوار پایین موبایل · برگهٔ بخش‌ها · دو مودال.  P5-D192

	   هر سه یک الگوی باز/بسته دارند، پس یک کنترل‌کننده کافی است:
	   ‏[open] روی خود عنصر، Escape و کلیک روی پس‌زمینه می‌بندد، و فوکوس
	   به دکمه‌ای که بازش کرد برمی‌گردد.
	   ──────────────────────────────────────────────────────────────── */

	( function () {

		var opener = null;

		function open( el, from ) {

			if ( ! el ) {
				return;
			}

			opener = from || null;
			el.setAttribute( 'open', '' );

			/* مرجع `body` را قفل می‌کند؛ `documentElement` هم می‌ماند چون
			   بعضی قالب‌ها پیمایش را روی آن می‌گذارند.  P5-D218 */
			document.documentElement.style.overflow = 'hidden';
			document.body.style.overflow = 'hidden';

			var focusable = el.querySelector( 'button, a[href]' );

			if ( focusable ) {
				focusable.focus();
			}
		}

		function closeAll() {

			/*
			 * نمای تک‌عکس اول بسته می‌شود، نه کل گالری.  P5-D218
			 *
			 * کاربر که از عکس کامل برمی‌گردد، انتظار دارد به شبکهٔ گالری
			 * برسد نه به صفحه. یک پله عقب، نه دو تا.
			 */
			var solo = document.querySelector( '.tp-gmodal__solo[open]' );

			if ( solo ) {
				solo.removeAttribute( 'open' );
				var img = solo.querySelector( 'img' );
				if ( img ) { img.removeAttribute( 'src' ); }
				return;
			}

			Array.prototype.forEach.call(
				document.querySelectorAll( '.tp-sheet[open], .tp-modal[open], .tp-gmodal[open]' ),
				function ( el ) { el.removeAttribute( 'open' ); }
			);

			document.documentElement.style.overflow = '';
			document.body.style.overflow = '';

			if ( opener ) {
				opener.focus();
				opener = null;
			}
		}

		document.addEventListener( 'click', function ( event ) {

			if ( ! event.target || ! event.target.closest ) {
				return;
			}

			if ( event.target.closest( '[data-tp-close]' ) ) {
				closeAll();
				return;
			}

			var sheet = event.target.closest( '[data-tp-sheet-open]' );

			if ( sheet ) {
				open( document.getElementById( 'tpSheet' ), sheet );
				return;
			}

			var map = event.target.closest( '[data-tp-map-open]' );

			if ( map ) {
				open( document.getElementById( 'tpMapModal' ), map );
				return;
			}

			var gallery = event.target.closest( '[data-tp-gallery-open]' );

			if ( gallery ) {
				open( document.getElementById( 'tpGalleryModal' ), gallery );
				return;
			}

			/* کاشی گالری ⇒ نمای تک‌عکس، با همان شاسی.  P5-D218 */
			var tile = event.target.closest( '.tp-gmodal__grid img' );

			if ( tile ) {

				var solo = document.getElementById( 'tpGallerySolo' );
				var big  = solo ? solo.querySelector( 'img' ) : null;

				if ( solo && big ) {
					/* بزرگ‌ترین نسخه‌ای که خودِ کاشی می‌شناسد — بی‌درخواست تازه */
					big.src = tile.currentSrc || tile.src;
					big.alt = tile.alt || '';
					solo.setAttribute( 'open', '' );
					var x = solo.querySelector( '[data-tp-close]' );
					if ( x ) { x.focus(); }
				}
				return;
			}

			/* پیوند داخل برگه، خودِ برگه را می‌بندد تا مقصد دیده شود */
			if ( event.target.closest( '.tp-sheet__p a' ) ) {
				closeAll();
			}
		} );

		document.addEventListener( 'keydown', function ( event ) {

			if ( 'Escape' === event.key ) {
				closeAll();
			}
		} );

		/* میان‌برهای نوار پایین */
		var mnav = document.querySelector( '.tp-mnav' );

		if ( ! mnav ) {
			return;
		}

		mnav.addEventListener( 'click', function ( event ) {

			var button = event.target.closest ? event.target.closest( '[data-tp-go]' ) : null;

			if ( ! button ) {
				return;
			}

			var key = button.getAttribute( 'data-tp-go' );

			if ( 'top' === key ) {
				window.scrollTo( { top: 0, behavior: 'smooth' } );
				return;
			}

			if ( 'save' === key ) {
				var save = document.querySelector( '[data-tp-save]' );
				if ( save ) { save.click(); }
				return;
			}

			var target = document.getElementById( key );

			if ( target ) {
				target.scrollIntoView( { behavior: 'smooth', block: 'start' } );
			}
		} );
	}() );

	/* ── نوار اسلایدر: قبلی و بعدی ──────────────────────────────────
	 *
	 * یک پله برابر یک کارت است، نه یک عدد ثابت: عرض کارت با نقطهٔ شکست
	 * عوض می‌شود و پله‌ی ثابت روی موبایل یا نصفه می‌ماند یا از روی کارت
	 * می‌پرد.
	 *
	 * جهت در RTL وارونه است و `scrollLeft` منفی می‌شود؛ برای همین
	 * به‌جای علامت، از `scrollBy` با مقدار منطقی استفاده می‌کنیم و
	 * مرورگر خودش راستی‌چپی را حل می‌کند.
	 */
	( function () {

		function stepOf( slider ) {
			var card = slider.firstElementChild;
			var gap = parseFloat( getComputedStyle( slider ).columnGap || '0' ) || 0;
			return card ? card.getBoundingClientRect().width + gap : slider.clientWidth * 0.8;
		}

		function sync( slider, bar ) {

			var prev = bar.querySelector( '[data-tp-slide="prev"]' );
			var next = bar.querySelector( '[data-tp-slide="next"]' );
			var max = slider.scrollWidth - slider.clientWidth;
			var at = Math.abs( slider.scrollLeft );

			/* یک پیکسل رواداری — گِردکردن زیرپیکسلی وگرنه دکمه را
			   همیشه فعال نگه می‌دارد */
			if ( prev ) { prev.disabled = at <= 1; }
			if ( next ) { next.disabled = at >= max - 1; }
		}

		document.addEventListener( 'click', function ( event ) {

			var button = event.target.closest( '[data-tp-slide]' );

			if ( ! button ) { return; }

			var slider = document.getElementById( button.getAttribute( 'data-tp-for' ) );

			if ( ! slider ) { return; }

			var step = stepOf( slider );

			slider.scrollBy( {
				left: 'next' === button.getAttribute( 'data-tp-slide' ) ? step : -step,
				behavior: 'smooth'
			} );
		} );

		var bars = document.querySelectorAll( '.tp-slider-bar' );

		for ( var i = 0; i < bars.length; i++ ) {

			( function ( bar ) {

				var one = bar.querySelector( '[data-tp-slide]' );
				if ( ! one ) { return; }

				var slider = document.getElementById( one.getAttribute( 'data-tp-for' ) );
				if ( ! slider ) { return; }

				sync( slider, bar );
				slider.addEventListener( 'scroll', function () { sync( slider, bar ); }, { passive: true } );
				window.addEventListener( 'resize', function () { sync( slider, bar ); }, { passive: true } );

			}( bars[ i ] ) );
		}
	}() );
}() );
