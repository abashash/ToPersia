<?php
/**
 * پل خلاصه‌ساز به هستۀ ToPersia — SPRINT-4.4 فاز ۲ (P5-D249 · P5-D250 · ۲٫۷).
 *
 * هسته اگر هست:
 *   — سرویس `ai.text` در «سرویس‌های خارجی» هسته پیکربندی می‌شود. ارائه‌دهنده‌های
 *     خلاصه‌ساز (DeepSeek، OpenAI، Grok، Perplexity، Claude، Azure، سازگار با
 *     OpenAI) این‌جا آداپتور همان سرویس ثبت می‌شوند؛ Gemini آداپتور خودِ هسته است.
 *   — موتور پیش‌فرض و دما از همان لایه خوانده می‌شود، اگر سطرش ذخیره شده؛ وگرنه
 *     تنظیم خودِ خلاصه‌ساز (تا «انتقال»). تنظیم قدیمی پاک نمی‌شود.
 *   — تولید از کش مرکزی می‌گذرد با انبارۀ همین جدول خلاصه‌ها (تکراری ساخته
 *     نمی‌شود) و هش محتوا؛ ویرایش پست خروجی را پاک نمی‌کند، کهنه علامت می‌زند.
 *   — هش محتوای هسته فیلدهای ورودیِ خلاصه‌ساز را هم می‌گیرد (نام‌ها، خلاصۀ
 *     کوتاه، متن مرور، …) — FIELDMAP ِ هستۀ نمایش آن‌ها را ندارد، و بی این
 *     ویرایش متن مرور خلاصه را کهنه نمی‌کرد.
 *
 * هسته نیست: همان رفتار ۱٫۱٫۱.
 */

defined( 'ABSPATH' ) || exit;

class TP_AI_Core_Bridge {

	/** آداپتورِ هسته برای Gemini — بقیه با پیشوند «tpas-». */
	const CORE_GEMINI = 'gemini';

	public static function init() {
		add_filter( 'topersia_service_adapters', array( __CLASS__, 'adapters' ), 10 );
		add_filter( 'topersia_services_legacy', array( __CLASS__, 'legacy' ), 10 );
		add_filter( 'topersia_content_hash_fields', array( __CLASS__, 'hash_fields' ), 20 );
	}

	/**
	 * فیلدهای هش محتوا: ورودی‌های خلاصه‌ساز به فهرست افزوده می‌شوند. تهی
	 * (null) یعنی «هر متای بی‌زیرخط» — همان می‌ماند، که این‌ها را هم دارد.
	 *
	 * @param array|null $keys فهرست تا این‌جا.
	 * @return array|null
	 */
	public static function hash_fields( $keys ) {
		return is_array( $keys ) ? array_values( array_unique( array_merge( $keys, TP_AI_Context::input_fields() ) ) ) : $keys;
	}

	/** هسته و لایۀ سرویس‌ها در دسترس است؟ */
	public static function available() {
		return function_exists( 'topersia_api' );
	}

	/** کش مرکزی در دسترس است؟ */
	public static function cache_available() {
		return function_exists( 'topersia_cache_remember' ) && function_exists( 'topersia_content_hash' );
	}

	/** شناسۀ آداپتور یک ارائه‌دهندۀ خلاصه‌ساز. */
	public static function adapter_for( $provider ) {
		return self::CORE_GEMINI === $provider ? self::CORE_GEMINI : 'tpas-' . $provider;
	}

	/** ارائه‌دهندۀ خلاصه‌ساز یک آداپتور، یا تهی. */
	public static function provider_for( $adapter ) {

		$adapter   = (string) $adapter;
		$providers = TP_AI_Options::providers();

		if ( self::CORE_GEMINI === $adapter ) {
			return 'gemini';
		}

		if ( 0 === strpos( $adapter, 'tpas-' ) && isset( $providers[ substr( $adapter, 5 ) ] ) ) {
			return substr( $adapter, 5 );
		}

		return '';
	}

	/** آداپتورهای ai.text از ارائه‌دهنده‌های خلاصه‌ساز (جز Gemini). */
	public static function adapters( $adapters ) {

		foreach ( TP_AI_Options::providers() as $id => $p ) {

			if ( self::CORE_GEMINI === $id ) {
				continue;
			}

			$adapters[ self::adapter_for( $id ) ] = array(
				'service'         => 'ai.text',
				'label'           => $p['label'] . ' — خلاصه‌ساز',
				'needs_key'       => true,
				'key_const'       => 'TOPERSIA_' . strtoupper( $id ) . '_API_KEY',
				'endpoint'        => (string) $p['url'],
				'model'           => (string) $p['model'],
				'free_commercial' => true,
				'doc'             => 'topersia-ai-summarizer · TP_AI_Options::providers()',
				'test'            => array( __CLASS__, 'layer_test' ),
			);
		}

		return $adapters;
	}

	/** سطر موتورِ خلاصه‌ساز از پیکربندی لایه. */
	public static function engine_from( array $cfg ) {

		$provider = self::provider_for( isset( $cfg['provider'] ) ? $cfg['provider'] : '' );

		if ( '' === $provider ) {
			return null;
		}

		return array(
			'id'       => 'topersia_api',
			'provider' => $provider,
			'api_key'  => isset( $cfg['key'] ) ? (string) $cfg['key'] : '',
			'model'    => isset( $cfg['model'] ) ? (string) $cfg['model'] : '',
			'base_url' => isset( $cfg['endpoint'] ) ? (string) $cfg['endpoint'] : '',
		);
	}

	/**
	 * موتور از لایه — فقط اگر سطر ai.text ذخیره شده، روشن است و کلید دارد.
	 *
	 * سطری که «انتقال» فقط با دو سقف روزانۀ هستۀ نمایش ساخته (خلاصه‌ساز کلیدی
	 * نداشت)، موتور نیست: بی این شرط، خلاصه‌ساز به‌جای موتور داخلی یک Gemini
	 * بی‌کلید می‌گرفت. خاموش با پرچم تجاری هم نه.
	 *
	 * @return array|null
	 */
	public static function engine() {

		if ( ! self::available() ) {
			return null;
		}

		$cfg = topersia_api( 'ai.text' );

		if ( empty( $cfg['configured'] ) || empty( $cfg['enabled'] ) || '' === (string) $cfg['key'] || in_array( $cfg['status'], array( 'nokey', 'off' ), true ) ) {
			return null;
		}

		return self::engine_from( $cfg );
	}

	/**
	 * دما: عدد اعشاری ۰ تا ۲ — از لایه اگر ذخیره شده، وگرنه تنظیم خلاصه‌ساز.  ۲٫۷
	 */
	public static function temperature() {

		if ( self::available() ) {
			$cfg = topersia_api( 'ai.text' );
			if ( ! empty( $cfg['configured'] ) && isset( $cfg['extra']['temperature'] ) && '' !== (string) $cfg['extra']['temperature'] ) {
				return TP_AI_Options::sanitize_temperature( $cfg['extra']['temperature'] );
			}
		}

		return TP_AI_Options::sanitize_temperature( TP_AI_Options::get_field( 'internal_temperature', 0.3 ) );
	}

	/**
	 * تنظیم قدیمی برای «انتقال»: موتور پیش‌فرض خودِ خلاصه‌ساز و دما.
	 * کلید فقط درون همین درخواست از اینجا به هسته می‌رود و آن‌جا رمز می‌شود.
	 */
	public static function legacy( $legacy ) {

		$engine = TP_AI_Options::legacy_engine();

		if ( ! $engine || empty( $engine['provider'] ) || empty( $engine['api_key'] ) ) {
			return $legacy;
		}

		$row = array(
			'provider' => self::adapter_for( (string) $engine['provider'] ),
			'key'      => (string) $engine['api_key'],
			'model'    => isset( $engine['model'] ) ? (string) $engine['model'] : '',
			'endpoint' => in_array( $engine['provider'], array( 'custom', 'azure' ), true ) && ! empty( $engine['base_url'] ) ? (string) $engine['base_url'] : '',
			'extra'    => array( 'temperature' => (string) TP_AI_Options::sanitize_temperature( TP_AI_Options::get_field( 'internal_temperature', 0.3 ) ) ),
		);

		$legacy['ai.text'] = array_merge( isset( $legacy['ai.text'] ) ? (array) $legacy['ai.text'] : array(), $row );

		return $legacy;
	}

	/**
	 * آزمون اتصال هسته برای آداپتورهای خلاصه‌ساز — یک پرسش هشت‌توکنی.
	 * فقط کد و نوع خطا برمی‌گردد، نه متن پاسخ ارائه‌دهنده (که گاه تکه‌ای از
	 * کلید را بازمی‌گرداند).
	 */
	public static function layer_test( $cfg ) {

		$engine = self::engine_from( (array) $cfg );

		if ( ! $engine ) {
			return array( 'ok' => false, 'message' => 'آداپتور ناشناخته' );
		}

		$r = TP_AI_API::test_key( $engine );

		return ! empty( $r['ok'] )
			? array( 'ok' => true, 'message' => 'پاسخ داد' )
			: array( 'ok' => false, 'message' => 'خطا: ' . ( isset( $r['error'] ) ? sanitize_key( (string) $r['error'] ) : 'نامعلوم' ) );
	}

	/* ── کش مرکزی ─────────────────────────────────────────────────── */

	/** متای هشی که خروجی با آن ساخته شد. */
	public static function hash_key( $type, $lang ) {
		return '_tpas_hash_' . sanitize_key( $type ) . '_' . sanitize_key( $lang );
	}

	/**
	 * انبارۀ کش مرکزی روی جدول خلاصه‌ها — همان ردیف یکتای (پست، نوع، زبان).
	 *
	 * @return array{get:callable,put:callable}
	 */
	public static function store( $post_id, $type, $lang ) {

		return array(
			'get' => function () use ( $post_id, $type, $lang ) {
				$row = TP_AI_DB::get_summary( $post_id, $type, $lang );
				if ( ! $row || '' === trim( (string) $row->content ) ) {
					return null;
				}
				/* ردیفِ پیش از ۱٫۲٫۰ هش ندارد؛ آن نسخه‌ها با هر ویرایش پاک می‌شدند، پس
				   ردیفی که مانده با محتوای امروز ساخته شده — همان هش امروز */
				$hash = (string) get_post_meta( $post_id, self::hash_key( $type, $lang ), true );
				return array(
					'value'       => (string) $row->content,
					'meta'        => array( 'provider' => (string) $row->provider, 'model' => (string) $row->model ),
					'hash'        => '' !== $hash ? $hash : topersia_content_hash( $post_id ),
					'fresh_until' => 0,
					'created'     => strtotime( (string) $row->updated_at ),
				);
			},
			'put' => function ( $key, $envelope ) use ( $post_id, $type, $lang ) {
				$meta = isset( $envelope['meta'] ) ? (array) $envelope['meta'] : array();
				TP_AI_DB::save_summary( $post_id, $type, $lang, (string) $envelope['value'], isset( $meta['provider'] ) ? (string) $meta['provider'] : '', isset( $meta['model'] ) ? (string) $meta['model'] : '' );
				update_post_meta( $post_id, self::hash_key( $type, $lang ), (string) $envelope['hash'] );
			},
		);
	}

	/** آیا خروجی ذخیره‌شدۀ این پست کهنه است (هش محتوا عوض شده)؟ */
	public static function is_stale( $post_id, $type, $lang ) {

		if ( ! self::cache_available() || ! $post_id ) {
			return false;
		}

		$hash = (string) get_post_meta( $post_id, self::hash_key( $type, $lang ), true );

		return function_exists( 'topersia_cache_is_stale' ) ? topersia_cache_is_stale( $post_id, $hash ) : false;
	}
}
