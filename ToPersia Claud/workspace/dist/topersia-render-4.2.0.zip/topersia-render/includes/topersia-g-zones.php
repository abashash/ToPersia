<?php
/**
 * ToPersia — نواحی نمایش دستهٔ G
 *
 * پانزده شورت‌کد که محتوای هر ناحیهٔ صفحهٔ موجودیت جغرافیایی را می‌سازند.
 *
 * ── مرز معماری ────────────────────────────────────────────────────────
 * المنتور اسکلت چیدمان می‌سازد. این فایل محتوای هر ناحیه را تولید می‌کند.
 * المنتور نباید ۵۷ متا و ۳۴ رابطه را بشناسد؛ اگر بشناسد، هر تغییر داده
 * یعنی ویرایش دستی قالب و شکستن قاعدهٔ تک‌تولیدکنندهٔ P5-D145 — چون همان
 * داده باید در JSON-LD هم برود.
 *
 * ── قواعد ثابت ────────────────────────────────────────────────────────
 * هر بخش بدون داده کامل ناپدید می‌شود؛ سرفصل خالی نمی‌ماند.
 * عدد با رقم فارسی و جداکنندهٔ ٬ · سال بدون جداکننده · لاتین مونو و LTR.
 * هیچ رنگ ثابتی اینجا نوشته نمی‌شود؛ رنگ از توکن‌های --tp-* می‌آید.
 * letter-spacing روی متن فارسی ممنوع است.
 * دادهٔ زنده — هوا و وضعیت ذخیره — در HTML کش‌شده نمی‌آید.
 *
 * @package topersia-render
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* =========================================================================
   ۱ — ابزارهای پایه
   ========================================================================= */

/** شناسهٔ پست جاری، با احترام به حلقهٔ المنتور و JetEngine. */
if ( ! function_exists( 'topersia_g_pid' ) ) {
	function topersia_g_pid( $atts = array() ) {

		if ( ! empty( $atts['id'] ) ) {
			return absint( $atts['id'] );
		}

		if ( function_exists( 'get_the_ID' ) ) {
			$id = get_the_ID();

			if ( $id ) {
				return absint( $id );
			}
		}

		return 0;
	}
}

/** رقم لاتین به رقم فارسی. */
if ( ! function_exists( 'topersia_g_fa' ) ) {
	function topersia_g_fa( $text ) {

		$latin   = array( '0', '1', '2', '3', '4', '5', '6', '7', '8', '9' );
		$persian = array( '۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹' );

		return str_replace( $latin, $persian, (string) $text );
	}
}

/**
 * جداکنندهٔ هزارگان با U+066C.
 *
 * فقط روی بخش صحیح اعمال می‌شود؛ بخش اعشاری دست‌نخورده می‌ماند.
 */
if ( ! function_exists( 'topersia_g_sep' ) ) {
	function topersia_g_sep( $number ) {

		$raw = trim( (string) $number );

		if ( '' === $raw ) {
			return '';
		}

		$sign = '';

		if ( '-' === substr( $raw, 0, 1 ) ) {
			$sign = '-';
			$raw  = substr( $raw, 1 );
		}

		$parts    = explode( '.', $raw, 2 );
		$integer  = preg_replace( '/[^0-9]/', '', $parts[0] );
		$fraction = isset( $parts[1] ) ? preg_replace( '/[^0-9]/', '', $parts[1] ) : '';

		if ( '' === $integer ) {
			return (string) $number;
		}

		$grouped = '';
		$length  = strlen( $integer );

		for ( $i = 0; $i < $length; $i++ ) {

			if ( $i > 0 && 0 === ( ( $length - $i ) % 3 ) ) {
				$grouped .= '٬';
			}

			$grouped .= $integer[ $i ];
		}

		return $sign . $grouped . ( '' !== $fraction ? '.' . $fraction : '' );
	}
}

/**
 * آیا این مقدار «پر» است؟
 *
 * قطبیت عمدی: هر چیزی جز خالی و «نادرست صریح»، پر است. شکست باید به سمت
 * نمایش باشد نه ناپدیدشدن — همان قاعده‌ای که topersia_active_rows دارد.
 */
if ( ! function_exists( 'topersia_g_filled' ) ) {
	function topersia_g_filled( $value ) {

		if ( is_array( $value ) ) {
			return ! empty( $value );
		}

		$value = trim( (string) $value );

		if ( '' === $value ) {
			return false;
		}

		return ! in_array( $value, array( '0', 'false', 'no', 'off' ), true );
	}
}

/** آیا این سوییچر روشن است؟ */
if ( ! function_exists( 'topersia_g_flag_on' ) ) {
	function topersia_g_flag_on( $value ) {

		if ( is_bool( $value ) ) {
			return $value;
		}

		$value = strtolower( trim( (string) $value ) );

		return in_array( $value, array( '1', 'true', 'yes', 'on' ), true );
	}
}

/** متای خام — بدون پاک‌سازی، چون ریپیتر و گالری آرایه‌اند. */
if ( ! function_exists( 'topersia_g_raw' ) ) {
	function topersia_g_raw( $post_id, $key ) {

		if ( ! $post_id || ! function_exists( 'get_post_meta' ) ) {
			return '';
		}

		return get_post_meta( $post_id, $key, true );
	}
}

/** متن ساده و امن. */
if ( ! function_exists( 'topersia_g_text' ) ) {
	function topersia_g_text( $post_id, $key ) {

		$value = topersia_g_raw( $post_id, $key );

		if ( is_array( $value ) || is_object( $value ) ) {
			return '';
		}

		return trim( wp_strip_all_tags( (string) $value ) );
	}
}

/**
 * مقدار یک فیلد، آمادهٔ نمایش، بر پایهٔ «نوع» نه نوع پست.
 *
 * @param string $name نام فیلد.
 * @param mixed  $raw  مقدار خام.
 * @return string HTML
 */
if ( ! function_exists( 'topersia_g_value' ) ) {
	function topersia_g_value( $name, $raw ) {

		$map   = topersia_g_map();
		$field = isset( $map[ $name ] ) ? $map[ $name ] : array( 'kind' => 'text', 'unit' => '' );
		$kind  = isset( $field['kind'] ) ? $field['kind'] : 'text';
		$unit  = isset( $field['unit'] ) ? $field['unit'] : '';

		if ( is_array( $raw ) ) {
			$raw = implode( '، ', array_filter( array_map( 'strval', $raw ) ) );
		}

		$raw = trim( (string) $raw );

		if ( '' === $raw ) {
			return '';
		}

		switch ( $kind ) {

			case 'number':
				$out = topersia_g_fa( topersia_g_sep( $raw ) );

				if ( '' !== $unit ) {
					$out .= ' <i class="tp-u">' . esc_html( $unit ) . '</i>';
				}

				return $out;

			case 'year':
				return topersia_g_fa( preg_replace( '/[^0-9۰-۹]/u', '', $raw ) );

			case 'latin':
				return '<span class="tp-lat" dir="ltr">' . esc_html( $raw ) . '</span>';

			case 'choice':
				$glossary = isset( $field['glossary'] ) ? $field['glossary'] : '';

				return esc_html( topersia_g_glossary_label( $glossary, $raw ) );

			case 'flag':
				return esc_html( isset( $field['label'] ) ? $field['label'] : $raw );
		}

		return esc_html( $raw );
	}
}

/**
 * پوستهٔ یک بخش. بدنهٔ خالی یعنی هیچ خروجی — نه سرفصل خالی.
 */
if ( ! function_exists( 'topersia_g_section' ) ) {
	function topersia_g_section( $id, $title, $kicker, $body, $class = 'tp-rail-card', $body_style = '', $after = '' ) {

		$body = trim( (string) $body );

		if ( '' === $body ) {
			return '';
		}

		$head = '';

		if ( '' !== (string) $title ) {

			$head = '<div class="tp-rail-card__head">'
				. '<h3 id="' . esc_attr( $id ) . 'Title">' . esc_html( $title ) . '</h3>'
				. ( '' !== (string) $kicker ? '<span class="tp-k">' . esc_html( $kicker ) . '</span>' : '' )
				. '</div>';
		}

		return '<section id="' . esc_attr( $id ) . '" class="' . esc_attr( $class ) . '"'
			. ( '' !== (string) $title ? ' aria-labelledby="' . esc_attr( $id ) . 'Title"' : '' )
			. '>' . $head . '<div class="tp-rail-card__body"'
			. ( '' !== $body_style ? ' style="' . esc_attr( $body_style ) . '"' : '' )
			. '>' . $body . '</div>' . $after . '</section>';
	}
}

/** فیلدهای یک ناحیه که این پست واقعاً دارد، به ترتیب نقشه. */
if ( ! function_exists( 'topersia_g_zone_fields' ) ) {
	function topersia_g_zone_fields( $post_id, $zone, $exclude = array() ) {

		$out = array();

		foreach ( topersia_g_map() as $name => $field ) {

			if ( ! isset( $field['zone'] ) || $field['zone'] !== $zone ) {
				continue;
			}

			if ( in_array( $name, $exclude, true ) ) {
				continue;
			}

			$raw = topersia_g_raw( $post_id, $name );

			if ( ! topersia_g_filled( $raw ) ) {
				continue;
			}

			$out[ $name ] = $raw;
		}

		return $out;
	}
}

/* =========================================================================
   ۲ — روابط
   ========================================================================= */

/** پیکربندی یک گروه رابطه برای این نوع پست. */
if ( ! function_exists( 'topersia_g_group' ) ) {
	function topersia_g_group( $post_id, $key ) {

		$type = function_exists( 'get_post_type' ) ? get_post_type( $post_id ) : '';
		$map  = topersia_g_relmap();

		if ( ! $type || ! isset( $map[ $type ][ $key ] ) ) {
			return array();
		}

		return $map[ $type ][ $key ];
	}
}

/**
 * نشانیِ عمومی — یا رشتهٔ خالی اگر آن نوع صفحه ندارد.
 *
 * شهرستان موجودیتِ زیرساخت است: قالب و صفحه ندارد (`P5-D172`). پیوند به
 * آن یعنی ۴۰۴ برای کاربر و پیوندِ شکسته برای خزنده. هر جا نشانی خالی
 * برگردد، کارت `<article>` می‌شود نه `<a>`.
 *
 * مبنا خودِ نقشهٔ رابطه است، نه فهرست جدا: نوعی که در `topersia_g_relmap()`
 * مدخل دارد، صفحه دارد. یک منبع حقیقت.  P5-D210
 */
if ( ! function_exists( 'topersia_g_public_url' ) ) {
	function topersia_g_public_url( $post_id ) {

		$type = function_exists( 'get_post_type' ) ? get_post_type( $post_id ) : '';
		$map  = topersia_g_relmap();

		if ( '' === $type || ! isset( $map[ $type ] ) ) {
			return '';
		}

		return (string) get_permalink( $post_id );
	}
}

if ( ! function_exists( 'topersia_g_sort_entities' ) ) {
	/**
	 * ترتیب کارت‌های موجودیتِ ماندگار — یک قاعده برای همه.  P5-D211
	 *
	 *   ۱ `display_priority` نزولی
	 *   ۲ جانشین نوع — شهر و روستا: `population` نزولی
	 *   ۳ الفبای فارسی
	 *
	 * `display_priority` هنوز فیلد نیست. این‌جا **ساخته نمی‌شود**: متا
	 * خوانده می‌شود و نبودش صفر حساب می‌شود. روزی که در JetEngine ساخته
	 * شود، بی‌هیچ تغییری در کد اثر می‌گذارد.
	 *
	 * الفبا با `Collator` فارسی است، نه `strcmp`: «آ» و «ا» و «ء» در
	 * بایت‌ها فاصله دارند ولی در الفبا کنار هم‌اند. اگر `intl` نبود،
	 * `strcoll` جای آن می‌نشیند — بدتر از Collator، بهتر از بایت.
	 */
	function topersia_g_sort_entities( $ids ) {

		$ids = array_values( array_unique( array_map( 'absint', (array) $ids ) ) );

		if ( count( $ids ) < 2 ) {
			return $ids;
		}

		$rank = array();

		foreach ( $ids as $one ) {

			$view = topersia_g_view_id( $one );

			$rank[ $one ] = array(
				'priority' => (float) topersia_g_raw( $view, 'display_priority' ),
				'fallback' => (float) topersia_g_raw( $view, 'population' ),
				'name'     => (string) topersia_g_name( $view ),
			);
		}

		$collator = class_exists( 'Collator' ) ? new Collator( 'fa' ) : null;

		usort( $ids, function ( $a, $b ) use ( $rank, $collator ) {

			if ( $rank[ $a ]['priority'] !== $rank[ $b ]['priority'] ) {
				return $rank[ $a ]['priority'] < $rank[ $b ]['priority'] ? 1 : -1;
			}

			if ( $rank[ $a ]['fallback'] !== $rank[ $b ]['fallback'] ) {
				return $rank[ $a ]['fallback'] < $rank[ $b ]['fallback'] ? 1 : -1;
			}

			return $collator
				? (int) $collator->compare( $rank[ $a ]['name'], $rank[ $b ]['name'] )
				: strcoll( $rank[ $a ]['name'], $rank[ $b ]['name'] );
		} );

		return $ids;
	}
}

if ( ! function_exists( 'topersia_g_chain_ids' ) ) {
	/**
	 * زنجیرهٔ رابطه — چند پله پشت سر هم.  P5-D210
	 *
	 * استان شهر ندارد؛ شهرستان دارد. ولی شهرستان موجودیتِ زیرساخت است و
	 * صفحه ندارد (`P5-D172`)، پس آنچه روی صفحهٔ استان باید بیاید شهرهای
	 * آن است: ۷۲ (استان→شهرستان) و بعد ۷۳ (شهرستان→شهر).
	 *
	 * هر پله روی **همهٔ** نتیجه‌های پلهٔ قبل اجرا می‌شود و تکراری‌ها یک‌بار
	 * می‌مانند — دو شهرستان می‌توانند به یک شهر وصل باشند.
	 *
	 * @param array $chain فهرست مرتبِ spec ها.
	 * @return array شناسه‌ها.
	 */
	function topersia_g_chain_ids( $post_id, $chain ) {

		if ( ! is_array( $chain ) || ! $chain ) {
			return array();
		}

		$cur = array( absint( $post_id ) );

		foreach ( $chain as $spec ) {

			$next = array();

			foreach ( $cur as $one ) {
				foreach ( topersia_g_rel_ids( $one, array( $spec ) ) as $found ) {
					$next[ $found ] = $found;
				}
			}

			$cur = array_values( $next );

			if ( ! $cur ) {
				return array();
			}
		}

		return $cur;
	}
}

/**
 * شناسه‌های طرف مقابل یک یا چند رابطه.
 *
 * جهت از export گرفته می‌شود، نه از سند روابط.  P5-D170
 */
if ( ! function_exists( 'topersia_g_rel_ids' ) ) {
	function topersia_g_rel_ids( $post_id, $rels ) {

		$ids = array();

		if ( ! is_array( $rels ) || ! function_exists( 'topersia_relation' ) ) {
			return $ids;
		}

		foreach ( $rels as $spec ) {

			$id  = isset( $spec['id'] ) ? absint( $spec['id'] ) : 0;
			$dir = isset( $spec['dir'] ) ? $spec['dir'] : 'children';

			if ( ! $id ) {
				continue;
			}

			$relation = topersia_relation( $id );

			if ( ! $relation ) {
				continue;
			}

			$found = ( 'parents' === $dir )
				? $relation->get_parents( $post_id, 'ids' )
				: $relation->get_children( $post_id, 'ids' );

			if ( empty( $found ) || ! is_array( $found ) ) {
				continue;
			}

			foreach ( $found as $one ) {

				$one = absint( $one );

				if ( $one ) {
					$ids[ $one ] = $one;
				}
			}
		}

		return array_values( $ids );
	}
}

/** شناسه را به نسخهٔ زبان جاری می‌برد. */
if ( ! function_exists( 'topersia_g_view_id' ) ) {
	function topersia_g_view_id( $post_id ) {

		if ( ! function_exists( 'apply_filters' ) ) {
			return $post_id;
		}

		$type = function_exists( 'get_post_type' ) ? get_post_type( $post_id ) : '';

		if ( ! $type ) {
			return $post_id;
		}

		$view = apply_filters( 'wpml_object_id', $post_id, $type, true );

		return $view ? absint( $view ) : absint( $post_id );
	}
}

/** نام نمایشی یک موجودیت. */
if ( ! function_exists( 'topersia_g_name' ) ) {
	function topersia_g_name( $post_id ) {

		foreach ( array( 'official_name_fa', 'name_fa' ) as $key ) {

			$value = topersia_g_text( $post_id, $key );

			if ( '' !== $value ) {
				return $value;
			}
		}

		return function_exists( 'get_the_title' ) ? (string) get_the_title( $post_id ) : '';
	}
}

/** برچسب نوع موجودیت — «کوه»، «تالاب» — از برچسب مفرد نوع پست. */
if ( ! function_exists( 'topersia_g_kind_label' ) ) {
	function topersia_g_kind_label( $post_id ) {

		$type = function_exists( 'get_post_type' ) ? get_post_type( $post_id ) : '';

		if ( ! $type || ! function_exists( 'get_post_type_object' ) ) {
			return '';
		}

		$object = get_post_type_object( $type );

		if ( ! $object || empty( $object->labels->singular_name ) ) {
			return '';
		}

		return (string) $object->labels->singular_name;
	}
}

/* =========================================================================
   ۳ — تاریخ شمسی
   ========================================================================= */

/**
 * میلادی به شمسی.
 *
 * چرا الگوریتم و نه intl: افزونهٔ intl روی این میزبان تضمین‌شده نیست و
 * وابستگی‌ای که ممکن است نباشد، یعنی تاریخ ناپدید یا خطای مرگبار.
 */
if ( ! function_exists( 'topersia_g_jalali' ) ) {
	function topersia_g_jalali( $gy, $gm, $gd ) {

		$g_days = array( 0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334 );

		$gy2 = ( $gm > 2 ) ? ( $gy + 1 ) : $gy;

		$days = 355666 + ( 365 * $gy ) + ( (int) ( ( $gy2 + 3 ) / 4 ) )
			- ( (int) ( ( $gy2 + 99 ) / 100 ) ) + ( (int) ( ( $gy2 + 399 ) / 400 ) )
			+ $gd + $g_days[ $gm - 1 ];

		$jy   = -1595 + ( 33 * ( (int) ( $days / 12053 ) ) );
		$days %= 12053;

		$jy   += 4 * ( (int) ( $days / 1461 ) );
		$days %= 1461;

		if ( $days > 365 ) {
			$jy   += (int) ( ( $days - 1 ) / 365 );
			$days  = ( $days - 1 ) % 365;
		}

		if ( $days < 186 ) {
			$jm = 1 + (int) ( $days / 31 );
			$jd = 1 + ( $days % 31 );
		} else {
			$jm = 7 + (int) ( ( $days - 186 ) / 30 );
			$jd = 1 + ( ( $days - 186 ) % 30 );
		}

		return array( $jy, $jm, $jd );
	}
}

/** تاریخ فیلد date جت‌انجین — چه timestamp باشد چه Y-m-d — به متن شمسی. */
if ( ! function_exists( 'topersia_g_date_fa' ) ) {
	function topersia_g_date_fa( $value ) {

		$value = trim( (string) $value );

		if ( '' === $value ) {
			return '';
		}

		if ( preg_match( '/^\d{4}-\d{2}-\d{2}/', $value ) ) {
			$gy = (int) substr( $value, 0, 4 );
			$gm = (int) substr( $value, 5, 2 );
			$gd = (int) substr( $value, 8, 2 );
		} elseif ( preg_match( '/^\d{9,11}$/', $value ) ) {
			$gy = (int) gmdate( 'Y', (int) $value );
			$gm = (int) gmdate( 'n', (int) $value );
			$gd = (int) gmdate( 'j', (int) $value );
		} else {
			return '';
		}

		if ( $gm < 1 || $gm > 12 || $gd < 1 || $gd > 31 ) {
			return '';
		}

		$months = array(
			'فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور',
			'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند',
		);

		list( $jy, $jm, $jd ) = topersia_g_jalali( $gy, $gm, $gd );

		return topersia_g_fa( $jd ) . ' ' . $months[ $jm - 1 ] . ' ' . topersia_g_fa( $jy );
	}
}

/* =========================================================================
   ۴ — شورت‌کدهای ناحیه
   ========================================================================= */

/** [tp_hero] — تصویر، نام سه‌زبانه، نام محلی، خلاصه. */
if ( ! function_exists( 'topersia_g_sc_hero' ) ) {
	function topersia_g_sc_hero( $atts = array() ) {

		$pid = topersia_g_pid( $atts );

		if ( ! $pid ) {
			return '';
		}

		$fa = topersia_g_name( $pid );
		$en = topersia_g_text( $pid, 'official_name_en' );
		$ar = topersia_g_text( $pid, 'official_name_ar' );

		if ( '' === $en ) {
			$en = topersia_g_text( $pid, 'name_en' );
		}

		if ( '' === $ar ) {
			$ar = topersia_g_text( $pid, 'name_ar' );
		}

		$local = topersia_g_text( $pid, 'name_local' );
		$alt   = topersia_g_text( $pid, 'alternative_names' );
		$lead  = topersia_g_text( $pid, 'short_summary' );
		$kind  = topersia_g_kind_label( $pid );

		$image = '';
		$hero  = topersia_g_raw( $pid, 'hero_image' );

		if ( topersia_g_filled( $hero ) && function_exists( 'wp_get_attachment_image' ) ) {

			$image = wp_get_attachment_image(
				is_array( $hero ) ? absint( reset( $hero ) ) : absint( $hero ),
				'full',
				false,
				array(
					'class'         => 'tp-hero__img',
					'loading'       => 'eager',
					'fetchpriority' => 'high',
				)
			);
		}

		$names = array();

		if ( '' !== $en ) {
			$names[] = '<span lang="en" dir="ltr">' . esc_html( $en ) . '</span>';
		}

		if ( '' !== $ar ) {
			$names[] = '<em lang="ar">' . esc_html( $ar ) . '</em>';
		}

		$others = array_filter( array( $local, $alt ) );

		$out = '<header class="tp-hero">'
			. '<div class="tp-hero__fallback" aria-hidden="true"></div>'
			. $image
			. '<div class="tp-hero__overlay" aria-hidden="true"></div>'
			. '<div class="tp-wrap tp-hero__in"><div class="tp-hero__copy">';

		/*
		 * eyebrow به زبان صفحه، نه لاتین.  P5-D218
		 *
		 * «PROVINCE» لغو شد: برچسب از واژه‌نامهٔ نوع می‌آید، که زیر WPML
		 * خودش ترجمه‌شده است — فارسی «استان»، انگلیسی «Province»، عربی
		 * «محافظة». یک منبع، سه زبان، بی‌جدول دستی.
		 */
		if ( '' !== $kind ) {
			$out .= '<p class="tp-eyebrow">' . esc_html( $kind ) . '</p>';
		}

		/*
		 * تیتر: پیشوند نوع + نام، از همان واژه‌نامه.
		 *
		 * اگر نامِ ذخیره‌شده خودش با همان پیشوند شروع شده باشد، دوباره
		 * نمی‌آید — «استان استان اصفهان» نه.
		 */
		$title = $fa;

		if ( '' !== $kind && '' !== $fa && 0 !== strpos( $fa, $kind ) ) {
			$title = $kind . ' ' . $fa;
		}

		$out .= '<h1>' . esc_html( $title ) . '</h1>';

		if ( $names ) {
			$out .= '<p class="tp-hero__alt">' . implode( ' · ', $names ) . '</p>';
		}

		if ( $others ) {
			$out .= '<p class="tp-altnames">' . esc_html( implode( ' · ', $others ) ) . '</p>';
		}

		if ( '' !== $lead ) {
			$out .= '<p class="tp-hero__lead">' . esc_html( $lead ) . '</p>';
		}

		return $out . '</div></div></header>';
	}
}

/**
 * [tp_actionbar] — اشتراک · ذخیره · دنبال‌کردن · منبع ترجیحی گوگل.
 *
 * یک عنصر است، نه دو نسخه. جابه‌جایی میان ستون کناری و بالای مسیر راهنما
 * را matchMedia انجام می‌دهد. وضعیت «ذخیره‌شده» عمداً در HTML نمی‌آید چون
 * صفحه کش تمام‌صفحه می‌شود.
 */
if ( ! function_exists( 'topersia_g_sc_actionbar' ) ) {
	function topersia_g_sc_actionbar( $atts = array() ) {

		$pid = topersia_g_pid( $atts );

		if ( ! $pid ) {
			return '';
		}

		$uid = topersia_g_text( $pid, 'entity_uid' );

		$svg = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true">';

		/*
		 * عیناً مرجع: `section#actions` با کلاس حالت کارتی (دسکتاپ)؛ روی
		 * موبایل جاوااسکریپت آن را بالای مسیر راهنما می‌برد و کلاسش را
		 * `tp-actionbar` می‌کند. بی‌جاوااسکریپت هم درست می‌نشیند.  P5-D219
		 *
		 * «دنبال‌کردن» پیوندِ فید است، نه دکمه — Follow کروم از روی فید کار
		 * می‌کند؛ همان‌طور که مرجع نوشته بود. نشانی فید از وردپرس می‌آید.
		 */
		$feed = function_exists( 'get_post_comments_feed_link' ) ? (string) get_post_comments_feed_link( $pid ) : '';

		return '<section id="tp-actions" class="tp-rail-card tp-actionbar tp-actionbar--rail" data-tp-actionbar'
			. ' data-tp-entity="' . esc_attr( $uid ) . '">'
			. '<div class="tp-actions">'
			. '<button type="button" class="tp-act" data-tp-share>' . $svg
			. '<circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/>'
			. '<path d="M8.6 13.5l6.8 4M15.4 6.5l-6.8 4"/></svg>'
			. '<span>' . esc_html__( 'اشتراک', 'topersia' ) . '</span></button>'
			. '<button type="button" class="tp-act" data-tp-save aria-pressed="false">' . $svg
			. '<path d="M6 3h12v18l-6-4.5L6 21z"/></svg>'
			. '<span>' . esc_html__( 'ذخیره', 'topersia' ) . '</span></button>'
			. ( '' !== $feed
				? '<a class="tp-act" href="' . esc_url( $feed ) . '" title="'
					. esc_attr__( 'افزودن به Following کروم', 'topersia' ) . '">' . $svg
					. '<circle cx="6" cy="18" r="2"/><path d="M4 4a16 16 0 0 1 16 16M4 10a10 10 0 0 1 10 10"/></svg>'
					. '<span>' . esc_html__( 'دنبال‌کردن', 'topersia' ) . '</span></a>'
				: '' )
			. '</div>'
			. topersia_g_gps_link()
			. '<p class="tp-act__note" role="status" aria-live="polite"></p>'
			. '</section>';
	}
}

/**
 * منبع ترجیحی گوگل — پیوند، نه دکمه.  P5-D207
 *
 * مرجع بصری `<button>` داشت، ولی این کار یک **ناوبری** است نه کنشِ
 * درون‌صفحه‌ای: کاربر به تنظیمات گوگل می‌رود. با `<a>` کلیک میانی و
 * «باز کردن در برگهٔ تازه» و صفحه‌کلید همه خودبه‌خود کار می‌کنند و
 * هیچ جاوااسکریپتی لازم نیست.
 *
 * اسکریپت رسمی گوگل عمداً نیامده: یک وابستگی بیرونی روی هر صفحهٔ
 * جغرافیا، برای پیوندی که یک آدرس ثابت است.
 *
 * `nofollow` چون توصیهٔ ما به گوگل نیست، و `noopener` چون مقصد بیرونی
 * است. آیکون همان G مرجع است و `aria-hidden` می‌ماند — معنایش در متن
 * پیوند آمده، نه در تصویر.
 */
if ( ! function_exists( 'topersia_g_gps_link' ) ) {
	function topersia_g_gps_link() {

		$icon = '<svg class="tp-g" viewBox="0 0 48 48" aria-hidden="true" focusable="false">'
			. '<path fill="#4285F4" d="M45.1 24.5c0-1.6-.1-3.2-.4-4.7H24v8.9h11.8c-.5 2.7-2 5-4.4 6.6v5.5h7.1c4.2-3.8 6.6-9.5 6.6-16.3z"/>'
			. '<path fill="#34A853" d="M24 46c5.9 0 10.9-2 14.5-5.2l-7.1-5.5c-2 1.3-4.5 2.1-7.4 2.1-5.7 0-10.6-3.9-12.3-9.1H4.4v5.7C8 41.4 15.4 46 24 46z"/>'
			. '<path fill="#FBBC05" d="M11.7 28.3c-.4-1.3-.7-2.7-.7-4.3s.3-3 .7-4.3v-5.7H4.4A22 22 0 0 0 2 24c0 3.6.9 6.9 2.4 9.9l7.3-5.6z"/>'
			. '<path fill="#EA4335" d="M24 10.6c3.2 0 6.1 1.1 8.4 3.3l6.3-6.3C34.9 4 29.9 2 24 2 15.4 2 8 6.6 4.4 13.9l7.3 5.7c1.7-5.2 6.6-9 12.3-9z"/>'
			. '</svg>';

		return '<a class="tp-gps-btn" href="https://www.google.com/preferences/source?q=topersia.com"'
			. ' rel="nofollow noopener" target="_blank">'
			. $icon
			. '<span class="tp-gps-btn__t">' . esc_html__( 'ToPersia را منبع ترجیحی گوگل کنید', 'topersia' ) . '</span>'
			. '<span class="tp-gps-btn__s">' . esc_html__( 'مطالب ما را بیشتر در نتایج گوگل و AI Mode ببینید', 'topersia' ) . '</span>'
			. '</a>';
	}
}

/** [tp_crumbs] — مسیر راهنما از سلسله‌مراتب رابطه. */
if ( ! function_exists( 'topersia_g_sc_crumbs' ) ) {
	function topersia_g_sc_crumbs( $atts = array() ) {

		$pid = topersia_g_pid( $atts );

		if ( ! $pid ) {
			return '';
		}

		$group = topersia_g_group( $pid, 'crumbs' );
		$chain = array();
		$cur   = $pid;

		if ( ! empty( $group['rels'] ) ) {

			foreach ( $group['rels'] as $spec ) {

				$found = topersia_g_rel_ids( $cur, array( $spec ) );

				if ( empty( $found ) ) {
					break;
				}

				$parent = absint( reset( $found ) );

				if ( empty( $spec['skip'] ) ) {
					$chain[] = $parent;
				}

				$cur = $parent;
			}
		}

		$items = array( '<a href="' . esc_url( home_url( '/' ) ) . '">ToPersia</a>' );

		foreach ( array_reverse( $chain ) as $ancestor ) {

			$view = topersia_g_view_id( $ancestor );

			$items[] = '<a href="' . esc_url( get_permalink( $view ) ) . '">'
				. esc_html( topersia_g_name( $view ) ) . '</a>';
		}

		$items[] = '<span aria-current="page">' . esc_html( topersia_g_name( $pid ) ) . '</span>';

		return '<p class="tp-crumb" aria-label="' . esc_attr__( 'مسیر راهنما', 'topersia' ) . '">'
			. implode( '<span>›</span>', $items ) . '</p>';
	}
}

/**
 * آیا این پست کارت «مرکز» دارد؟ یک خانه از چهار خانهٔ آمار را می‌گیرد.
 */
if ( ! function_exists( 'topersia_g_capital_id' ) ) {
	function topersia_g_capital_id( $post_id ) {

		$group = topersia_g_group( $post_id, 'capital' );

		if ( empty( $group['rels'] ) ) {
			return 0;
		}

		$ids = topersia_g_rel_ids( $post_id, $group['rels'] );

		return empty( $ids ) ? 0 : absint( reset( $ids ) );
	}
}

/**
 * نام فیلدهایی که کارت آمار مصرف می‌کند.
 *
 * تولیدکنندهٔ واحد: کارت آمار این را مصرف می‌کند و کارت حقایق همین را
 * کنار می‌گذارد. اگر هر کدام حساب خودش را می‌کرد، فیلدی که «مرکز» جایش
 * را تنگ کرده بود بی‌صدا از هر دو کارت می‌افتاد — همان اتفاقی که در
 * آزمون T-1 برای climate_type افتاد.
 */
if ( ! function_exists( 'topersia_g_stat_keys' ) ) {
	/**
	 * والدِ مکانیِ بی‌واسطه — همان پلهٔ اولِ مسیر راهنما.
	 *
	 * از همان نقشهٔ `crumbs` می‌آید که `[tp_crumbs]` استفاده می‌کند، نه از
	 * فهرست جدا. پله‌های `skip` (مثل شهرستان — `P5-D172`) رد می‌شوند و
	 * اولین والدِ دیدنی برمی‌گردد.
	 *
	 * @return string نام، یا رشتهٔ خالی.
	 */
	function topersia_g_place_parent( $post_id ) {

		$group = topersia_g_group( $post_id, 'crumbs' );

		if ( empty( $group['rels'] ) ) {
			return '';
		}

		$cur = $post_id;

		foreach ( $group['rels'] as $spec ) {

			$found = topersia_g_rel_ids( $cur, array( $spec ) );

			if ( empty( $found ) ) {
				return '';
			}

			$parent = absint( reset( $found ) );

			if ( empty( $spec['skip'] ) ) {
				return topersia_g_name( topersia_g_view_id( $parent ) );
			}

			$cur = $parent;
		}

		return '';
	}
}

/**
 * پاورقی کارت: والد مکانی · یک واقعیت کلیدی.
 *
 * اگر هیچ‌کدام نبود، خودِ پاورقی هم نیست — نه جعبهٔ خالی، نه جداکنندهٔ
 * بی‌طرف. همان قاعدهٔ ناپدیدشدن که در کل قالب هست.
 */
if ( ! function_exists( 'topersia_g_card_foot' ) ) {
	function topersia_g_card_foot( $item ) {

		/*
		 * پاورقیِ `#places` مرجع: «N جاذبه» و «N رویداد».  P5-D215
		 * هر کدام صفر بود، همان `span` نمی‌آید.
		 */
		if ( isset( $item['counts'] ) ) {

			$spots  = (int) $item['counts']['spots'];
			$events = (int) $item['counts']['events'];

			if ( ! $spots && ! $events ) {
				return '';
			}

			return '<div class="tp-card-slide__foot">'
				. ( $spots ? '<span>' . topersia_g_fa( $spots ) . ' '
					. esc_html__( 'جاذبه', 'topersia' ) . '</span>' : '' )
				. ( $events ? '<span>' . topersia_g_fa( $events ) . ' '
					. esc_html__( 'رویداد', 'topersia' ) . '</span>' : '' )
				. '</div>';
		}

		$place = isset( $item['place'] ) ? (string) $item['place'] : '';
		$fact  = isset( $item['fact'] ) ? (string) $item['fact'] : '';

		if ( '' === $place && '' === $fact ) {
			return '';
		}

		/* پاورقی مرجع دو `span` خالیِ بی‌کلاس است. */
		return '<div class="tp-card-slide__foot">'
			. ( '' !== $place ? '<span>' . esc_html( $place ) . '</span>' : '' )
			. ( '' !== $fact ? '<span>' . esc_html( $fact ) . '</span>' : '' )
			. '</div>';
	}
}

/**
 * برچسب نوعِ اعضای یک گروه — از واژه‌نامه، نه ثابت.  P5-D210
 *
 * «شهر» در متن دکمه نباید سخت‌کد شود: همین شورت‌کد برای روستا و محله و
 * استان هم کار می‌کند. برچسب از نخستین عضو گرفته می‌شود، چون اعضای یک
 * گروه هم‌نوع‌اند.
 */
/**
 * سرفصل بخش — عیناً مرجع: `h2` + `p.lead` + `a.more`.  P5-D215
 *
 * شمارندهٔ «N مورد» در مرجع نیست و برداشته شد.
 *
 * `a.more` فقط وقتی می‌آید که برگهٔ هاب برای آن نوع وجود داشته باشد.
 * چون هنوز هیچ هابی تصمیم نشده، `hub` در نقشه خالی است و این پیوند
 * رندر نمی‌شود — پیوند به صفحه‌ای که نیست، ۴۰۴ است نه ناوبری.
 */
if ( ! function_exists( 'topersia_g_section_head' ) ) {
	function topersia_g_section_head( $group, $entity = '' ) {

		$title = isset( $group['title'] ) ? (string) $group['title'] : '';

		if ( '' === $title ) {
			return '';
		}

		/* متن راهنما نام موجودیت را می‌گیرد، نه رشتهٔ ثابت.  P5-D215 */
		$lead = isset( $group['lead'] ) ? (string) $group['lead'] : '';

		if ( '' !== $lead && false !== strpos( $lead, '%s' ) ) {
			$lead = sprintf( $lead, $entity );
		}
		$hub  = isset( $group['hub'] ) ? (string) $group['hub'] : '';
		$more = isset( $group['more'] ) ? (string) $group['more'] : '';

		return '<div class="tp-section-head"><div>'
			. '<h2>' . esc_html( $title ) . '</h2>'
			. ( '' !== $lead ? '<p class="tp-lead">' . esc_html( $lead ) . '</p>' : '' )
			. '</div>'
			. ( '' !== $hub && '' !== $more
				? '<a class="tp-more" href="' . esc_url( $hub ) . '">' . esc_html( $more ) . '</a>'
				: '' )
			. '</div>';
	}
}

if ( ! function_exists( 'topersia_g_group_kind' ) ) {
	function topersia_g_group_kind( $result ) {

		if ( ! empty( $result['items'][0]['kind'] ) ) {
			return (string) $result['items'][0]['kind'];
		}

		return esc_html__( 'مورد', 'topersia' );
	}
}

/**
 * نوار زیر اسلایدر — راهنما و دو دکمهٔ پیمایش.
 *
 * با یک کارت اصلاً نمی‌آید: دکمهٔ قبلی/بعدی وقتی جایی برای رفتن نیست،
 * فقط سر می‌دواند.
 */
if ( ! function_exists( 'topersia_g_slider_bar' ) ) {
	function topersia_g_slider_bar( $uid, $count ) {

		if ( $count < 2 ) {
			return '';
		}

		/* عیناً مرجع: `span.slider-hint` و دو دکمهٔ بی‌کلاس با data-target/data-dir. */
		return '<div class="tp-slider-bar">'
			. '<span class="tp-slider-hint">' . esc_html__( 'برای کشف موارد بیشتر بکشید', 'topersia' ) . '</span>'
			. '<div class="tp-slider-nav">'
			. '<button type="button" data-target="' . esc_attr( $uid ) . '" data-dir="1"'
			. ' aria-label="' . esc_attr__( 'اسلاید بعدی', 'topersia' ) . '">‹</button>'
			. '<button type="button" data-target="' . esc_attr( $uid ) . '" data-dir="-1"'
			. ' aria-label="' . esc_attr__( 'اسلاید قبلی', 'topersia' ) . '">›</button>'
			. '</div></div>';
	}
}

/**
 * یک واقعیت کلیدی — نخستین فیلدِ ناحیهٔ `card` که مقدار دارد.
 *
 * فهرست دستی ندارد: همان `topersia_g_zone_fields()` را می‌خواند که
 * `[tp_stats]` می‌خواند، پس ترتیبِ اهمیت از نقشهٔ فیلد می‌آید نه از حدس
 * ما، و برای هر نوع پست خودبه‌خود درست است.
 *
 * مختصات و بهترین فصل کنار گذاشته می‌شوند — یکی زیر نقشه می‌نشیند و
 * دیگری در جدول فصل‌ها، و هیچ‌کدام روی کارت معنا نمی‌دهند.
 *
 * @return string مقدارِ قالب‌بندی‌شده، یا رشتهٔ خالی.
 */
if ( ! function_exists( 'topersia_g_key_fact' ) ) {
	function topersia_g_key_fact( $post_id ) {

		$fields = topersia_g_zone_fields( $post_id, 'card', array( 'geo_coordinates', 'best_season' ) );

		foreach ( array_keys( $fields ) as $name ) {

			$raw = topersia_g_raw( $post_id, $name );

			if ( '' === $raw || null === $raw || array() === $raw ) {
				continue;
			}

			$value = trim( wp_strip_all_tags( topersia_g_value( $name, $raw ) ) );

			if ( '' !== $value ) {
				return $value;
			}
		}

		return '';
	}
}

if ( ! function_exists( 'topersia_g_stat_keys' ) ) {
	function topersia_g_stat_keys( $post_id ) {

		$slots = 4 - ( topersia_g_capital_id( $post_id ) ? 1 : 0 );

		$fields = topersia_g_zone_fields( $post_id, 'card', array( 'geo_coordinates', 'best_season' ) );

		/*
		 * ترتیب کارت آمار صریح است، نه ترتیبِ نقشهٔ فیلد.  P5-D208
		 *
		 * خواسته: مرکز · جمعیت · مساحت · اقلیم. با ترتیبِ نقشه،
		 * `province_code` پیش از `climate_type` می‌افتاد و خانهٔ چهارم را
		 * می‌گرفت. کد استان جای خودش کارت حقایق است — و چون آن کارت هرچه
		 * را آمار نبرده نشان می‌دهد، همین‌که از این فهرست بیرون بماند
		 * خودبه‌خود آن‌جا می‌رود.
		 *
		 * فهرست برای هر سیزده نوع پست یکی است؛ هر نوع هرچه را دارد از آن
		 * برمی‌دارد. آنچه نامش این‌جا نیست، به ترتیبِ نقشه ته صف می‌رود —
		 * پس نوع تازه بی‌صدا خالی نمی‌ماند.
		 *
		 * ترتیب از لایهٔ دادهٔ مرجع می‌آید: مرکز · کد · مساحت · جمعیت.
		 * `P5-D208` (مرکز · جمعیت · مساحت · اقلیم) لغو شد.  P5-D215
		 */
		$order = array( 'province_code', 'area_km2', 'population', 'climate_type', 'elevation_m', 'founded_year' );

		$ranked = array();

		foreach ( $order as $name ) {
			if ( isset( $fields[ $name ] ) ) { $ranked[] = $name; }
		}

		foreach ( array_keys( $fields ) as $name ) {
			if ( ! in_array( $name, $ranked, true ) ) { $ranked[] = $name; }
		}

		return array_slice( $ranked, 0, max( 0, $slots ) );
	}
}

/** [tp_stats] — کارت آمار: مرکز (رابطهٔ یک‌به‌یک) + سه حقیقت سرخط. */
if ( ! function_exists( 'topersia_g_sc_stats' ) ) {
	function topersia_g_sc_stats( $atts = array() ) {

		$pid = topersia_g_pid( $atts );

		if ( ! $pid ) {
			return '';
		}

		$cells   = array();
		$capital = topersia_g_capital_id( $pid );

		if ( $capital ) {

			$group = topersia_g_group( $pid, 'capital' );
			$view  = topersia_g_view_id( $capital );

			$cells[] = array(
				isset( $group['title'] ) ? $group['title'] : '',
				'<a href="' . esc_url( get_permalink( $view ) ) . '">'
					. esc_html( topersia_g_name( $view ) ) . '</a>',
			);
		}

		/* مختصات زیر نقشه می‌نشیند و بهترین فصل در جدول فصل‌ها. */
		$map = topersia_g_map();

		foreach ( topersia_g_stat_keys( $pid ) as $name ) {

			$cells[] = array( $map[ $name ]['label'], topersia_g_value( $name, topersia_g_raw( $pid, $name ) ) );
		}

		if ( empty( $cells ) ) {
			return '';
		}

		$out = '';

		foreach ( $cells as $cell ) {

			$out .= '<div class="tp-stat" role="listitem">'
				. '<span class="tp-stat__k">' . esc_html( $cell[0] ) . '</span>'
				. '<b class="tp-stat__v">' . $cell[1] . '</b></div>';
		}

		return '<div class="tp-wrap tp-stats-wrap"><div class="tp-stats" role="list" aria-label="'
			. esc_attr__( 'اطلاعات کلیدی', 'topersia' ) . '">' . $out . '</div></div>';
	}
}

/** [tp_facts] — هر فیلد کارتی که در آمار نیامده، و فهرست جزئیات. */
if ( ! function_exists( 'topersia_g_sc_facts' ) ) {
	function topersia_g_sc_facts( $atts = array() ) {

		$pid = topersia_g_pid( $atts );

		if ( ! $pid ) {
			return '';
		}

		$map  = topersia_g_map();
		$body = '';

		/*
		 * کارت `#geo` مرجع فقط `.geo-grid` است: حقایق کوتاه.  P5-D219
		 *
		 * فیلدهای ناحیهٔ `details` — محدودهٔ جغرافیایی، مرور اقلیم،
		 * زمینهٔ تاریخی، دسترسی — از این کارت برداشته شدند و به
		 * `#overview` رفتند. آن‌ها پاراگراف‌اند، نه حقیقتِ یک‌خطی؛ در
		 * ستون ۳۴۰ پیکسلی خوانده نمی‌شدند.
		 */
		$taken  = array_merge( topersia_g_stat_keys( $pid ), array( 'geo_coordinates', 'best_season' ) );
		$fields = topersia_g_zone_fields( $pid, 'card', $taken );

		if ( $fields ) {

			$grid = '';

			foreach ( $fields as $name => $raw ) {

				$grid .= '<div class="tp-fact"><span>' . esc_html( $map[ $name ]['label'] ) . '</span>'
					. '<b>' . topersia_g_value( $name, $raw ) . '</b></div>';
			}

			$body .= '<div class="tp-geo-grid">' . $grid . '</div>';
		}

		return topersia_g_section( 'tp-geo', 'اطلاعات جغرافیایی', 'GEO', $body );
	}
}

/** [tp_badges] — سوییچرهای درست، جفت‌شده با سالشان. */
if ( ! function_exists( 'topersia_g_sc_badges' ) ) {
	function topersia_g_sc_badges( $atts = array() ) {

		$pid = topersia_g_pid( $atts );

		if ( ! $pid ) {
			return '';
		}

		$body = '';

		foreach ( topersia_g_map() as $name => $field ) {

			if ( 'badge' !== $field['zone'] || 'flag' !== $field['kind'] ) {
				continue;
			}

			if ( ! topersia_g_flag_on( topersia_g_raw( $pid, $name ) ) ) {
				continue;
			}

			$year = '';

			if ( ! empty( $field['year'] ) ) {

				$raw = topersia_g_raw( $pid, $field['year'] );

				if ( topersia_g_filled( $raw ) ) {
					$year = ' <span>· ' . topersia_g_value( $field['year'], $raw ) . '</span>';
				}
			}

			$body .= '<span class="tp-badge">' . esc_html( $field['label'] ) . $year . '</span>';
		}

		if ( '' === $body ) {
			return '';
		}

		return topersia_g_section( 'tp-badges', 'نشان‌ها', 'STATUS', '<div class="tp-badges">' . $body . '</div>' );
	}
}

/**
 * [tp_seasons] — جدول چهار فصل.
 *
 * فیلد best_season یک select تک‌مقداری روی واژه‌نامهٔ ۳۴ است
 * (spring · summer · autumn · winter · all_year) — نه بازهٔ متنی ماه.
 * پس ماه‌های همان فصل روشن می‌شوند و تطبیق زیررشته‌ای انجام نمی‌شود؛
 * «دی» زیررشتهٔ «اردیبهشت» است و آن مسیر یک بار هزینه داده.
 */
if ( ! function_exists( 'topersia_g_sc_seasons' ) ) {
	function topersia_g_sc_seasons( $atts = array() ) {

		$pid = topersia_g_pid( $atts );

		if ( ! $pid ) {
			return '';
		}

		$value = trim( (string) topersia_g_raw( $pid, 'best_season' ) );

		if ( '' === $value ) {
			return '';
		}

		$seasons = array(
			'spring' => array( 'بهار', array( 'فروردین', 'اردیبهشت', 'خرداد' ) ),
			'summer' => array( 'تابستان', array( 'تیر', 'مرداد', 'شهریور' ) ),
			'autumn' => array( 'پاییز', array( 'مهر', 'آبان', 'آذر' ) ),
			'winter' => array( 'زمستان', array( 'دی', 'بهمن', 'اسفند' ) ),
		);

		$all = ( 'all_year' === $value );

		if ( ! $all && ! isset( $seasons[ $value ] ) ) {
			return '';
		}

		$grid = '';

		foreach ( $seasons as $key => $season ) {

			$on    = ( $all || $key === $value );
			$class = 'tp-season tp-season--' . $key . ( $on ? ' tp-has-on' : '' );
			$cells = '<div class="tp-season__h">' . esc_html( $season[0] ) . '</div>';

			foreach ( $season[1] as $month ) {
				$cells .= '<div class="tp-month' . ( $on ? ' tp-is-on' : '' ) . '">' . esc_html( $month ) . '</div>';
			}

			$grid .= '<div class="' . esc_attr( $class ) . '">' . $cells . '</div>';
		}

		$caption = topersia_g_glossary_label( '34', $value );

		$body = '<div class="tp-seasons" role="img" aria-label="'
			. esc_attr( 'بهترین زمان سفر: ' . $caption ) . '">' . $grid . '</div>'
			. '<p class="tp-seasons__cap">' . esc_html( $caption ) . '</p>';

		return topersia_g_section( 'tp-season', 'بهترین زمان سفر', 'WHEN', $body );
	}
}

/**
 * [tp_weather] — هوای سه روز.
 *
 * فقط پوسته و جای خالی. دادهٔ زنده نباید در HTML کش‌شده بیاید، پس پس از
 * بارگذاری از یک نقطهٔ REST با کش نیم‌ساعته خوانده می‌شود. مبنای مکان همان
 * geo_coordinates خود رکورد است؛ فیلد تازه‌ای لازم نیست.
 */
if ( ! function_exists( 'topersia_g_sc_weather' ) ) {
	function topersia_g_sc_weather( $atts = array() ) {

		$pid = topersia_g_pid( $atts );

		if ( ! $pid ) {
			return '';
		}

		$coords = topersia_g_text( $pid, 'geo_coordinates' );

		if ( '' === $coords ) {
			return '';
		}

		$body = '<div class="tp-wx" data-tp-weather data-tp-coords="' . esc_attr( $coords ) . '">'
			. '<div class="tp-wx__day tp-is-load"></div>'
			. '<div class="tp-wx__day tp-is-load"></div>'
			. '<div class="tp-wx__day tp-is-load"></div></div>'
			. '<p class="tp-wx__src">' . esc_html__( 'در حال گرفتن داده…', 'topersia' ) . '</p>';

		return topersia_g_section( 'tp-weather', 'هوای این روزها', 'FORECAST', $body );
	}
}

/** [tp_map] — نقشه با پاپ‌آپ و مختصات زیرش. */
if ( ! function_exists( 'topersia_g_sc_map' ) ) {
	function topersia_g_sc_map( $atts = array() ) {

		$pid = topersia_g_pid( $atts );

		if ( ! $pid ) {
			return '';
		}

		$coords = topersia_g_text( $pid, 'geo_coordinates' );

		if ( '' === $coords ) {
			return '';
		}

		$uid = 'tpmap' . $pid;

		/*
		 * سطر دوم پاپ‌آپ مرجع: «مرکز: شهر اصفهان · ۲۸ شهرستان».  P5-D219
		 * مرکز از رابطهٔ یک‌به‌یکِ `capital` و شمار از گروه `places` — هر
		 * کدام نبود، همان تکه نمی‌آید؛ هیچ‌کدام نبود، سطر نمی‌آید.
		 */
		$pop = array();

		$capital = topersia_g_capital_id( $pid );

		if ( $capital ) {
			$pop[] = sprintf(
				/* translators: %s: نام مرکز */
				__( 'مرکز: %s', 'topersia' ),
				topersia_g_name( topersia_g_view_id( $capital ) )
			);
		}

		$places = topersia_g_group( $pid, 'places' );

		if ( ! empty( $places['rels'] ) ) {

			$ids = topersia_g_rel_ids( $pid, $places['rels'] );

			if ( $ids ) {
				$pop[] = topersia_g_fa( count( $ids ) ) . ' ' . topersia_g_kind_label( topersia_g_view_id( reset( $ids ) ) );
			}
		}

		$body = '<div class="tp-map-inner" data-tp-map data-tp-coords="' . esc_attr( $coords ) . '">'
			. '<svg class="tp-map-svg" viewBox="0 0 320 230" role="img" aria-label="'
			. esc_attr__( 'نمای شماتیک نقشه', 'topersia' ) . '">'
			. '<defs><pattern id="' . esc_attr( $uid ) . '" width="24" height="24" patternUnits="userSpaceOnUse">'
			. '<path d="M24 0H0V24" fill="none" stroke="currentColor" stroke-opacity=".16" stroke-width="1"/>'
			. '</pattern></defs>'
			. '<rect width="320" height="230" fill="url(#' . esc_attr( $uid ) . ')"/>'
			. '<path d="M40 60 C 80 40, 140 50, 190 42 C 240 36, 280 60, 290 100'
			. ' C 296 140, 260 180, 210 190 C 160 200, 100 195, 60 175 C 30 160, 22 110, 40 60 Z"'
			. ' fill="none" stroke="currentColor" stroke-width="1.6" stroke-dasharray="4 3" opacity=".65"/>'
			. '<circle cx="150" cy="118" r="3" fill="currentColor" opacity=".35"/>'
			. '<circle cx="95" cy="90" r="2.4" fill="currentColor" opacity=".3"/>'
			. '<circle cx="220" cy="150" r="2.4" fill="currentColor" opacity=".3"/>'
			. '</svg>'
			. '<div class="tp-map-pop" role="note"><b>' . esc_html( topersia_g_name( $pid ) ) . '</b>'
			. ( $pop ? '<span>' . esc_html( implode( ' · ', $pop ) ) . '</span>' : '' ) . '</div>'
			. '<button class="tp-map-pin" type="button" aria-label="'
			. esc_attr__( 'نمایش اطلاعات نشانگر', 'topersia' ) . '"></button></div>'
			. '<div class="tp-map-coord"><span class="tp-lbl">'
			. esc_html__( 'مختصات مرکز', 'topersia' ) . '</span>'
			. '<span dir="ltr">' . esc_html( $coords ) . '</span></div>';

		/* دکمه در مرجع بیرون از بدنهٔ کارت است، تمام‌عرض و چسبیده به لبه. */
		$after = '<button class="tp-map-btn" type="button" data-tp-map-open>'
			. esc_html__( 'باز کردن نقشهٔ کامل', 'topersia' ) . '</button>';

		return topersia_g_section( 'tp-map', 'نقشه', 'MAP', $body, 'tp-rail-card', 'padding:0', $after );
	}
}

/**
 * سال ثبتِ یک جاذبه — «ثبت ۱۹۷۹» مرجع.  P5-D219
 *
 * فهرست دستی ندارد: هر فیلد نشان که `year` دارد و خودش روشن است، سالش
 * را می‌دهد. نخستینِ مقداردار برنده است.
 *
 * @return string رشتهٔ آمادهٔ چاپ، یا خالی.
 */
if ( ! function_exists( 'topersia_g_listed_year' ) ) {
	function topersia_g_listed_year( $post_id ) {

		foreach ( topersia_g_map() as $name => $field ) {

			if ( empty( $field['year'] ) || 'badge' !== $field['zone'] ) {
				continue;
			}

			if ( ! topersia_g_flag_on( topersia_g_raw( $post_id, $name ) ) ) {
				continue;
			}

			$raw = topersia_g_raw( $post_id, $field['year'] );

			if ( ! topersia_g_filled( $raw ) ) {
				continue;
			}

			return sprintf(
				/* translators: %s: سال ثبت */
				esc_html__( 'ثبت %s', 'topersia' ),
				trim( wp_strip_all_tags( topersia_g_value( $field['year'], $raw ) ) )
			);
		}

		return '';
	}
}

/**
 * یک کارت رابطه.  P5-D215
 *
 * برای `#places` دو چیز فرق می‌کند و هر دو از مرجع می‌آیند:
 *
 *   برچسب   کارت اول «مرکز استان» است، بقیه «شهرستان».
 *   پیوند   شهرستان صفحه ندارد (`P5-D172`)، ولی شهرِ مرکزش دارد —
 *           رابطهٔ ۹۷. اگر نبود، کارت `<article>` می‌شود.
 */
if ( ! function_exists( 'topersia_g_place_item' ) ) {
	function topersia_g_place_item( $view, $key, $is_lead ) {

		$name = topersia_g_name( $view );
		$url  = topersia_g_public_url( $view );

		if ( 'places' !== $key ) {

			/*
			 * پاورقی جاذبه: شهر · سال ثبت.  P5-D219
			 *
			 * مرجع «ثبت ۱۹۷۹» دارد، نه نخستین حقیقتِ کارت. سال از همان
			 * فیلدهای سالِ نشان می‌آید که بخش «نشان‌ها» می‌خواند، پس
			 * هیچ فیلد تازه‌ای لازم نیست. نبود که باشد، همان حقیقت
			 * کلیدیِ همیشگی می‌آید.
			 */
			$fact  = 'attractions' === $key ? topersia_g_listed_year( $view ) : '';
			$place = '';

			if ( '' === $fact ) {
				$fact = topersia_g_key_fact( $view );
			}

			/*
			 * شهرِ جاذبه — از همان چهار رابطه‌ای که جاذبه را به شهر وصل
			 * می‌کنند، در جهت والد. انواع جاذبه در نقشهٔ رابطه مدخل ندارند،
			 * پس `topersia_g_place_parent()` برایشان چیزی پیدا نمی‌کرد و
			 * نیمهٔ اولِ «شهر · سال ثبت» خالی می‌ماند.
			 */
			if ( 'attractions' === $key ) {

				$city = topersia_g_rel_ids( $view, array(
					array( 'id' => 84, 'dir' => 'parents' ),
					array( 'id' => 86, 'dir' => 'parents' ),
					array( 'id' => 88, 'dir' => 'parents' ),
					array( 'id' => 93, 'dir' => 'parents' ),
				) );

				if ( $city ) {
					$place = topersia_g_name( topersia_g_view_id( absint( reset( $city ) ) ) );
				}
			}

			if ( '' === $place ) {
				$place = topersia_g_place_parent( $view );
			}

			return array(
				'kind'  => topersia_g_kind_label( $view ),
				'id'    => $view,
				'name'  => $name,
				'url'   => $url,
				'sum'   => topersia_g_text( $view, 'short_summary' ),
				'place' => $place,
				'fact'  => $fact,
			);
		}

		/* شهرستان خودش صفحه ندارد؛ پیوند به شهرِ مرکزش می‌رود */
		$target = $view;

		if ( ! $is_lead && '' === $url ) {
			$seat = topersia_g_rel_ids( $view, array( array( 'id' => 97, 'dir' => 'children' ) ) );

			if ( $seat ) {
				$target = topersia_g_view_id( absint( reset( $seat ) ) );
				$url    = topersia_g_public_url( $target );
			}
		}

		return array(
			'kind'  => $is_lead
				? esc_html__( 'مرکز استان', 'topersia' )
				: topersia_g_kind_label( $view ),
			'id'    => $view,
			'name'  => $name,
			'url'   => $url,
			'sum'   => topersia_g_text( $view, 'short_summary' ),
			'place' => '',
			'fact'  => '',
			'counts' => topersia_g_place_counts( $target ),
		);
	}
}

/**
 * شمار جاذبه و رویدادِ یک شهر — برای پاورقی کارت مرجع.  P5-D215
 *
 * جاذبه از گروه `ancient` آن شهر می‌آید و رویداد از زیرخانوادهٔ
 * `festivals` گروه `culture`. هیچ‌کدام فهرست دستی ندارند؛ همان نقشهٔ
 * رابطه‌ای است که بقیهٔ صفحه از آن می‌خواند.
 *
 * صفر که باشد، آن `span` اصلاً نمی‌آید.
 */
if ( ! function_exists( 'topersia_g_place_counts' ) ) {
	function topersia_g_place_counts( $view ) {

		$out = array( 'spots' => 0, 'events' => 0 );

		$ancient = topersia_g_group( $view, 'ancient' );

		if ( ! empty( $ancient['rels'] ) ) {
			$out['spots'] = count( topersia_g_rel_ids( $view, $ancient['rels'] ) );
		}

		$culture = topersia_g_group( $view, 'culture' );

		if ( ! empty( $culture['rels'] ) ) {

			$fest = array();

			foreach ( $culture['rels'] as $spec ) {
				if ( isset( $spec['fam'] ) && 'festivals' === $spec['fam'] ) { $fest[] = $spec; }
			}

			if ( $fest ) {
				$out['events'] = count( topersia_g_rel_ids( $view, $fest ) );
			}
		}

		return $out;
	}
}

/** سازندهٔ مشترک بخش‌های رابطه. */
if ( ! function_exists( 'topersia_g_rel_items' ) ) {
	function topersia_g_rel_items( $post_id, $key, $limit ) {

		$group = topersia_g_group( $post_id, $key );

		if ( empty( $group['rels'] ) && empty( $group['chains'] ) ) {
			return array( 'items' => array(), 'total' => 0, 'group' => $group );
		}

		$ids = empty( $group['rels'] ) ? array() : topersia_g_rel_ids( $post_id, $group['rels'] );

		/*
		 * زنجیره‌ها — برای بخش‌هایی که موجودیتشان یک پله پایین‌تر است.
		 *
		 * جاذبه‌های استان روی خود استان ننشسته‌اند؛ روی شهرهایش‌اند، و
		 * شهر هم دو پله پایین‌تر است: استان→شهرستان→شهر→جاذبه. بدون
		 * زنجیره، بخش جاذبه‌ها روی هر استانی خالی درمی‌آید.
		 */
		if ( ! empty( $group['chains'] ) ) {

			foreach ( $group['chains'] as $chain ) {
				foreach ( topersia_g_chain_ids( $post_id, $chain ) as $one ) {
					$ids[] = $one;
				}
			}

			$ids = array_values( array_unique( array_map( 'absint', $ids ) ) );
		}

		/*
		 * بخش `#places` کارت اولش مرکز استان است، بعد شهرستان‌ها —
		 * عیناً مرجع.  P5-D215
		 *
		 * مرکز از رابطهٔ ۹۶ می‌آید و برچسبش فرق دارد، پس جدا از صف
		 * شهرستان‌ها جلو می‌افتد و در مرتب‌سازی شرکت نمی‌کند.
		 */
		$lead_id = 'places' === $key ? topersia_g_capital_id( $post_id ) : 0;

		if ( $lead_id ) {
			$ids = array_values( array_diff( $ids, array( $lead_id ) ) );
		}

		/* یک ترتیب برای همهٔ کارت‌های موجودیت ماندگار.  P5-D211 */
		$ids   = topersia_g_sort_entities( $ids );
		$total = count( $ids );
		$items = array();
		$all   = array();

		if ( $lead_id ) {
			array_unshift( $ids, $lead_id );
			$total ++;
		}

		foreach ( $ids as $n => $one ) {

			if ( $limit && $n >= $limit ) {
				break;
			}

			$view = topersia_g_view_id( $one );
			$items[] = topersia_g_place_item( $view, $key, $lead_id && $one === $lead_id );
		}

		return array( 'items' => $items, 'total' => $total, 'group' => $group );
	}
}

/** [tp_slider rel="..."] — اسلاید کارت برای یک گروه رابطه. */
if ( ! function_exists( 'topersia_g_sc_slider' ) ) {
	function topersia_g_sc_slider( $atts = array() ) {

		$pid = topersia_g_pid( $atts );
		$key = isset( $atts['rel'] ) ? trim( (string) $atts['rel'] ) : '';

		if ( ! $pid || '' === $key ) {
			return '';
		}

		/* همهٔ موارد در DOM، بی‌پنهان‌سازی — مثل مرجع.  P5-D215 */
		$limit  = isset( $atts['limit'] ) ? absint( $atts['limit'] ) : 0;
		$result = topersia_g_rel_items( $pid, $key, $limit );

		if ( empty( $result['items'] ) ) {
			return '';
		}

		$cards = '';
		$no    = 0;

		foreach ( $result['items'] as $item ) {

			$no ++;

			/*
			 * نوعی که صفحهٔ عمومی ندارد، پیوند هم نمی‌گیرد: کارتش
			 * `<article>` است و حالت هاور ندارد.  P5-D210
			 */
			$linked = '' !== $item['url'];
			$open   = $linked
				? '<a class="tp-card-slide" href="' . esc_url( $item['url'] ) . '">'
				: '<article class="tp-card-slide">';

			/* شماره در مرجع لاتینِ دورقمی است — «01»، نه «۱».  P5-D215 */
			$cards .= $open
				. '<div class="tp-card-slide__art" aria-hidden="true">'
				. '<span class="tp-card-slide__no">' . esc_html( sprintf( '%02d', $no ) ) . '</span></div>'
				. '<div class="tp-card-slide__body">'
				. ( '' !== $item['kind'] ? '<span class="tp-card-slide__tag">' . esc_html( $item['kind'] ) . '</span>' : '' )
				. '<h3 class="tp-card-slide__title">' . esc_html( $item['name'] ) . '</h3>'
				. ( '' !== $item['sum'] ? '<p class="tp-card-slide__desc">' . esc_html( $item['sum'] ) . '</p>' : '' )
				. topersia_g_card_foot( $item )
				. '</div>'
				. ( $linked ? '</a>' : '</article>' );
		}

		$group = $result['group'];
		$title = isset( $group['title'] ) ? $group['title'] : '';
		$uid   = 'tpsl' . $pid . preg_replace( '/[^a-z0-9]+/i', '', $key );

		/* `places` شناسهٔ خودش را دارد چون در مرجع `#places` است، نه
		   یکی از `#rel-*` ها.  P5-D215 */
		$sec_id = 'tp-' . $key;

		/* نوار زیر اسلایدر در مرجع **داخل** `.slider-wrap` است، نه بعدش. */
		return '<section id="' . esc_attr( $sec_id ) . '" class="tp-section">'
			. topersia_g_section_head( $group, topersia_g_name( $pid ) )
			. '<div class="tp-slider-wrap">'
			. '<div class="tp-slider" id="' . esc_attr( $uid ) . '">' . $cards . '</div>'
			. topersia_g_slider_bar( $uid, count( $result['items'] ) )
			. '</div></section>';
	}
}

/**
 * سرِ پیوندِ یک مورد رابطه — یا بی‌`href` اگر آن نوع صفحه ندارد.  P5-D210
 *
 * `href=""` یعنی پیوند به خودِ صفحه: خزنده دنبالش می‌رود و کاربر با کلیک
 * به بالای همین صفحه می‌پرد. `<a>` بی‌`href` پیوند نیست، فوکوس نمی‌گیرد، و
 * سبکش همان سبکِ `a` مرجع است.
 */
if ( ! function_exists( 'topersia_g_a_open' ) ) {
	function topersia_g_a_open( $url, $attrs = '' ) {
		return '' !== (string) $url
			? '<a href="' . esc_url( $url ) . '"' . $attrs . '>'
			: '<a' . $attrs . '>';
	}
}

/**
 * جهتِ یک همسایه از این موجودیت — «شمال» تا «شمال‌غرب».  P5-D219
 *
 * رابطهٔ ۱۰۲ (هم‌مرزی) هیچ فیلد جهتی ندارد، ولی هر دو سو
 * `geo_coordinates` دارند. سمتِ مرکز همسایه از مرکز این موجودیت، به هشت
 * بخش ۴۵ درجه‌ای. از دو مختصات واقعی مشتق است، نه حدس؛ اگر یکی نبود،
 * برچسب اصلاً نمی‌آید.
 *
 * @return string برچسب فارسی، یا رشتهٔ خالی.
 */
if ( ! function_exists( 'topersia_g_bearing_label' ) ) {
	function topersia_g_bearing_label( $from, $to ) {

		$a = array_map( 'trim', explode( ',', (string) $from ) );
		$b = array_map( 'trim', explode( ',', (string) $to ) );

		if ( count( $a ) < 2 || count( $b ) < 2 || ! is_numeric( $a[0] ) || ! is_numeric( $a[1] )
			|| ! is_numeric( $b[0] ) || ! is_numeric( $b[1] ) ) {
			return '';
		}

		$p1 = deg2rad( (float) $a[0] );
		$p2 = deg2rad( (float) $b[0] );
		$dl = deg2rad( (float) $b[1] - (float) $a[1] );

		$y = sin( $dl ) * cos( $p2 );
		$x = cos( $p1 ) * sin( $p2 ) - sin( $p1 ) * cos( $p2 ) * cos( $dl );

		if ( 0.0 === $x && 0.0 === $y ) {
			return '';
		}

		$deg = fmod( rad2deg( atan2( $y, $x ) ) + 360.0, 360.0 );

		$names = array( 'شمال', 'شمال‌شرق', 'شرق', 'جنوب‌شرق', 'جنوب', 'جنوب‌غرب', 'غرب', 'شمال‌غرب' );

		return $names[ (int) floor( ( $deg + 22.5 ) / 45.0 ) % 8 ];
	}
}

/** [tp_relgrid rel="..."] — شبکهٔ دوستونی با دکمهٔ ادامه. */
if ( ! function_exists( 'topersia_g_sc_relgrid' ) ) {
	function topersia_g_sc_relgrid( $atts = array() ) {

		$pid = topersia_g_pid( $atts );
		$key = isset( $atts['rel'] ) ? trim( (string) $atts['rel'] ) : '';

		if ( ! $pid || '' === $key ) {
			return '';
		}

		/*
		 * همه در DOM، بقیه با `hidden`.  P5-D219
		 *
		 * مرجع می‌گفت دکمه «ادامه را همین‌جا بار می‌کند، نه اینکه کاربر
		 * از صفحه برود» و در وردپرس یک درخواست REST می‌زند. تا آن نقطه
		 * ساخته نشده، همه‌شان رندر می‌شوند و بقیه پنهان می‌مانند: خزنده
		 * همه را می‌بیند، کاربر شش‌تای اول را، و دکمه بقیه را نشان
		 * می‌دهد بی‌هیچ رفت‌وبرگشتی.
		 */
		$shown  = isset( $atts['limit'] ) ? absint( $atts['limit'] ) : 6;
		$result = topersia_g_rel_items( $pid, $key, 0 );

		if ( empty( $result['items'] ) ) {
			return '';
		}

		$group = $result['group'];
		$title = isset( $group['title'] ) ? $group['title'] : '';
		$kick  = isset( $group['kicker'] ) ? $group['kicker'] : '';

		/*
		 * سه کارت مرجع شکل خودشان را دارند، نه شبکهٔ عمومی.  P5-D219
		 *
		 *   #practical   .practical-grid — نام و یک پیکان
		 *   #neighbors   .neighbors      — جهت بالای نام
		 *   #routes      .routes         — نام و جاهایی که از آن می‌گذرد
		 *
		 * تا ۴٫۱٫۶ هر سه با همان `.tp-grid` ساخته می‌شدند و آزمون پذیرش
		 * آنها را جفت نمی‌کرد: کلاس‌ها اصلاً یکی نبودند.
		 */
		if ( 'practical' === $key ) {

			$body = '';

			foreach ( $result['items'] as $item ) {
				$body .= topersia_g_a_open( $item['url'] ) . esc_html( $item['name'] )
					. ' <span>→</span></a>';
			}

			return topersia_g_section( 'tp-practical', $title, $kick, '<div class="tp-practical-grid">' . $body . '</div>' );
		}

		if ( 'neighbors' === $key ) {

			$here = topersia_g_text( $pid, 'geo_coordinates' );
			$body = '';

			foreach ( $result['items'] as $item ) {

				$dir = topersia_g_bearing_label( $here, topersia_g_text( $item['id'], 'geo_coordinates' ) );

				$body .= topersia_g_a_open( $item['url'] )
					. ( '' !== $dir ? '<span class="tp-n-dir">' . esc_html( $dir ) . '</span>' : '' )
					. '<b>' . esc_html( $item['name'] ) . '</b></a>';
			}

			return topersia_g_section( 'tp-neighbors', $title, $kick, '<div class="tp-neighbors">' . $body . '</div>' );
		}

		if ( 'routes' === $key ) {

			/* شهرهای همین موجودیت: برای استان زنجیرهٔ ۷۲→۷۳، برای شهر خودش. */
			$type  = function_exists( 'get_post_type' ) ? (string) get_post_type( $pid ) : '';
			$local = array();

			if ( 'tp_province' === $type ) {
				$local = topersia_g_chain_ids( $pid, array(
					array( 'id' => 72, 'dir' => 'children' ),
					array( 'id' => 73, 'dir' => 'children' ),
				) );
			} elseif ( 'tp_city' === $type ) {
				$local = array( $pid );
			}

			$body = '';

			foreach ( $result['items'] as $item ) {

				$via = array();

				if ( $local ) {
					$on_route = topersia_g_rel_ids( $item['id'], array( array( 'id' => 173, 'dir' => 'children' ) ) );
					foreach ( array_intersect( $on_route, $local ) as $city ) {
						$via[] = topersia_g_name( topersia_g_view_id( $city ) );
					}
				}

				$body .= topersia_g_a_open( $item['url'] ) . '<b>' . esc_html( $item['name'] ) . '</b>'
					. ( $via ? '<span>' . esc_html( implode( ' · ', $via ) ) . '</span>' : '' ) . '</a>';
			}

			return topersia_g_section( 'tp-routes', $title, $kick, '<div class="tp-routes">' . $body . '</div>' );
		}

		$grid = '';
		$n    = 0;

		foreach ( $result['items'] as $item ) {

			$n ++;

			$grid .= topersia_g_a_open( $item['url'], ( $shown && $n > $shown ? ' hidden data-tp-rest-item' : '' ) )
				. ( '' !== $item['kind'] ? '<span class="tp-kind">' . esc_html( $item['kind'] ) . '</span>' : '' )
				. '<b>' . esc_html( $item['name'] ) . '</b></a>';
		}

		$rest = $shown ? max( 0, count( $result['items'] ) - $shown ) : 0;
		$more = '';

		if ( $rest > 0 ) {

			$more = '<button class="tp-more-rest" type="button" data-tp-more'
				. ' data-tp-rest="' . esc_attr( $rest ) . '">'
				. topersia_g_fa( $rest ) . ' ' . esc_html__( 'مورد دیگر', 'topersia' ) . '</button>';
		}

		$group = $result['group'];

		return topersia_g_section(
			'tp-' . $key,
			isset( $group['title'] ) ? $group['title'] : '',
			isset( $group['kicker'] ) ? $group['kicker'] : '',
			'<div class="tp-grid">' . $grid . '</div>' . $more
		);
	}
}

/** [tp_gallery] — گالری از featured_image_gallery. */
if ( ! function_exists( 'topersia_g_sc_gallery' ) ) {
	/**
	 * فهرست عکس‌های گالری — یک بار خوانده می‌شود، دو جا مصرف.
	 *
	 * موزاییک و مودال هر دو از همین می‌خوانند، پس هیچ‌وقت از هم واگرا
	 * نمی‌شوند و شمارِ «+N تصویر» با شمارِ مودال یکی است.
	 *
	 * @return array هر عضو: id · img · full · label · place
	 */
	function topersia_g_gallery_shots( $raw ) {

		$out = array();

		if ( is_string( $raw ) ) {
			$raw = array_filter( array_map( 'trim', explode( ',', $raw ) ) );
		}

		if ( ! is_array( $raw ) ) {
			return $out;
		}

		foreach ( $raw as $attachment ) {

			$attachment = absint( is_array( $attachment ) && isset( $attachment['id'] ) ? $attachment['id'] : $attachment );

			if ( ! $attachment ) {
				continue;
			}

			$img = function_exists( 'wp_get_attachment_image' )
				? wp_get_attachment_image( $attachment, 'large', false, array( 'loading' => 'lazy' ) )
				: '';

			if ( '' === $img ) {
				continue;
			}

			$caption = function_exists( 'wp_get_attachment_caption' )
				? (string) wp_get_attachment_caption( $attachment ) : '';

			/* عنوانِ پیوست برچسب است و توضیحش جای مکان — همان دو سطر مرجع. */
			$label = function_exists( 'get_the_title' ) ? (string) get_the_title( $attachment ) : '';

			$out[] = array(
				'id'    => $attachment,
				'img'   => $img,
				'full'  => function_exists( 'wp_get_attachment_image_url' )
					? (string) wp_get_attachment_image_url( $attachment, 'full' ) : '',
				'label' => '' !== $label ? $label : $caption,
				'place' => '' !== $label ? $caption : '',
			);
		}

		return $out;
	}

	function topersia_g_sc_gallery( $atts = array() ) {

		$pid = topersia_g_pid( $atts );

		if ( ! $pid ) {
			return '';
		}

		$raw = topersia_g_raw( $pid, 'featured_image_gallery' );

		if ( is_string( $raw ) ) {
			$raw = array_filter( array_map( 'trim', explode( ',', $raw ) ) );
		}

		if ( ! is_array( $raw ) || empty( $raw ) ) {
			return '';
		}

		$shots = topersia_g_gallery_shots( $raw );

		if ( empty( $shots ) ) {
			return '';
		}

		/*
		 * موزاییک مرجع: پنج کاشی، ۲fr ۱fr ۱fr در دو ردیف، ۴۲۰ پیکسل.
		 * کاشی اول دو ردیف را می‌گیرد و شمارِ «+N تصویر» رویش می‌نشیند.
		 * P5-D219
		 *
		 * کاشی‌ها `<button>` اند نه `<figure>`: کلیک روی هرکدام همان
		 * عکس را در اندازهٔ کامل باز می‌کند.
		 */
		$tiles = '';
		$rest  = count( $shots ) - 5;

		foreach ( array_slice( $shots, 0, 5 ) as $n => $shot ) {

			$large = 0 === $n;

			$tiles .= '<button class="tp-gallery-main__item'
				. ( $large ? ' tp-gallery-main__item--large' : '' ) . '" type="button"'
				. ' data-tp-shot="' . esc_attr( $shot['id'] ) . '"'
				. ' aria-label="' . esc_attr( $shot['label'] ) . '">'
				. $shot['img']
				. ( $large && $rest > 0
					? '<span class="tp-gallery-main__count">+' . topersia_g_fa( $rest ) . ' '
						. esc_html__( 'تصویر', 'topersia' ) . '</span>'
					: '' )
				. ( '' !== $shot['label']
					? '<span class="tp-gallery-main__label">' . esc_html( $shot['label'] )
						. ( '' !== $shot['place']
							? ' <span class="tp-gallery-main__meta">· ' . esc_html( $shot['place'] ) . '</span>'
							: '' )
						. '</span>'
					: '' )
				. '</button>';
		}

		/*
		 * سرفصل مرجع: `h2` + `p.lead` + `.more` متنیِ کوچک.  P5-D218
		 */
		return '<section id="tp-gallery" class="tp-section">'
			. '<div class="tp-section-head"><div>'
			. '<h2>' . esc_html__( 'گالری تصاویر', 'topersia' ) . '</h2>'
			. '<p class="tp-lead">' . esc_html( sprintf(
				/* translators: نام موجودیت */
				__( 'تصاویر منتخب از جاذبه‌های %s', 'topersia' ),
				topersia_g_name( $pid )
			) ) . '</p></div>'
			. '<button class="tp-more" type="button" data-tp-gallery-open>'
			. esc_html__( 'همه تصاویر ←', 'topersia' ) . '</button></div>'
			. '<div class="tp-gallery-main">' . $tiles . '</div></section>';
	}
}

/**
 * تولیدکنندهٔ واحد ردیف‌های ریپیتر.
 *
 * ردیف بازنشسته هرگز حذف نمی‌شود؛ وضعیتش عوض می‌شود و هسته آن را فیلتر
 * می‌کند. اگر این فیلتر نباشد، یک ردیف بازنشسته هم در صفحه و هم در
 * JSON-LD منتشر می‌شود.  P5-D121 · P5-D145
 */
if ( ! function_exists( 'topersia_g_rows' ) ) {
	function topersia_g_rows( $post_id, $key ) {

		$rows = topersia_g_raw( $post_id, $key );

		if ( ! is_array( $rows ) ) {
			return array();
		}

		if ( function_exists( 'topersia_active_rows' ) ) {
			return topersia_active_rows( $rows );
		}

		/* هسته نیست — همان قطبیت را دستی نگه می‌داریم. */
		$out = array();

		foreach ( $rows as $row ) {

			if ( ! is_array( $row ) ) {
				continue;
			}

			$status = '';

			foreach ( $row as $sub => $value ) {

				if ( '_row_status' === substr( $sub, -11 ) ) {
					$status = $value;
					break;
				}
			}

			if ( 'not_applicable' !== $status ) {
				$out[] = $row;
			}
		}

		return $out;
	}
}

/** [tp_audio] — روایت صوتی از ریپیتر. */
if ( ! function_exists( 'topersia_g_sc_audio' ) ) {
	function topersia_g_sc_audio( $atts = array() ) {

		$pid = topersia_g_pid( $atts );

		if ( ! $pid ) {
			return '';
		}

		$rows = topersia_g_rows( $pid, 'audio_narration' );
		$body = '';

		foreach ( $rows as $row ) {

			$title = isset( $row['audio_title'] ) ? trim( wp_strip_all_tags( (string) $row['audio_title'] ) ) : '';
			$url   = isset( $row['audio_external_url'] ) ? trim( (string) $row['audio_external_url'] ) : '';
			$time  = isset( $row['audio_duration'] ) ? trim( (string) $row['audio_duration'] ) : '';

			if ( '' === $url && ! empty( $row['audio_file'] ) && function_exists( 'wp_get_attachment_url' ) ) {

				$file = is_array( $row['audio_file'] ) && isset( $row['audio_file']['id'] )
					? $row['audio_file']['id']
					: $row['audio_file'];

				$url = (string) wp_get_attachment_url( absint( $file ) );
			}

			if ( '' === $title || '' === $url ) {
				continue;
			}

			/* عیناً مرجع: آیکون پخش · عنوان · مدت — سه ستونِ شبکه. */
			$body .= '<a href="' . esc_url( $url ) . '">'
				. '<svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M8 5v14l11-7z"/></svg>'
				. '<b>' . esc_html( $title ) . '</b>'
				. ( '' !== $time ? '<span>' . topersia_g_fa( $time ) . '</span>' : '' ) . '</a>';
		}

		if ( '' === $body ) {
			return '';
		}

		return topersia_g_section( 'tp-audio', 'روایت صوتی', 'LISTEN', '<div class="tp-audio">' . $body . '</div>' );
	}
}

/** [tp_faq] — همان دادهٔ پرسش‌ها که در JSON-LD می‌رود. */
if ( ! function_exists( 'topersia_g_sc_faq' ) ) {
	function topersia_g_sc_faq( $atts = array() ) {

		$pid = topersia_g_pid( $atts );

		if ( ! $pid ) {
			return '';
		}

		$rows = topersia_g_rows( $pid, 'faq_items' );
		$body = '';
		$n    = 0;

		foreach ( $rows as $row ) {

			$question = isset( $row['faq_question'] ) ? trim( wp_strip_all_tags( (string) $row['faq_question'] ) ) : '';
			$answer   = isset( $row['faq_answer'] ) ? trim( wp_strip_all_tags( (string) $row['faq_answer'] ) ) : '';

			if ( '' === $question || '' === $answer ) {
				continue;
			}

			$n ++;

			/* آکوردئون مرجع: `name` مشترک، پس هر بار یکی باز است. */
			$body .= '<details name="faq-accordion"' . ( 1 === $n ? ' open' : '' ) . '>'
				. '<summary>' . esc_html( $question ) . '</summary>'
				. '<p>' . esc_html( $answer ) . '</p></details>';
		}

		if ( '' === $body ) {
			return '';
		}

		return '<section id="tp-faq" class="tp-section tp-faq">'
			. '<div class="tp-section-head"><div><h2>'
			. esc_html__( 'پرسش‌های متداول', 'topersia' ) . '</h2></div></div>'
			. $body . '</section>';
	}
}

/**
 * [tp_overview] — «پاسخ مستقیم».  P5-D219
 *
 * پاراگراف نخست `short_summary` است و بعدش هر فیلد ناحیهٔ `details` که
 * مقدار دارد، هر کدام یک `h3` با برچسب واژه‌نامه و متنش.
 *
 * این فیلدها تا ۴٫۱٫۶ داخل کارت «اطلاعات جغرافیایی» بودند و آن‌جا جایشان
 * نبود: «مرور اقلیم» و «زمینهٔ تاریخی» پاراگراف‌اند، و ستون کناری ۳۴۰
 * پیکسل است.
 *
 * `field-note` مرجع منتقل نشد — یادداشت ساخت بود، نه محتوا.
 */
if ( ! function_exists( 'topersia_g_sc_overview' ) ) {
	function topersia_g_sc_overview( $atts = array() ) {

		$pid = topersia_g_pid( $atts );

		if ( ! $pid ) {
			return '';
		}

		$map  = topersia_g_map();
		$lead = topersia_g_text( $pid, 'short_summary' );
		$long = '';

		if ( '' !== $lead ) {
			$long .= '<p itemprop="description">' . esc_html( $lead ) . '</p>';
		}

		foreach ( topersia_g_zone_fields( $pid, 'details' ) as $name => $raw ) {

			$text = trim( wp_strip_all_tags( topersia_g_value( $name, $raw ) ) );

			if ( '' === $text ) {
				continue;
			}

			$long .= '<h3>' . esc_html( $map[ $name ]['label'] ) . '</h3>'
				. '<p>' . esc_html( $text ) . '</p>';
		}

		if ( '' === $long ) {
			return '';
		}

		/* `.answer__meta` مرجع: چیپ‌های کوتاه از فیلدهای ناحیهٔ `card`. */
		$chips = '';

		foreach ( topersia_g_zone_fields( $pid, 'card', array( 'geo_coordinates' ) ) as $name => $raw ) {

			/* چیپ‌های مرجع متن خالص‌اند — «مساحت: ۱۰۷٬۰۱۸ km²». */
			$chips .= '<span>' . esc_html( $map[ $name ]['label'] ) . ': '
				. esc_html( trim( wp_strip_all_tags( topersia_g_value( $name, $raw ) ) ) )
				. '</span>';
		}

		$type = function_exists( 'get_post_type' ) ? (string) get_post_type( $pid ) : '';

		return '<section id="tp-overview" class="tp-section tp-answer">'
			. '<h2>' . esc_html__( 'پاسخ مستقیم', 'topersia' ) . '</h2>'
			. '<div class="tp-answer__divider"></div>'
			. '<article class="tp-longform" data-entity-type="' . esc_attr( $type ) . '"'
			. ' itemscope itemtype="https://schema.org/TouristDestination">' . $long . '</article>'
			. ( '' !== $chips ? '<div class="tp-answer__meta">' . $chips . '</div>' : '' )
			. '</section>';
	}
}

/**
 * [tp_ai] — «این مقصد را در یک نگاه بفهمید».  P5-D219
 *
 * افزونهٔ `topersia-ai-summarizer` خوانده شد: خروجیِ «خلاصه · نکات ·
 * برنامه» ندارد. آنچه دارد یک خلاصهٔ تکی است و دکمه‌هایی که موتور بیرونی
 * را با یک پرسش باز می‌کنند. پس طبق مسیر دومِ خواسته:
 *
 *   خلاصه        `ai_summary`
 *   نکات کلیدی   حقایق کارت آمار و کارت جغرافیا — همان‌ها که صفحه دارد
 *   برنامهٔ سفر   ساخته **نمی‌شود**: خواسته «فقط اگر فیلدش هست» بود و
 *                `Jetengine_Skin.json` هیچ فیلد برنامه یا مسیر روزانه‌ای
 *                ندارد. روزی که ساخته شد، سومین دکمه همین‌جا می‌آید.
 *
 * هیچ‌کدام ساخته نمی‌شوند: اگر خلاصه نباشد، بخش نمی‌آید.
 *
 * دکمه‌های موتور پیوند بیرونی‌اند، نه دکمهٔ جاوااسکریپتی: کاربر از صفحه
 * می‌رود، و `<a>` کلیک میانی و برگهٔ تازه را خودش می‌داند.
 */
if ( ! function_exists( 'topersia_g_ai_engines' ) ) {
	function topersia_g_ai_engines() {

		return array(
			'ChatGPT' => 'https://chatgpt.com/?q=%s',
			'Claude'  => 'https://claude.ai/new?q=%s',
			'Gemini'  => 'https://gemini.google.com/app?q=%s',
			'Copilot' => 'https://copilot.microsoft.com/?q=%s',
		);
	}
}

if ( ! function_exists( 'topersia_g_ai_icons' ) ) {
	function topersia_g_ai_icons() {

		$open = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"'
			. ' stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">';

		return array(
			'ChatGPT' => $open . '<circle cx="12" cy="12" r="9"/><path d="M8 12l3 3 5-5"/></svg>',
			'Claude'  => $open . '<rect x="4" y="4" width="16" height="16" rx="2"/><path d="M8 9h8M8 13h8M8 17h5"/></svg>',
			'Gemini'  => $open . '<path d="M12 2l2.4 6.6L21 11l-6.6 2.4L12 20l-2.4-6.6L3 11l6.6-2.4z"/></svg>',
			'Copilot' => $open . '<circle cx="12" cy="12" r="9"/><path d="M9 9h.01M15 9h.01M8.5 14c1 1.5 6 1.5 7 0"/></svg>',
		);
	}
}

if ( ! function_exists( 'topersia_g_sc_ai' ) ) {
	function topersia_g_sc_ai( $atts = array() ) {

		$pid = topersia_g_pid( $atts );

		if ( ! $pid ) {
			return '';
		}

		$summary = topersia_g_text( $pid, 'ai_summary' );

		if ( '' === $summary ) {
			return '';
		}

		$map  = topersia_g_map();
		$name = topersia_g_name( $pid );

		/* نکات کلیدی: همان حقایقی که کارت آمار و کارت جغرافیا نشان می‌دهند. */
		$bullets = array();

		$capital = topersia_g_capital_id( $pid );

		if ( $capital ) {
			$group     = topersia_g_group( $pid, 'capital' );
			$bullets[] = ( isset( $group['title'] ) ? $group['title'] : '' ) . ': '
				. topersia_g_name( topersia_g_view_id( $capital ) );
		}

		foreach ( topersia_g_zone_fields( $pid, 'card', array( 'geo_coordinates' ) ) as $key => $raw ) {
			$bullets[] = $map[ $key ]['label'] . ': '
				. trim( wp_strip_all_tags( topersia_g_value( $key, $raw ) ) );
		}

		$types = array( 'summary' => 'خلاصه مقصد' );

		if ( $bullets ) {
			$types['bullets'] = 'نکات کلیدی';
		}

		$data = array(
			'summary' => $summary,
			'bullets' => $bullets ? '• ' . implode( "\n• ", $bullets ) : '',
		);

		/* دکمه‌های نوع خروجی */
		$buttons = '';
		$first   = true;

		foreach ( $types as $key => $label ) {

			$buttons .= '<button class="tp-ai__btn' . ( $first ? ' tp-is-active' : '' ) . '"'
				. ' type="button" data-ai="' . esc_attr( $key ) . '">' . esc_html( $label ) . '</button>';

			$first = false;
		}

		$buttons .= '<button class="tp-ai__btn tp-ai__btn--copy" type="button" data-ai="copy">'
			. '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"'
			. ' stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">'
			. '<rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15V5a2 2 0 012-2h10"/></svg>'
			. esc_html__( 'کپی خروجی', 'topersia' ) . '</button>';

		/*
		 * پرسشی که موتور با آن باز می‌شود: نام موجودیت و نشانی همین صفحه.
		 * بی‌نشانی، موتور نمی‌داند دربارهٔ کدام صفحه حرف می‌زنیم.
		 */
		$url = (string) get_permalink( $pid );

		$prompt = sprintf(
			/* translators: 1: نام موجودیت 2: نشانی صفحه */
			esc_html__( 'دربارهٔ %1$s بر پایهٔ این صفحه توضیح بده: %2$s', 'topersia' ),
			$name,
			$url
		);

		$icons   = topersia_g_ai_icons();
		$engines = '<span class="tp-ai__engines-label">' . esc_html__( 'موتور:', 'topersia' ) . '</span>';

		foreach ( topersia_g_ai_engines() as $engine => $pattern ) {

			$engines .= '<a class="tp-ai__engine" href="'
				. esc_url( sprintf( $pattern, rawurlencode( $prompt ) ) ) . '"'
				. ' target="_blank" rel="nofollow noopener">'
				. $icons[ $engine ] . esc_html( $engine ) . '</a>';
		}

		$body = '<div class="tp-ai">'
			. '<div class="tp-ai__kicker">' . esc_html__( 'این مقصد را در یک نگاه بفهمید', 'topersia' ) . '</div>'
			. '<h2>' . esc_html__( 'این مقصد را در یک نگاه بفهمید', 'topersia' ) . '</h2>'
			. '<p>' . esc_html__( 'خروجی از دادهٔ ساختاریافتهٔ همین صفحه ساخته می‌شود.', 'topersia' ) . '</p>'
			. '<div class="tp-ai__actions" role="group" aria-label="'
			. esc_attr__( 'خروجی‌های هوش مصنوعی', 'topersia' ) . '">' . $buttons . '</div>'
			. '<div class="tp-ai__engines" role="group" aria-label="'
			. esc_attr__( 'ادامه در موتور هوش مصنوعی', 'topersia' ) . '">' . $engines . '</div>'
			. '<div class="tp-ai__out" data-tp-ai-out'
			. " data-tp-ai='" . esc_attr( wp_json_encode( $data ) ) . "'"
			. ' aria-live="polite"><p>' . esc_html( $summary ) . '</p>'
			. '<div class="tp-ai__out-meta"><span>' . esc_html__( 'نوع خروجی:', 'topersia' )
			. ' <strong data-tp-ai-type>' . esc_html( reset( $types ) ) . '</strong></span></div></div>'
			/* نیمهٔ اولِ جملهٔ مرجع برای ما هم راست است؛ نیمهٔ دوم یادداشت ساخت بود. */
			. '<p class="tp-ai__disclaimer">' . esc_html__( 'این خروجی صرفاً از دادهٔ موجود همین صفحه ساخته شده است.', 'topersia' ) . '</p>'
			. '</div>';

		return '<section id="tp-ai" class="tp-section">' . $body . '</section>';
	}
}

/**
 * [tp_news] — اخبار مرتبط با این موجودیت.  P5-D219
 *
 * نوع پست `tpc_news` هنوز ساخته نشده (CHANGE-PACKAGE-001). تا آن روز
 * این بخش رندر نمی‌شود — نه جعبهٔ خالی، نه متن «به‌زودی».
 */
if ( ! function_exists( 'topersia_g_sc_news' ) ) {
	function topersia_g_sc_news( $atts = array() ) {

		$pid = topersia_g_pid( $atts );

		if ( ! $pid || ! function_exists( 'post_type_exists' ) || ! post_type_exists( 'tpc_news' ) ) {
			return '';
		}

		$group = topersia_g_group( $pid, 'news' );

		if ( empty( $group['rels'] ) ) {
			return '';
		}

		$ids  = topersia_g_rel_ids( $pid, $group['rels'] );
		$rows = '';

		foreach ( array_slice( $ids, 0, 3 ) as $one ) {

			$view = topersia_g_view_id( $one );
			$date = function_exists( 'get_post_time' ) ? (string) get_post_time( 'Y-m-d', false, $view ) : '';
			$sum  = topersia_g_text( $view, 'short_summary' );

			$rows .= '<a href="' . esc_url( (string) get_permalink( $view ) ) . '">'
				. '<div class="tp-thumb">NEWS</div><div>'
				. '<h3>' . esc_html( topersia_g_name( $view ) ) . '</h3>'
				. ( '' !== $date
					? '<time datetime="' . esc_attr( $date ) . '">' . esc_html( topersia_g_date_fa( $date ) ) . '</time>'
					: '' )
				. ( '' !== $sum ? '<p>' . esc_html( $sum ) . '</p>' : '' )
				. '</div></a>';
		}

		if ( '' === $rows ) {
			return '';
		}

		return '<section id="tp-news" class="tp-section">'
			. '<div class="tp-section-head"><div><h2>'
			. esc_html__( 'اخبار', 'topersia' ) . '</h2></div></div>'
			. '<div class="tp-news">' . $rows . '</div></section>';
	}
}

/**
 * [tp_reviews] — امتیاز و نظر بازدیدکنندگان.  P5-D219
 *
 * داده از JetReviews همین پست می‌آید: میانگین، توزیع یک تا پنج، و دو
 * نظر آخر. بی‌نظر، بخش نمی‌آید.
 *
 * JetReviews جدول خودش را دارد و ما فقط می‌خوانیم؛ اگر افزونه نصب نباشد
 * همان `''` برمی‌گردد و بخش ناپدید می‌شود.
 */
if ( ! function_exists( 'topersia_g_reviews_data' ) ) {
	function topersia_g_reviews_data( $post_id ) {

		$rows  = array();
		$names = array();

		/*
		 * جدول‌های JetReviews روی سایت زنده — از تصویر پایگاه داده.  P5-D219
		 *
		 *   {prefix}jet_reviews        post_id · author · date · content ·
		 *                              rating (int) · approved (varchar)
		 *   {prefix}jet_review_guests  guest_id · name
		 *
		 * فقط خواندن. اگر افزونه یا جدولش نبود، هیچ چیز خوانده نمی‌شود و
		 * بخش ناپدید می‌شود — همان قاعدهٔ «بی‌داده، بی‌جعبه».
		 */
		global $wpdb;

		if ( isset( $wpdb ) && is_object( $wpdb ) && method_exists( $wpdb, 'get_results' ) && $post_id ) {

			$table = $wpdb->prefix . 'jet_reviews';
			$found = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $wpdb->esc_like( $table ) ) );

			if ( $found === $table ) {

				$rows = (array) $wpdb->get_results( $wpdb->prepare(
					"SELECT author, date, content, rating, approved FROM {$table} WHERE post_id = %d ORDER BY date DESC",
					absint( $post_id )
				), ARRAY_A );

				/* نام مهمان — فقط برای دو نظر آخر لازم است */
				$guests = $wpdb->prefix . 'jet_review_guests';
				$ids    = array();

				foreach ( array_slice( $rows, 0, 6 ) as $row ) {
					if ( isset( $row['author'] ) && '' !== (string) $row['author'] && ! ctype_digit( (string) $row['author'] ) ) {
						$ids[] = (string) $row['author'];
					}
				}

				if ( $ids && $guests === $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $wpdb->esc_like( $guests ) ) ) ) {

					$marks = implode( ',', array_fill( 0, count( $ids ), '%s' ) );

					foreach ( (array) $wpdb->get_results( $wpdb->prepare(
						"SELECT guest_id, name FROM {$guests} WHERE guest_id IN ({$marks})",
						$ids
					), ARRAY_A ) as $g ) {
						$names[ (string) $g['guest_id'] ] = (string) $g['name'];
					}
				}
			}
		}

		$data = topersia_g_reviews_from_rows( $rows, $names );

		if ( function_exists( 'apply_filters' ) ) {
			$data = apply_filters( 'topersia_g_reviews_data', $data, $post_id );
		}

		return $data;
	}
}

/**
 * ردیف‌های خامِ JetReviews ← داده‌ٔ بخش نظرها.  P5-D219
 *
 * تابع خالص است — بی‌پایگاه داده آزمون‌پذیر.
 *
 *   تأییدشده   `approved` برابر `1` یا `true`؛ بقیه کنار می‌روند
 *   امتیاز      اگر بیشینهٔ `rating` از ۵ بزرگ‌تر است، درصد است و ÷۲۰ می‌شود
 *               (JetReviews امتیاز را درصدی از بیشینهٔ فیلد نگه می‌دارد)؛
 *               وگرنه خودش ستاره است
 *   توزیع       هر نظر در نزدیک‌ترین ستارهٔ یک تا پنج
 *   دو نظر آخر  تازه‌ترین‌های بامتن؛ نویسنده از کاربر وردپرس یا جدول مهمان
 *
 * @param array $rows  ردیف‌ها به ترتیب تاریخ نزولی.
 * @param array $names نام مهمان‌ها بر پایهٔ guest_id.
 * @return array avg · count · dist · last
 */
if ( ! function_exists( 'topersia_g_reviews_from_rows' ) ) {
	function topersia_g_reviews_from_rows( $rows, $names = array() ) {

		$out = array( 'avg' => 0.0, 'count' => 0, 'dist' => array( 1 => 0, 2 => 0, 3 => 0, 4 => 0, 5 => 0 ), 'last' => array() );

		$ok = array();

		foreach ( (array) $rows as $row ) {
			$flag = isset( $row['approved'] ) ? strtolower( trim( (string) $row['approved'] ) ) : '';
			if ( '1' === $flag || 'true' === $flag ) {
				$ok[] = $row;
			}
		}

		if ( ! $ok ) {
			return $out;
		}

		$max = 0;
		foreach ( $ok as $row ) {
			$max = max( $max, (int) $row['rating'] );
		}

		$percent = $max > 5;
		$sum     = 0.0;

		foreach ( $ok as $i => $row ) {

			$score = $percent ? ( (int) $row['rating'] ) / 20 : (float) $row['rating'];
			$score = max( 0.0, min( 5.0, $score ) );

			$ok[ $i ]['_score'] = $score;
			$sum               += $score;

			$star = (int) max( 1, min( 5, round( $score ) ) );
			$out['dist'][ $star ] ++;
		}

		$out['count'] = count( $ok );
		$out['avg']   = round( $sum / $out['count'], 1 );

		foreach ( $ok as $row ) {

			$text = trim( wp_strip_all_tags( isset( $row['content'] ) ? (string) $row['content'] : '' ) );

			if ( '' === $text ) {
				continue;
			}

			$author = isset( $row['author'] ) ? (string) $row['author'] : '';
			$name   = '';

			if ( ctype_digit( $author ) && function_exists( 'get_the_author_meta' ) ) {
				$name = (string) get_the_author_meta( 'display_name', (int) $author );
			} elseif ( isset( $names[ $author ] ) ) {
				$name = $names[ $author ];
			}

			$out['last'][] = array( 'author' => $name, 'score' => $row['_score'], 'text' => $text );

			if ( 2 === count( $out['last'] ) ) {
				break;
			}
		}

		return $out;
	}
}

if ( ! function_exists( 'topersia_g_stars' ) ) {
	function topersia_g_stars( $score ) {

		$full = (int) round( (float) $score );
		$full = max( 0, min( 5, $full ) );

		return str_repeat( '★', $full ) . str_repeat( '☆', 5 - $full );
	}
}

if ( ! function_exists( 'topersia_g_sc_reviews' ) ) {
	function topersia_g_sc_reviews( $atts = array() ) {

		$pid = topersia_g_pid( $atts );

		if ( ! $pid ) {
			return '';
		}

		$data = topersia_g_reviews_data( $pid );

		if ( empty( $data['count'] ) ) {
			return '';
		}

		$count = (int) $data['count'];
		$bars  = '';

		for ( $star = 5; $star >= 1; $star -- ) {

			$n   = isset( $data['dist'][ $star ] ) ? (int) $data['dist'][ $star ] : 0;
			$pct = $count ? round( $n * 100 / $count ) : 0;

			$bars .= '<div class="tp-bar"><span>' . topersia_g_fa( $star ) . '</span>'
				. '<i style="--tp-w:' . esc_attr( $pct ) . '%"></i>'
				. '<span>' . topersia_g_fa( $n ) . '</span></div>';
		}

		$list = '';

		foreach ( array_slice( (array) $data['last'], 0, 2 ) as $one ) {

			$author = isset( $one['author'] ) ? (string) $one['author'] : '';
			$text   = isset( $one['text'] ) ? (string) $one['text'] : '';
			$score  = isset( $one['score'] ) ? (float) $one['score'] : 0.0;

			if ( '' === $text ) {
				continue;
			}

			$list .= '<div class="tp-cmt">'
				. ( '' !== $author ? '<b>' . esc_html( $author ) . '</b>' : '' )
				. '<span class="tp-rate__stars">' . esc_html( topersia_g_stars( $score ) ) . '</span>'
				. '<p>' . esc_html( $text ) . '</p></div>';
		}

		$avg = topersia_g_fa( number_format_i18n( (float) $data['avg'], 1 ) );

		return '<section id="tp-reviews" class="tp-section">'
			. '<div class="tp-section-head"><div><h2>'
			. esc_html__( 'نظر بازدیدکنندگان', 'topersia' ) . '</h2></div></div>'
			. '<div class="tp-rate"><div class="tp-rate__top"><div>'
			. '<div class="tp-rate__score">' . esc_html( $avg ) . '</div>'
			. '<div class="tp-rate__stars">' . esc_html( topersia_g_stars( $data['avg'] ) ) . '</div>'
			. '<div class="tp-rate__count">' . esc_html( sprintf(
				/* translators: %s: شمار رأی */
				__( 'از %s رأی', 'topersia' ),
				topersia_g_fa( $count )
			) ) . '</div></div>'
			. '<div class="tp-rate__bars">' . $bars . '</div></div>'
			. ( '' !== $list ? '<div class="tp-rate__list">' . $list . '</div>' : '' )
			. '</div></section>';
	}
}

/** [tp_sources] — منابع، راستی‌آزمایی، شناسهٔ موجودیت. */
if ( ! function_exists( 'topersia_g_sc_sources' ) ) {
	function topersia_g_sc_sources( $atts = array() ) {

		$pid = topersia_g_pid( $atts );

		if ( ! $pid ) {
			return '';
		}

		$body = '';
		$list = '';

		foreach ( topersia_g_rows( $pid, 'source_references' ) as $row ) {

			$name = isset( $row['source_name'] ) ? trim( wp_strip_all_tags( (string) $row['source_name'] ) ) : '';
			$url  = isset( $row['source_url'] ) ? trim( (string) $row['source_url'] ) : '';

			if ( '' === $name ) {
				continue;
			}

			$list .= '<li>' . ( '' !== $url
				? '<a href="' . esc_url( $url ) . '" rel="nofollow noopener">' . esc_html( $name ) . '</a>'
				: esc_html( $name ) ) . '</li>';
		}

		if ( '' !== $list ) {
			$body .= '<ol>' . $list . '</ol>';
		}

		$verified = topersia_g_date_fa( topersia_g_raw( $pid, 'last_verified_date' ) );

		if ( '' !== $verified ) {

			$body .= '<span class="tp-verified">✓ '
				. esc_html__( 'آخرین راستی‌آزمایی:', 'topersia' ) . ' ' . esc_html( $verified ) . '</span>';
		}

		$rows   = '';
		$status = topersia_g_text( $pid, 'content_status' );
		$uid    = topersia_g_text( $pid, 'entity_uid' );
		$ref    = topersia_g_text( $pid, 'external_reference_uri' );

		if ( '' !== $status ) {

			$rows .= '<div><span>' . esc_html__( 'وضعیت محتوا', 'topersia' ) . '</span>'
				. '<b>' . esc_html( topersia_g_glossary_label( '37', $status ) ) . '</b></div>';
		}

		if ( '' !== $uid ) {

			$rows .= '<div><span>' . esc_html__( 'شناسهٔ موجودیت', 'topersia' ) . '</span>'
				. '<b class="tp-lat" dir="ltr">' . esc_html( $uid ) . '</b></div>';
		}

		if ( '' !== $ref ) {

			/* مرجع نام میزبان را نشان می‌داد («Wikidata»)، نه نشانی کامل را. */
			$host = (string) parse_url( $ref, PHP_URL_HOST );
			$host = preg_replace( '/^www\./', '', $host );

			$rows .= '<div><span>' . esc_html__( 'مرجع خارجی', 'topersia' ) . '</span>'
				. '<a class="tp-lat" dir="ltr" href="' . esc_url( $ref ) . '" rel="nofollow noopener">'
				. esc_html( '' !== $host ? $host : $ref ) . '</a></div>';
		}

		/*
		 * `.tp-uid` در مرجع **خواهرِ** `.sources-rail` است، نه فرزندش — هر
		 * دو مستقیم زیر بدنهٔ کارت. داخلش که بنشیند، رنگ کم‌رنگ و اندازهٔ
		 * ریزِ فهرست منابع را ارث می‌برد.  P5-D219
		 */
		$out = '';

		if ( '' !== $body ) {
			$out .= '<div class="tp-sources-rail">' . $body . '</div>';
		}

		if ( '' !== $rows ) {
			$out .= '<div class="tp-uid">' . $rows . '</div>';
		}

		return topersia_g_section( 'tp-sources', 'منابع و راستی‌آزمایی', 'PROVENANCE', $out );
	}
}

/* =========================================================================
   ۵ — آهنگساز صفحه
   =========================================================================

   چرا این شورت‌کد وجود دارد:

   قرار اولیه این بود که المنتور اسکلت چیدمان بسازد و هسته محتوا. سه دور
   آزمون زنده نشان داد این مرز جواب نمی‌دهد: کانتینر المنتور CSS خودش را
   با همان ویژگی ما می‌نویسد و بعد از فایل ما بار می‌شود، سربرگ نمی‌تواند
   از جعبه بیرون بزند، و ترتیب موبایل باید از میان دو لایه پوشش رد شود.
   هر دور، یک ترفند ویژگی تازه لازم داشت — و ترفند روی ۱۹۴٬۰۰۰ صفحه
   یعنی بدهی.

   حالا لایهٔ نمایش کل بدنه را می‌سازد و المنتور دقیقاً یک ویجت دارد.
   چیزی از دست نمی‌رود، چون از P5-D179 به بعد چیدمان هم در CSS بود و
   المنتور جز یک درخت کانتینر که با ما می‌جنگید چیزی نمی‌داد.  P5-D183
   ========================================================================= */

/**
 * نمایش هر گروه رابطه: ستون · تولیدکننده · شناسه · نام در نوار بخش‌ها.
 *
 * ترتیب همین آرایه، ترتیب نشستن بخش‌ها در هر ستون است.
 *
 * `capital` و `crumbs` اینجا نیستند چون بخش مستقل نمی‌سازند — اولی در
 * کارت آمار می‌نشیند و دومی در مسیر راهنما.
 */
if ( ! function_exists( 'topersia_g_rel_zones' ) ) {
	function topersia_g_rel_zones() {

		$zones = array(
			/* `#places` مرجع: مرکز استان + شهرستان‌ها در یک اسلایدر. */
			/*
			 * شناسهٔ هر ناحیه `tp-` + شناسهٔ مرجع است، بی‌استثنا.  P5-D219
			 * قاعدهٔ نگاشت مکانیکی است، پس `#places` مرجع `#tp-places`
			 * می‌شود و بلوک `order` موبایلِ مرجع بدون دست‌کاری کار می‌کند.
			 */
			'attractions' => array( 'main', 'topersia_g_sc_slider',  'tp-attractions', 'جاذبه‌ها' ),
			'places'      => array( 'main', 'topersia_g_sc_slider',  'tp-places',      'شهرستان‌ها و شهرها' ),
			'districts'   => array( 'main', 'topersia_g_sc_slider',  'tp-districts',   'محله‌ها' ),
			'provinces'   => array( 'main', 'topersia_g_sc_slider',  'tp-provinces',   'استان‌ها' ),
			'culture'     => array( 'main', 'topersia_g_sc_culture', 'tp-culture',     'فرهنگ و غذا' ),

			/* روستاها در ستون کناری‌اند، میان «باستانی» و «سفر عملی» — پس
			   هم‌شکل همسایه‌هایشان شبکهٔ دوستونی‌اند، نه اسلایدر. */
			'villages'   => array( 'rail', 'topersia_g_sc_relgrid', 'tp-villages',   'روستاها' ),
			'nature'     => array( 'rail', 'topersia_g_sc_relgrid', 'tp-nature',     'طبیعت' ),
			'ancient'    => array( 'rail', 'topersia_g_sc_relgrid', 'tp-ancient',    'باستانی' ),
			'practical'  => array( 'rail', 'topersia_g_sc_relgrid', 'tp-practical',  'سفر عملی' ),
			'border'     => array( 'rail', 'topersia_g_sc_relgrid', 'tp-border',     'گذرهای مرزی' ),
			'subranges'  => array( 'rail', 'topersia_g_sc_relgrid', 'tp-subranges',  'زیرشاخه‌ها' ),
			'capital-of' => array( 'rail', 'topersia_g_sc_relgrid', 'tp-capital-of', 'مرکزیت' ),
			'neighbors'  => array( 'rail', 'topersia_g_sc_relgrid', 'tp-neighbors',  'هم‌مرزها' ),
			'routes'     => array( 'rail', 'topersia_g_sc_relgrid', 'tp-routes',     'مسیرها' ),
		);

		if ( function_exists( 'apply_filters' ) ) {
			$zones = apply_filters( 'topersia_g_rel_zones', $zones );
		}

		return $zones;
	}
}

/**
 * فهرست نواحی، به همان ترتیبی که در صفحه می‌نشینند.
 *
 * بخش‌های رابطه‌ای از نقشهٔ همین نوع پست ساخته می‌شوند، نه از فهرست ثابت.
 * قالب دستهٔ G یکی است ولی سیزده نوع پست ساختار رابطهٔ متفاوتی دارند؛ فهرست
 * ثابتِ استان‌شکل یعنی شهر و روستا و کوه بخش‌های خودشان را هرگز نگیرند.
 */
if ( ! function_exists( 'topersia_g_layout' ) ) {
	function topersia_g_layout( $post_id = 0 ) {

		$type = ( $post_id && function_exists( 'get_post_type' ) ) ? get_post_type( $post_id ) : '';
		$map  = topersia_g_relmap();
		$has  = ( $type && isset( $map[ $type ] ) ) ? $map[ $type ] : array();

		$rel = array( 'main' => array(), 'rail' => array() );

		foreach ( topersia_g_rel_zones() as $key => $zone ) {

			if ( empty( $has[ $key ] ) ) {
				continue;
			}

			$rel[ $zone[0] ][ $key ] = array(
				'fn'   => $zone[1],
				'atts' => array( 'rel' => $key ),
				'id'   => $zone[2],
				'nav'  => $zone[3],
			);
		}

		/*
		 * ترتیب دو ستون، صریح و عیناً مرجع.  P5-D219
		 *
		 * هر عضو یا یک ناحیهٔ ثابت است یا کلید یک گروه رابطه. پیش از این
		 * ناحیه‌های رابطه‌ای یک‌جا ته صف می‌افتادند و ترتیبشان از جدول
		 * `topersia_g_rel_zones()` می‌آمد، نه از مرجع — برای همین
		 * «فرهنگ» پیش از «اخبار» می‌نشست ولی «جاذبه‌ها» بعد از
		 * «شهرستان‌ها» نه.
		 *
		 * ناحیه‌های رابطه‌ای که مرجع نامشان را نبرده (محله، استان‌ها،
		 * گذر مرزی، …) ته همان ستون می‌آیند، به ترتیب جدول — پس نوع
		 * پستی که ساختار دیگری دارد بی‌صدا بخشش را گم نمی‌کند.
		 */
		$order = array(
			'main' => array(
				array( 'fn' => 'topersia_g_sc_ai',       'id' => 'tp-ai',       'nav' => 'خلاصه هوشمند' ),
				array( 'fn' => 'topersia_g_sc_overview', 'id' => 'tp-overview', 'nav' => 'پاسخ مستقیم' ),
				array( 'fn' => 'topersia_g_sc_gallery',  'id' => 'tp-gallery',  'nav' => 'گالری' ),
				'attractions',
				'places',
				'culture',
				array( 'fn' => 'topersia_g_sc_news',    'id' => 'tp-news',    'nav' => 'اخبار' ),
				array( 'fn' => 'topersia_g_sc_faq',     'id' => 'tp-faq',     'nav' => 'پرسش‌ها' ),
				array( 'fn' => 'topersia_g_sc_reviews', 'id' => 'tp-reviews', 'nav' => 'نظرها' ),
			),
			'rail' => array(
				array( 'fn' => 'topersia_g_sc_actionbar', 'id' => '',           'nav' => '' ),
				array( 'fn' => 'topersia_g_sc_map',       'id' => 'tp-map',     'nav' => 'نقشه' ),
				array( 'fn' => 'topersia_g_sc_seasons',   'id' => 'tp-season',  'nav' => 'زمان سفر' ),
				array( 'fn' => 'topersia_g_sc_weather',   'id' => 'tp-weather', 'nav' => '' ),
				array( 'fn' => 'topersia_g_sc_audio',     'id' => 'tp-audio',   'nav' => '' ),
				array( 'fn' => 'topersia_g_sc_facts',     'id' => 'tp-geo',     'nav' => 'جغرافیا' ),
				array( 'fn' => 'topersia_g_sc_badges',    'id' => 'tp-badges',  'nav' => '' ),
				'nature',
				'ancient',
				'villages',
				'practical',
				'neighbors',
				'routes',
				array( 'fn' => 'topersia_g_sc_sources', 'id' => 'tp-sources', 'nav' => 'منابع' ),
			),
		);

		$layout = array( 'main' => array(), 'rail' => array() );

		foreach ( $order as $col => $list ) {

			$named = array();

			foreach ( $list as $entry ) {

				if ( is_array( $entry ) ) {
					$entry['atts']     = array();
					$layout[ $col ][]  = $entry;
					continue;
				}

				$named[ $entry ] = true;

				if ( isset( $rel[ $col ][ $entry ] ) ) {
					$layout[ $col ][] = $rel[ $col ][ $entry ];
				}
			}

			/* آنچه نامش در فهرست مرجع نبود، ته همان ستون. */
			foreach ( $rel[ $col ] as $key => $zone ) {
				if ( empty( $named[ $key ] ) ) {
					$layout[ $col ][] = $zone;
				}
			}
		}

		if ( function_exists( 'apply_filters' ) ) {
			$layout = apply_filters( 'topersia_g_layout', $layout, $post_id );
		}

		return $layout;
	}
}

/**
 * [tp_page] — کل بدنهٔ صفحهٔ موجودیت.
 *
 * نوار بخش‌ها از روی نواحی‌ای ساخته می‌شود که واقعاً محتوا داشتند، نه از
 * یک فهرست ثابت. لینک به بخشی که وجود ندارد، بدترین نوع ناوبری است.
 */
if ( ! function_exists( 'topersia_g_sc_page' ) ) {
	function topersia_g_sc_page( $atts = array() ) {

		$pid = topersia_g_pid( $atts );

		if ( ! $pid ) {
			return '';
		}

		$layout   = topersia_g_layout( $pid );
		$cols     = array( 'main' => '', 'rail' => '' );
		$rendered = array();

		foreach ( $cols as $key => $ignored ) {

			if ( empty( $layout[ $key ] ) ) {
				continue;
			}

			foreach ( $layout[ $key ] as $zone ) {

				if ( ! function_exists( $zone['fn'] ) ) {
					continue;
				}

				$html = call_user_func( $zone['fn'], array_merge( $zone['atts'], array( 'id' => $pid ) ) );

				if ( '' === trim( (string) $html ) ) {
					continue;
				}

				$cols[ $key ] .= $html;

				if ( '' !== $zone['id'] ) {
					$rendered[ $zone['id'] ] = array( 'col' => $key, 'nav' => $zone['nav'] );
				}
			}
		}

		/*
		 * نوار بخش‌ها — همان دوازده پیوندِ مرجع با برچسب‌های خودش.  P5-D219
		 *
		 * مرجع کارت‌های ستون کناری را (فصل، جغرافیا، طبیعت، …) در نوار
		 * نمی‌آورد؛ آن‌ها از برگهٔ «بخش‌ها»ی موبایل در دسترس‌اند. بخش‌های
		 * ستون اصلی که مرجع نداشت (محله‌ها، استان‌ها) پس از «فرهنگ» می‌آیند.
		 * پیوندی فقط به بخشی که واقعاً رندر شد.  P5-D192
		 */
		$snav_ref = array(
			'tp-ai'          => 'خلاصه هوشمند',
			'tp-overview'    => 'پاسخ مستقیم',
			'tp-gallery'     => 'گالری',
			'tp-attractions' => 'جاذبه‌ها',
			'tp-places'      => 'شهرستان‌ها',
			'tp-culture'     => 'فرهنگ و غذا',
			'tp-news'        => 'اخبار',
			'tp-faq'         => 'پرسش‌ها',
			'tp-reviews'     => 'نظرها',
			'tp-map'         => 'نقشه',
			'tp-practical'   => 'سفر عملی',
			'tp-sources'     => 'منابع',
		);

		$nav = array();

		foreach ( $snav_ref as $id => $label ) {

			if ( isset( $rendered[ $id ] ) ) {
				$nav[ $id ] = $label;
			}

			if ( 'tp-culture' === $id ) {
				foreach ( $rendered as $rid => $meta ) {
					if ( 'main' === $meta['col'] && ! isset( $snav_ref[ $rid ] ) && '' !== $meta['nav'] ) {
						$nav[ $rid ] = $meta['nav'];
					}
				}
			}
		}

		$snav = '';

		if ( count( $nav ) > 1 ) {

			$links = '';

			foreach ( $nav as $id => $label ) {
				$links .= '<a href="#' . esc_attr( $id ) . '">' . esc_html( $label ) . '</a>';
			}

			$snav = '<nav class="tp-snav" aria-label="' . esc_attr__( 'ناوبری بخش‌های صفحه', 'topersia' ) . '">'
				. '<div class="tp-wrap tp-snav__in">' . $links . '</div></nav>';
		}

		/*
		 * پوستهٔ صفحه عیناً مرجع: `main.main > .wrap > .crumb +
		 * .content-grid > .main-col + aside.rail`.  P5-D219
		 *
		 * مسیر راهنما داخل همان `.wrap` است، نه در یک `.wrap` جدا —
		 * وگرنه پرکردنِ `main` دو بار حساب می‌شود.
		 */
		$body = '';

		if ( '' !== $cols['main'] || '' !== $cols['rail'] ) {

			$body = '<main id="tp-main" class="tp-main"><div class="tp-wrap">'
				. topersia_g_sc_crumbs( array( 'id' => $pid ) )
				. '<div class="tp-content-grid">'
				. '<div class="tp-main-col">' . $cols['main'] . '</div>'
				. '<aside class="tp-rail" aria-label="' . esc_attr__( 'اطلاعات مکمل', 'topersia' ) . '">'
				. $cols['rail'] . '</aside>'
				. '</div></div></main>';
		}

		return '<div class="tp-page">'
			. topersia_g_sc_hero( array( 'id' => $pid ) )
			. topersia_g_sc_stats( array( 'id' => $pid ) )
			. $snav
			. $body
			. topersia_g_mobilebar( $pid, $nav, $rendered )
			. topersia_g_modals( $pid )
			. '</div>';
	}
}

/**
 * نوار پایین موبایل و برگهٔ بخش‌ها.
 *
 * نوار افقی دسکتاپ روی موبایل بد کار می‌کند: بیست برچسب در یک خط اسکرولی
 * که باید افقی گشت تا مقصد پیدا شود. جایش چهار میان‌بر ثابت و یک برگهٔ
 * شماره‌گذاری‌شده می‌آید.
 *
 * برگه از همان `$nav` تغذیه می‌شود که نوار دسکتاپ می‌سازد، پس هیچ‌وقت به
 * بخشی که رندر نشده لینک نمی‌دهد.  P5-D192
 */
if ( ! function_exists( 'topersia_g_mobilebar' ) ) {
	function topersia_g_mobilebar( $post_id, $nav, $rendered = array() ) {

		if ( ! is_array( $nav ) || count( $nav ) < 2 ) {
			return '';
		}

		$icons = array(
			'top'  => '<path d="M12 19V5M5 12l7-7 7 7"/>',
			'star' => '<path d="M12 3.5l2.6 5.3 5.9.9-4.3 4.1 1 5.8-5.2-2.7-5.2 2.7 1-5.8L3.5 9.7l5.9-.9z"/>',
			'pin'  => '<path d="M12 21s7-6.4 7-11a7 7 0 1 0-14 0c0 4.6 7 11 7 11z"/><circle cx="12" cy="10" r="2.6"/>',
			'save' => '<path d="M6 3h12v18l-6-4.5L6 21z"/>',
			'list' => '<path d="M4 6h16M4 12h16M4 18h16"/>',
		);

		$svg = function ( $key ) use ( $icons ) {
			return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7"'
				. ' stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">'
				. $icons[ $key ] . '</svg>';
		};

		/*
		 * ردیف مرجع: بالا · جاذبه‌ها · نقشه · ذخیره · بخش‌ها.  P5-D219
		 * اگر جاذبه‌ای نبود، دکمهٔ دوم به نخستین بخش ستون اصلی می‌رود —
		 * میان‌بری به بخشی که نیست، دکمهٔ مرده است.
		 */
		$second = isset( $rendered['tp-attractions'] ) ? 'tp-attractions' : '';

		if ( '' === $second ) {
			foreach ( $nav as $id => $ignored ) {
				if ( 'tp-map' !== $id ) { $second = $id; break; }
			}
		}

		$row = '<button type="button" data-tp-go="top">' . $svg( 'top' )
			. '<span>' . esc_html__( 'بالا', 'topersia' ) . '</span></button>';

		if ( '' !== $second ) {
			$row .= '<button type="button" data-tp-go="' . esc_attr( $second ) . '">' . $svg( 'star' )
				. '<span>' . esc_html( 'tp-attractions' === $second ? __( 'جاذبه‌ها', 'topersia' ) : $nav[ $second ] ) . '</span></button>';
		}

		if ( isset( $rendered['tp-map'] ) ) {
			$row .= '<button type="button" data-tp-go="tp-map">' . $svg( 'pin' )
				. '<span>' . esc_html__( 'نقشه', 'topersia' ) . '</span></button>';
		}

		$row .= '<button type="button" data-tp-go="save">' . $svg( 'save' )
			. '<span>' . esc_html__( 'ذخیره', 'topersia' ) . '</span></button>'
			. '<button type="button" data-tp-sheet-open>' . $svg( 'list' )
			. '<span>' . esc_html__( 'بخش‌ها', 'topersia' ) . '</span></button>';

		/*
		 * برگهٔ «بخش‌ها» — همان چهار گروه مرجع با برچسب‌های خودش.  P5-D219
		 *
		 * بخش‌هایی که مرجع نداشت در گروه ستونشان می‌آیند: ستون اصلی در
		 * «مطالب»، ستون کناری در «پیوندها». گروهی که هیچ عضوِ رندرشده‌ای
		 * ندارد، سرفصلش هم نمی‌آید.
		 */
		$groups = array(
			'مطالب'      => array(
				'tp-ai' => 'خلاصهٔ هوشمند', 'tp-overview' => 'پاسخ مستقیم', 'tp-gallery' => 'گالری',
				'tp-attractions' => 'جاذبه‌ها', 'tp-places' => 'شهرستان‌ها', 'tp-culture' => 'فرهنگ و غذا',
				'tp-news' => 'اخبار', 'tp-audio' => 'روایت صوتی',
			),
			'مشخصات'     => array(
				'tp-map' => 'نقشه', 'tp-weather' => 'هوای این روزها', 'tp-season' => 'بهترین زمان سفر',
				'tp-geo' => 'اطلاعات جغرافیایی', 'tp-badges' => 'نشان‌ها',
			),
			'پیوندها'     => array(
				'tp-nature' => 'پهنه‌های طبیعی', 'tp-ancient' => 'محوطه‌های باستانی', 'tp-practical' => 'سفر عملی',
				'tp-neighbors' => 'هم‌مرزها', 'tp-routes' => 'مسیرها',
			),
			'پایان صفحه' => array(
				'tp-faq' => 'پرسش‌های متداول', 'tp-reviews' => 'نظر بازدیدکنندگان', 'tp-sources' => 'منابع',
			),
		);

		$known = array();
		foreach ( $groups as $members ) { $known += $members; }

		foreach ( $rendered as $id => $meta ) {
			if ( isset( $known[ $id ] ) || '' === $meta['nav'] ) { continue; }
			$groups[ 'main' === $meta['col'] ? 'مطالب' : 'پیوندها' ][ $id ] = $meta['nav'];
		}

		$items = '';

		foreach ( $groups as $head => $members ) {

			$li = '';

			foreach ( $members as $id => $label ) {
				if ( isset( $rendered[ $id ] ) ) {
					$li .= '<li><a href="#' . esc_attr( $id ) . '">' . esc_html( $label ) . '</a></li>';
				}
			}

			if ( '' !== $li ) {
				$items .= '<li class="tp-sheet__g">' . esc_html( $head ) . '</li>' . $li;
			}
		}

		return '<nav class="tp-mnav" aria-label="' . esc_attr__( 'ناوبری موبایل', 'topersia' ) . '">'
			. '<div class="tp-mnav__row">' . $row . '</div></nav>'
			. '<div class="tp-sheet" id="tpSheet">'
			. '<div class="tp-sheet__bd" data-tp-close></div>'
			. '<div class="tp-sheet__p" role="dialog" aria-modal="true" aria-label="'
			. esc_attr__( 'بخش‌های صفحه', 'topersia' ) . '">'
			. '<h2>' . esc_html__( 'بخش‌های این صفحه', 'topersia' ) . '</h2>'
			. '<ol>' . $items . '</ol></div></div>';
	}
}

/**
 * [tp_culture] — شبکهٔ شش خانوادهٔ فرهنگی.
 *
 * گروه `culture` سیزده رابطه دارد و به‌صورت یک اسلایدر تخت، تودهٔ بی‌شکلی
 * می‌شود. اینجا به شش خانواده تقسیم می‌شود که هرکدام آیکون و شمار دارد.
 * خانوادهٔ هر رابطه در نقشه نشسته (`fam`) و از نوعِ سرِ دیگر مشتق شده.
 *
 * خانوادهٔ بی‌نتیجه کارت نمی‌سازد، و اگر هیچ خانواده‌ای پر نشود کل بخش
 * ناپدید می‌شود — همان قاعدهٔ همیشگی.  P5-D192
 */
if ( ! function_exists( 'topersia_g_families' ) ) {
	function topersia_g_families() {

		$fam = array(
			'artisanat' => array( 'صنایع دستی', 'ARTISANAT',
				'<path d="M12 2l1.8 5.6H20l-4.7 3.4 1.8 5.6L12 13.2 6.9 16.6 8.7 11 4 7.6h6.2z"/>' ),
			'cuisine'   => array( 'خوراک محلی', 'CUISINE',
				'<path d="M3 11h18M5 11V8a3 3 0 016 0v3M13 11V8a3 3 0 016 0v3M4 11v8M20 11v8"/>' ),
			'music'     => array( 'موسیقی و آیین', 'MUSIC & RITUAL',
				'<path d="M9 18V5l10-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="16" cy="16" r="3"/>' ),
			'festivals' => array( 'جشنواره', 'FESTIVALS',
				'<path d="M4 20l6-14 8 6-14 8z"/><path d="M14 4l1.5 1.5M18 8l1.5 1.5M17 3l.8.8"/>' ),
			'seasonal'  => array( 'رویداد فصلی و مذهبی', 'SEASONAL',
				'<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M8 3v4M16 3v4M3 11h18"/>' ),
			'heritage'  => array( 'زبان و پوشاک', 'HERITAGE',
				'<path d="M12 3l4 2v4a8 8 0 01-4 7 8 8 0 01-4-7V5z"/>' ),
		);

		if ( function_exists( 'apply_filters' ) ) {
			$fam = apply_filters( 'topersia_g_families', $fam );
		}

		return $fam;
	}
}

if ( ! function_exists( 'topersia_g_sc_culture' ) ) {
	function topersia_g_sc_culture( $atts = array() ) {

		$pid = topersia_g_pid( $atts );

		if ( ! $pid ) {
			return '';
		}

		$group = topersia_g_group( $pid, 'culture' );

		if ( empty( $group['rels'] ) ) {
			return '';
		}

		/* رابطه‌ها را به خانواده‌شان تقسیم کن، با حفظ ترتیب نقشه */
		$buckets = array();
		foreach ( $group['rels'] as $spec ) {
			if ( empty( $spec['fam'] ) ) { continue; }
			$buckets[ $spec['fam'] ][] = $spec;
		}

		if ( ! $buckets ) {
			return '';
		}

		$cards = '';

		foreach ( topersia_g_families() as $key => $meta ) {

			if ( empty( $buckets[ $key ] ) ) {
				continue;
			}

			$ids = topersia_g_rel_ids( $pid, $buckets[ $key ] );

			if ( ! $ids ) {
				continue;
			}

			$chips = '';
			foreach ( $ids as $rel_id ) {
				$view   = topersia_g_view_id( $rel_id );
				$chips .= '<li><a href="' . esc_url( get_permalink( $view ) ) . '">'
					. esc_html( topersia_g_name( $view ) ) . '</a></li>';
			}

			$cards .= '<article class="tp-culture-card">'
				. '<span class="tp-culture-card__count">' . topersia_g_fa( count( $ids ) ) . '</span>'
				. '<div class="tp-culture-card__head">'
				. '<span class="tp-culture-card__icon" aria-hidden="true">'
				. '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"'
				. ' stroke-linecap="round" stroke-linejoin="round">' . $meta[2] . '</svg></span>'
				. '<div class="tp-culture-card__title">'
				. '<span class="tp-culture-card__kicker">' . esc_html( $meta[1] ) . '</span>'
				. '<h3>' . esc_html( $meta[0] ) . '</h3>'
				. '</div></div>'
				. '<ul class="tp-culture-card__list">' . $chips . '</ul>'
				. '</article>';
		}

		if ( '' === $cards ) {
			return '';
		}

		/* `#culture` در مرجع بخشِ ستون اصلی است، نه کارت ستون کناری. */
		return '<section id="tp-culture" class="tp-section">'
			. topersia_g_section_head( $group, topersia_g_name( $pid ) )
			. '<div class="tp-culture-grid">' . $cards . '</div></section>';
	}
}

/**
 * مودال نقشه و مودال گالری.
 *
 * هیچ‌کدام دادهٔ تازه نمی‌خواهند: نقشه همان مختصاتِ کارت نقشه را بزرگ
 * نشان می‌دهد و گالری همان `featured_image_gallery` را.
 *
 * هر مودال فقط وقتی ساخته می‌شود که ناحیهٔ متناظرش محتوا داشته باشد،
 * وگرنه دکمه‌ای که بازش کند روی صفحه نیست.  P5-D192
 */
if ( ! function_exists( 'topersia_g_modals' ) ) {
	function topersia_g_modals( $post_id ) {

		$out    = '';
		$name   = topersia_g_name( $post_id );
		$coords = (string) topersia_g_raw( $post_id, 'geo_coordinates' );

		if ( '' !== (string) $coords ) {

			/* مرجع پرده ندارد: کلیک روی خودِ `.modal` می‌بنددش. */
			$out .= '<div class="tp-modal" id="tpMapModal" role="dialog" aria-modal="true"'
				. ' aria-labelledby="tpMapModalTitle">'
				. '<div class="tp-modal__card">'
				. '<div class="tp-modal__head">'
				. '<h3 id="tpMapModalTitle">' . esc_html( sprintf(
					/* translators: %s نام موجودیت */
					__( 'نقشهٔ %s', 'topersia' ), $name ) ) . '</h3>'
				. '<button class="tp-modal__close" type="button" data-tp-close'
				. ' aria-label="' . esc_attr__( 'بستن', 'topersia' ) . '">&times;</button>'
				. '</div>'
				. '<div class="tp-modal__map" role="img" aria-label="'
				. esc_attr( sprintf( __( 'نمای بزرگ نقشهٔ %s', 'topersia' ), $name ) ) . '">'
				/* عیناً مرجع: بی‌کلاس (کلاسِ نقشهٔ کارت ارتفاع ۲۳۰ و پس‌زمینه
				   می‌آورد) و با همان الگوی شبکهٔ ۴۰ پیکسلی. */
				. '<svg viewBox="0 0 800 480" aria-hidden="true">'
				. '<defs><pattern id="tpGridL' . absint( $post_id ) . '" width="40" height="40" patternUnits="userSpaceOnUse">'
				. '<path d="M40 0H0V40" fill="none" stroke="currentColor" stroke-opacity=".18" stroke-width="1"/>'
				. '</pattern></defs>'
				. '<rect width="800" height="480" fill="url(#tpGridL' . absint( $post_id ) . ')"/>'
				. '<path d="M90 130 C 200 80, 340 100, 470 84 C 590 72, 700 130, 720 220'
				. ' C 740 320, 620 400, 500 420 C 380 440, 220 430, 140 390'
				. ' C 70 350, 50 220, 90 130 Z" fill="none" stroke="currentColor"'
				. ' stroke-width="2" stroke-dasharray="6 5" opacity=".6"/></svg>'
				. '<div class="tp-modal__pin"></div>'
				. '</div>'
				. '<div class="tp-modal__meta">'
				. esc_html__( 'مختصات مرکز', 'topersia' ) . ': '
				. '<span class="tp-lat" dir="ltr">' . esc_html( $coords ) . '</span>'
				. '</div></div></div>';
		}

		/* همان فهرستی که موزاییک از آن ساخته شد — یک منبع، دو مصرف. */
		$shots = topersia_g_gallery_shots( topersia_g_raw( $post_id, 'featured_image_gallery' ) );

		if ( empty( $shots ) ) {
			return $out;
		}

		$items = '';
		$srcs  = array();

		foreach ( $shots as $n => $shot ) {

			/* الگوی کاشی پهن در مرجع: نخستین و نهمین. */
			$wide = ( 0 === $n % 8 );

			$items .= '<button class="tp-gallery-modal__item'
				. ( $wide ? ' tp-gallery-modal__item--wide' : '' ) . '" type="button"'
				. ' data-tp-shot="' . esc_attr( $shot['id'] ) . '"'
				. ' aria-label="' . esc_attr( $shot['label'] ) . '">'
				. $shot['img']
				. ( '' !== $shot['label']
					? '<span class="tp-gallery-modal__cap">' . esc_html( $shot['label'] )
						. ( '' !== $shot['place'] ? ' <small>' . esc_html( $shot['place'] ) . '</small>' : '' )
						. '</span>'
					: '' )
				. '</button>';

			$srcs[] = array(
				'id'  => $shot['id'],
				'src' => $shot['full'],
				'alt' => $shot['label'],
			);
		}

		$out .= '<div class="tp-gallery-modal" id="tpGalleryModal" role="dialog" aria-modal="true"'
			. ' aria-labelledby="tpGalleryModalTitle"'
			. " data-tp-shots='" . esc_attr( wp_json_encode( $srcs ) ) . "'>"
			. '<div class="tp-gallery-modal__head"><div>'
			. '<h3 class="tp-gallery-modal__title" id="tpGalleryModalTitle">'
			. esc_html( sprintf(
				/* translators: %s نام موجودیت */
				__( 'گالری کامل %s', 'topersia' ), $name ) )
			. '<small>' . esc_html( sprintf(
				/* translators: %s شمار تصویر */
				__( '%s تصویر', 'topersia' ), topersia_g_fa( count( $shots ) ) ) ) . '</small></h3>'
			. '</div>'
			. '<button class="tp-gallery-modal__close" type="button" data-tp-close'
			. ' aria-label="' . esc_attr__( 'بستن گالری', 'topersia' ) . '">&times;</button>'
			. '</div>'
			. '<div class="tp-gallery-modal__grid">' . $items . '</div></div>'

			/*
			 * نمای تک‌عکس — همان شاسی مودال.  P5-D219
			 *
			 * مرجع فقط افکت `scale` داشت چون عکس واقعی نداشت. کلیک روی
			 * هر کاشی — چه در موزاییک، چه در مودال — همان عکس را در
			 * اندازهٔ کامل باز می‌کند، با قبلی و بعدی. دکمه‌ها همان
			 * کلاس دکمهٔ بستن را دارند، پس هیچ قاعدهٔ تازه‌ای لازم نشد.
			 */
			. '<div class="tp-gallery-modal tp-gallery-modal--solo" id="tpGallerySolo"'
			. ' role="dialog" aria-modal="true"'
			. ' aria-label="' . esc_attr__( 'نمای کامل تصویر', 'topersia' ) . '">'
			. '<div class="tp-gallery-modal__head"><div></div>'
			. '<button class="tp-gallery-modal__close" type="button" data-tp-shot-prev'
			. ' aria-label="' . esc_attr__( 'تصویر قبلی', 'topersia' ) . '">›</button>'
			. '<button class="tp-gallery-modal__close" type="button" data-tp-shot-next'
			. ' aria-label="' . esc_attr__( 'تصویر بعدی', 'topersia' ) . '">‹</button>'
			. '<button class="tp-gallery-modal__close" type="button" data-tp-close'
			. ' aria-label="' . esc_attr__( 'بستن تصویر', 'topersia' ) . '">&times;</button>'
			. '</div>'
			. '<div class="tp-gallery-modal__grid"><img alt="" decoding="async"></div>'
			. '</div>';

		return $out;
	}
}

/* =========================================================================
   ۶ — ثبت
   ========================================================================= */

if ( ! function_exists( 'topersia_g_register' ) ) {
	function topersia_g_register() {

		$shortcodes = array(
			'tp_page'      => 'topersia_g_sc_page',
			'tp_culture'   => 'topersia_g_sc_culture',
			'tp_hero'      => 'topersia_g_sc_hero',
			'tp_actionbar' => 'topersia_g_sc_actionbar',
			'tp_crumbs'    => 'topersia_g_sc_crumbs',
			'tp_stats'     => 'topersia_g_sc_stats',
			'tp_facts'     => 'topersia_g_sc_facts',
			'tp_badges'    => 'topersia_g_sc_badges',
			'tp_seasons'   => 'topersia_g_sc_seasons',
			'tp_weather'   => 'topersia_g_sc_weather',
			'tp_map'       => 'topersia_g_sc_map',
			'tp_slider'    => 'topersia_g_sc_slider',
			'tp_relgrid'   => 'topersia_g_sc_relgrid',
			'tp_gallery'   => 'topersia_g_sc_gallery',
			'tp_audio'     => 'topersia_g_sc_audio',
			'tp_faq'       => 'topersia_g_sc_faq',
			'tp_sources'   => 'topersia_g_sc_sources',
			'tp_ai'        => 'topersia_g_sc_ai',
			'tp_overview'  => 'topersia_g_sc_overview',
			'tp_news'      => 'topersia_g_sc_news',
			'tp_reviews'   => 'topersia_g_sc_reviews',
		);

		foreach ( $shortcodes as $tag => $callback ) {

			/* پیشوند tp_ کوتاه است؛ گارد لازم است تا افزونهٔ دیگری بی‌صدا برنده نشود. */
			if ( function_exists( 'shortcode_exists' ) && shortcode_exists( $tag ) ) {

				if ( function_exists( 'topersia_log' ) ) {
					topersia_log( 'شورت‌کد ' . $tag . ' از قبل ثبت شده بود؛ ثبت نشد.', 'warning', 'render' );
				}

				continue;
			}

			add_shortcode( $tag, $callback );
		}
	}
}

if ( function_exists( 'topersia_render_ready' ) && topersia_render_ready() ) {
	topersia_g_register();
}
