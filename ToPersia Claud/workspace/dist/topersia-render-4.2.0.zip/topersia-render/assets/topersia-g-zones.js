/*!
 * ToPersia — رفتار قالب دستهٔ G
 * نسخه: 3.0.0 — انتقال مستقیم از اسکریپت‌های فایل مرجع.  P5-D219
 *
 * منتقل شد: ارتفاع هدر · حالت فعال نوار بخش‌ها · اسلایدرها · مدیر مودال
 * (قفل body، Esc، دام فوکوس، کلیک بیرون) · گالری و نمای تک‌عکس · بلوک
 * هوش مصنوعی · نوار کنش و جابه‌جایی دسکتاپ/موبایل · نوار پایین موبایل و
 * برگهٔ بخش‌ها · دکمهٔ «N مورد دیگر» · هوای سه روز.
 *
 * منتقل نشد: دادهٔ ساختگی مرجع — aiData · TP · TP_REL · نمونهٔ هوا.
 * داده از PHP می‌آید، یا از نقطهٔ REST.
 */
( function () {
	'use strict';

	var page = document.querySelector( '.tp-page' );

	if ( ! page ) {
		return;
	}

	/* ══ ارتفاع هدر چسبان ═══════════════════════════════════════════════
	   مرجع هدر خودش را داشت با ارتفاع ثابت ۶۴. اینجا هدر مال قالب است و
	   ارتفاعش با تنظیمات عوض می‌شود، پس اندازه گرفته می‌شود نه حدس زده.
	   شیوه‌نامه همان عدد مرجع را پیش‌فرض دارد، پس اگر هدر چسبانی نبود
	   هیچ چیز عوض نمی‌شود.
	   ────────────────────────────────────────────────────────────────── */
	( function () {

		function sticky() {

			var all = document.querySelectorAll( 'header, .whb-header, #masthead, .site-header' );

			for ( var i = 0; i < all.length; i ++ ) {

				var el = all[ i ];

				if ( page.contains( el ) ) {
					continue;
				}

				var pos = window.getComputedStyle( el ).position;

				if ( 'sticky' === pos || 'fixed' === pos ) {
					return Math.round( el.getBoundingClientRect().height );
				}
			}

			return 0;
		}

		function apply() {

			var h = sticky();

			if ( h > 0 ) {
				page.style.setProperty( '--tp-header-h', h + 'px' );
			} else {
				page.style.removeProperty( '--tp-header-h' );
			}
		}

		apply();
		window.addEventListener( 'resize', apply, { passive: true } );
		window.addEventListener( 'load', apply, { once: true } );
	} )();

	/* ══ حالت فعال نوار بخش‌ها ═══════════════════════════════════════════
	   فهرست بخش‌ها از خودِ پیوندهای نوار می‌آید، نه از یک آرایهٔ ثابت:
	   نوار را PHP از ناحیه‌هایی می‌سازد که واقعاً محتوا داشتند، پس هر
	   فهرست ثابتی روی سیزده نوع پست غلط می‌شد.
	   ────────────────────────────────────────────────────────────────── */
	( function () {

		var nav = page.querySelector( '.tp-snav' );

		if ( ! nav ) {
			return;
		}

		var links = [].slice.call( nav.querySelectorAll( 'a' ) );
		var byId  = {};
		var ids   = [];

		links.forEach( function ( a ) {

			var href = a.getAttribute( 'href' ) || '';

			if ( '#' === href.charAt( 0 ) ) {
				byId[ href.slice( 1 ) ] = a;
				ids.push( href.slice( 1 ) );
			}
		} );

		if ( ! ids.length ) {
			return;
		}

		var lockUntil = 0;

		function setActive( id ) {

			links.forEach( function ( a ) { a.classList.remove( 'tp-is-active' ); } );

			var link = byId[ id ];

			if ( ! link ) {
				return;
			}

			link.classList.add( 'tp-is-active' );

			try {
				link.scrollIntoView( { block: 'nearest', inline: 'center', behavior: 'smooth' } );
			} catch ( e ) {}
		}

		function pick() {

			if ( Date.now() < lockUntil ) {
				return;
			}

			var threshold = window.innerWidth <= 720 ? 130 : 150;
			var bestId    = null;
			var bestTop   = -Infinity;

			ids.forEach( function ( id ) {

				var el = document.getElementById( id );

				if ( ! el ) {
					return;
				}

				var top = el.getBoundingClientRect().top;

				if ( top <= threshold && top > bestTop ) {
					bestTop = top;
					bestId  = id;
				}
			} );

			setActive( bestId || ids[ 0 ] );
		}

		links.forEach( function ( a ) {
			a.addEventListener( 'click', function () {
				var href = a.getAttribute( 'href' ) || '';
				if ( '#' !== href.charAt( 0 ) ) { return; }
				setActive( href.slice( 1 ) );
				lockUntil = Date.now() + 1600;
			} );
		} );

		window.addEventListener( 'hashchange', function () {
			var id = ( location.hash || '' ).replace( '#', '' );
			if ( id ) { setActive( id ); lockUntil = Date.now() + 1200; }
		} );

		var ticking = false;

		window.addEventListener( 'scroll', function () {

			if ( ticking ) {
				return;
			}

			ticking = true;

			window.requestAnimationFrame( function () {
				pick();
				ticking = false;
			} );
		}, { passive: true } );

		window.addEventListener( 'resize', function () { lockUntil = 0; pick(); }, { passive: true } );

		if ( location.hash ) {
			setActive( location.hash.replace( '#', '' ) );
		} else {
			pick();
		}

		window.addEventListener( 'load', pick, { once: true } );
	} )();

	/* ══ اسلایدرها ══════════════════════════════════════════════════════ */
	Array.prototype.forEach.call( page.querySelectorAll( '[data-target]' ), function ( btn ) {

		btn.addEventListener( 'click', function () {

			var el = document.getElementById( btn.getAttribute( 'data-target' ) );

			if ( ! el ) {
				return;
			}

			var amount = Math.round( el.clientWidth * 0.85 ) * ( '1' === btn.getAttribute( 'data-dir' ) ? -1 : 1 );

			el.scrollBy( { left: amount, behavior: 'smooth' } );
		} );
	} );

	/* ══ مدیر مودال ═════════════════════════════════════════════════════
	   قفل روی `body` و `documentElement` هر دو: iOS فقط دومی را می‌فهمد
	   و اندروید فقط اولی را.
	   ────────────────────────────────────────────────────────────────── */
	var lastFocus = null;
	var openStack = [];

	function openModal( modal, focusEl ) {

		if ( ! modal ) {
			return;
		}

		if ( ! openStack.length ) {
			lastFocus = document.activeElement;
			document.body.style.overflow = 'hidden';
			document.documentElement.style.overflow = 'hidden';
		}

		openStack.push( modal );
		modal.classList.add( 'tp-show' );

		if ( focusEl && focusEl.focus ) {
			focusEl.focus();
		}
	}

	function closeModal( modal ) {

		if ( ! modal ) {
			return;
		}

		modal.classList.remove( 'tp-show' );
		openStack = openStack.filter( function ( one ) { return one !== modal; } );

		if ( openStack.length ) {
			return;
		}

		document.body.style.overflow = '';
		document.documentElement.style.overflow = '';

		if ( lastFocus && lastFocus.focus ) {
			lastFocus.focus();
		}

		lastFocus = null;
	}

	function trapFocus( modal ) {

		if ( ! modal ) {
			return;
		}

		modal.addEventListener( 'keydown', function ( e ) {

			if ( 'Tab' !== e.key || ! modal.classList.contains( 'tp-show' ) ) {
				return;
			}

			var f = modal.querySelectorAll( 'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])' );

			if ( ! f.length ) {
				return;
			}

			var first = f[ 0 ];
			var last  = f[ f.length - 1 ];

			if ( e.shiftKey && document.activeElement === first ) {
				e.preventDefault();
				last.focus();
			} else if ( ! e.shiftKey && document.activeElement === last ) {
				e.preventDefault();
				first.focus();
			}
		} );
	}

	var mapModal    = document.getElementById( 'tpMapModal' );
	var galleryBox  = document.getElementById( 'tpGalleryModal' );
	var soloBox     = document.getElementById( 'tpGallerySolo' );

	[ mapModal, galleryBox, soloBox ].forEach( trapFocus );

	[ mapModal, galleryBox, soloBox ].forEach( function ( modal ) {

		if ( ! modal ) {
			return;
		}

		modal.addEventListener( 'click', function ( e ) {
			if ( e.target === modal ) { closeModal( modal ); }
		} );
	} );

	document.addEventListener( 'keydown', function ( e ) {

		if ( 'Escape' !== e.key || ! openStack.length ) {
			return;
		}

		/* یک پله عقب، نه همه با هم. */
		closeModal( openStack[ openStack.length - 1 ] );
	} );

	page.addEventListener( 'click', function ( e ) {

		var target = e.target.closest ? e.target : e.target.parentNode;

		if ( ! target || ! target.closest ) {
			return;
		}

		if ( target.closest( '[data-tp-map-open]' ) && mapModal ) {
			openModal( mapModal, mapModal.querySelector( '[data-tp-close]' ) );
		}

		if ( target.closest( '[data-tp-gallery-open]' ) && galleryBox ) {
			openModal( galleryBox, galleryBox.querySelector( '[data-tp-close]' ) );
		}
	} );

	document.addEventListener( 'click', function ( e ) {

		if ( ! e.target.closest ) {
			return;
		}

		var x = e.target.closest( '[data-tp-close]' );

		if ( ! x ) {
			return;
		}

		var modal = x.closest( '.tp-modal, .tp-gallery-modal, .tp-sheet' );

		if ( modal && modal.classList.contains( 'tp-sheet' ) ) {
			modal.removeAttribute( 'open' );
			return;
		}

		closeModal( modal );
	} );

	/* ══ گالری — نمای تک‌عکس ════════════════════════════════════════════
	   کلیک روی هر کاشی، چه در موزاییک چه در مودال، همان عکس را در
	   اندازهٔ کامل نشان می‌دهد. فهرست عکس‌ها را PHP روی مودال گذاشته،
	   پس هر دو جا از یک ترتیب می‌خوانند.
	   ────────────────────────────────────────────────────────────────── */
	( function () {

		if ( ! soloBox || ! galleryBox ) {
			return;
		}

		var shots = [];

		try {
			shots = JSON.parse( galleryBox.getAttribute( 'data-tp-shots' ) || '[]' );
		} catch ( err ) {
			shots = [];
		}

		if ( ! shots.length ) {
			return;
		}

		var img = soloBox.querySelector( 'img' );
		var at  = 0;

		function show( index ) {

			at = ( index + shots.length ) % shots.length;

			img.setAttribute( 'src', shots[ at ].src );
			img.setAttribute( 'alt', shots[ at ].alt || '' );
		}

		page.addEventListener( 'click', function ( e ) {

			if ( ! e.target.closest ) {
				return;
			}

			var tile = e.target.closest( '[data-tp-shot]' );

			if ( ! tile ) {
				return;
			}

			var id = tile.getAttribute( 'data-tp-shot' );

			for ( var i = 0; i < shots.length; i ++ ) {
				if ( String( shots[ i ].id ) === String( id ) ) { show( i ); break; }
			}

			openModal( soloBox, soloBox.querySelector( '[data-tp-close]' ) );
		} );

		soloBox.addEventListener( 'click', function ( e ) {

			if ( ! e.target.closest ) {
				return;
			}

			if ( e.target.closest( '[data-tp-shot-next]' ) ) { show( at + 1 ); }
			if ( e.target.closest( '[data-tp-shot-prev]' ) ) { show( at - 1 ); }
		} );

		document.addEventListener( 'keydown', function ( e ) {

			if ( ! soloBox.classList.contains( 'tp-show' ) ) {
				return;
			}

			if ( 'ArrowLeft' === e.key ) { show( at + 1 ); }
			if ( 'ArrowRight' === e.key ) { show( at - 1 ); }
		} );
	} )();

	/* ══ بلوک هوش مصنوعی ════════════════════════════════════════════════ */
	( function () {

		var out = page.querySelector( '[data-tp-ai-out]' );

		if ( ! out ) {
			return;
		}

		var data = {};

		try {
			data = JSON.parse( out.getAttribute( 'data-tp-ai' ) || '{}' );
		} catch ( err ) {
			data = {};
		}

		var body  = out.querySelector( 'p' );
		var label = out.querySelector( '[data-tp-ai-type]' );

		Array.prototype.forEach.call( page.querySelectorAll( '[data-ai]' ), function ( btn ) {

			btn.addEventListener( 'click', function () {

				var kind = btn.getAttribute( 'data-ai' );

				if ( 'copy' === kind ) {

					if ( navigator.clipboard && navigator.clipboard.writeText ) {

						navigator.clipboard.writeText( body.textContent || '' ).then( function () {

							var was = btn.innerHTML;

							btn.textContent = 'کپی شد ✓';
							btn.disabled    = true;

							window.setTimeout( function () {
								btn.innerHTML = was;
								btn.disabled  = false;
							}, 1500 );
						} ).catch( function () {} );
					}

					return;
				}

				if ( ! data[ kind ] ) {
					return;
				}

				body.textContent = data[ kind ];

				if ( label ) {
					label.textContent = btn.textContent.trim();
				}

				Array.prototype.forEach.call( page.querySelectorAll( '[data-ai]' ), function ( b ) {
					if ( 'copy' !== b.getAttribute( 'data-ai' ) ) {
						b.classList.toggle( 'tp-is-active', b === btn );
					}
				} );
			} );
		} );
	} )();

	/* ══ دکمهٔ «N مورد دیگر» ═════════════════════════════════════════════ */
	Array.prototype.forEach.call( page.querySelectorAll( '[data-tp-more]' ), function ( btn ) {

		btn.addEventListener( 'click', function () {

			var card = btn.closest( '.tp-rail-card' ) || btn.parentNode;

			Array.prototype.forEach.call( card.querySelectorAll( '[data-tp-rest-item]' ), function ( one ) {
				one.removeAttribute( 'hidden' );
			} );

			btn.remove();
		} );
	} );

	/* ══ نوار کنش ═══════════════════════════════════════════════════════
	   یک عنصر، دو جای نشستن — در دسکتاپ کارتی در ستون کناری، در موبایل
	   نواری بالای مسیر راهنما. دو نسخه یعنی دو وضعیت «ذخیره‌شده» که با
	   هم واگرا می‌شوند.
	   ────────────────────────────────────────────────────────────────── */
	( function () {

		var bar = page.querySelector( '[data-tp-actionbar]' );

		if ( ! bar ) {
			return;
		}

		var home   = bar.parentNode;
		var crumb  = page.querySelector( '.tp-crumb' );
		var narrow = window.matchMedia( '(max-width: 720px)' );

		function place() {

			if ( narrow.matches ) {

				if ( crumb && bar.nextSibling !== crumb ) {
					crumb.parentNode.insertBefore( bar, crumb );
				}

				bar.className = 'tp-actionbar';

			} else {

				if ( bar.parentNode !== home ) {
					home.appendChild( bar );
				}

				bar.className = 'tp-rail-card tp-actionbar tp-actionbar--rail';
			}
		}

		place();

		if ( narrow.addEventListener ) {
			narrow.addEventListener( 'change', place );
		} else if ( narrow.addListener ) {
			narrow.addListener( place );
		}

		var note = bar.querySelector( '.tp-act__note' );

		function say( text ) {

			if ( ! note ) {
				return;
			}

			note.textContent = text;

			window.setTimeout( function () {
				if ( note.textContent === text ) { note.textContent = ''; }
			}, 2600 );
		}

		var share = bar.querySelector( '[data-tp-share]' );

		if ( share ) {

			share.addEventListener( 'click', function () {

				var data = { title: document.title, url: location.href };

				if ( navigator.share ) {
					navigator.share( data ).catch( function () {} );
					return;
				}

				if ( navigator.clipboard ) {
					navigator.clipboard.writeText( location.href ).then( function () {
						say( 'نشانی کپی شد.' );
					} ).catch( function () {} );
				}
			} );
		}

		var save = bar.querySelector( '[data-tp-save]' );

		if ( save ) {

			save.addEventListener( 'click', function () {

				var on = 'true' === save.getAttribute( 'aria-pressed' );

				save.setAttribute( 'aria-pressed', on ? 'false' : 'true' );
				save.classList.toggle( 'tp-is-on', ! on );

				say( on ? 'از فهرست شما برداشته شد.' : 'در حساب شما ذخیره شد.' );
			} );
		}
	} )();

	/* ══ نوار پایین موبایل و برگهٔ بخش‌ها ══════════════════════════════ */
	( function () {

		var mnav = page.querySelector( '.tp-mnav' );

		if ( ! mnav ) {
			return;
		}

		var sheet = document.getElementById( 'tpSheet' );

		mnav.addEventListener( 'click', function ( e ) {

			var btn = e.target.closest ? e.target.closest( '[data-tp-go]' ) : null;

			if ( btn ) {

				var key = btn.getAttribute( 'data-tp-go' );

				if ( 'top' === key ) {
					window.scrollTo( { top: 0, behavior: 'smooth' } );
					return;
				}

				if ( 'save' === key ) {
					var s = page.querySelector( '[data-tp-save]' );
					if ( s ) { s.click(); }
					return;
				}

				var el = document.getElementById( key );

				if ( el ) {
					el.scrollIntoView( { behavior: 'smooth', block: 'start' } );
				}

				return;
			}

			if ( e.target.closest && e.target.closest( '[data-tp-sheet-open]' ) && sheet ) {
				sheet.setAttribute( 'open', '' );
			}
		} );

		if ( sheet ) {

			sheet.addEventListener( 'click', function ( e ) {
				if ( e.target.hasAttribute( 'data-tp-close' ) || 'A' === e.target.tagName ) {
					sheet.removeAttribute( 'open' );
				}
			} );

			document.addEventListener( 'keydown', function ( e ) {
				if ( 'Escape' === e.key ) { sheet.removeAttribute( 'open' ); }
			} );
		}
	} )();

	/* ══ نشانگر نقشه ════════════════════════════════════════════════════ */
	Array.prototype.forEach.call( page.querySelectorAll( '.tp-map-pin' ), function ( pin ) {

		pin.addEventListener( 'click', function () {

			pin.style.transform = 'translate(-50%,-50%) scale(1.2)';

			window.setTimeout( function () {
				pin.style.transform = 'translate(-50%,-50%)';
			}, 160 );
		} );
	} );

	/* ══ هوای سه روز ════════════════════════════════════════════════════
	   دادهٔ زنده است و داخل HTML کش‌شده نمی‌آید، وگرنه هر بازدیدکننده
	   هوای روزِ ساختِ کش را می‌بیند. پس پس از بارگذاری از نقطهٔ REST
	   خوانده می‌شود — همان چیزی که مرجع با `demo` جایش را نگه داشته بود.
	   ────────────────────────────────────────────────────────────────── */
	( function () {

		var box = page.querySelector( '[data-tp-weather]' );

		if ( ! box || ! window.fetch ) {
			return;
		}

		var root = ( window.TopersiaG && window.TopersiaG.rest ) || '';

		if ( ! root ) {
			return;
		}

		var note = box.parentNode.querySelector( '.tp-wx__src' );

		var ICON = {
			sun:  '<circle cx="12" cy="12" r="4.4"/><path d="M12 2.6v2.2M12 19.2v2.2M2.6 12h2.2M19.2 12h2.2M5.4 5.4l1.6 1.6M17 17l1.6 1.6M18.6 5.4L17 7M7 17l-1.6 1.6"/>',
			part: '<circle cx="9" cy="9" r="3.4"/><path d="M6.5 18h9a3.5 3.5 0 0 0 0-7 5 5 0 0 0-9.6 1.4A3 3 0 0 0 6.5 18z"/>',
			wind: '<path d="M3 8h11a3 3 0 1 0-3-3M3 13h15a3 3 0 1 1-3 3M3 18h8"/>',
			rain: '<path d="M6.5 15h9a3.5 3.5 0 0 0 0-7 5 5 0 0 0-9.6 1.4A3 3 0 0 0 6.5 15z"/><path d="M8 18l-1 2M12 18l-1 2M16 18l-1 2"/>',
			snow: '<path d="M6.5 15h9a3.5 3.5 0 0 0 0-7 5 5 0 0 0-9.6 1.4A3 3 0 0 0 6.5 15z"/><path d="M9 19h.01M12 20h.01M15 19h.01"/>'
		};

		function fa( n ) {
			return String( n ).replace( /[0-9]/g, function ( d ) { return '۰۱۲۳۴۵۶۷۸۹'[ d ]; } );
		}

		fetch( root + '?coords=' + encodeURIComponent( box.getAttribute( 'data-tp-coords' ) || '' ) )
			.then( function ( r ) { return r.ok ? r.json() : null; } )
			.then( function ( data ) {

				if ( ! data || ! data.days || ! data.days.length ) {
					if ( note ) { note.textContent = ''; }
					return;
				}

				box.innerHTML = data.days.map( function ( x ) {

					return '<div class="tp-wx__day"><span class="tp-wx__d">' + x.d + '</span>'
						+ '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round">'
						+ ( ICON[ x.i ] || ICON.sun ) + '</svg>'
						+ '<b>' + fa( x.t ) + '°</b><span class="tp-wx__n">' + fa( x.n ) + '°</span>'
						+ '<span class="tp-wx__s">' + x.s + '</span></div>';
				} ).join( '' );

				if ( note ) {
					note.textContent = data.note || '';
				}
			} )
			.catch( function () {
				if ( note ) { note.textContent = ''; }
			} );
	} )();

}() );
