/*!
 * ToPersia — رفتار قالب دستهٔ G
 * نسخه: 3.0.0 — انتقال مستقیم از اسکریپت‌های فایل مرجع.  P5-D219
 *
 * منتقل شد: ارتفاع هدر · حالت فعال نوار بخش‌ها · اسلایدرها · مدیر مودال
 * (قفل body، Esc، دام فوکوس، کلیک بیرون) · گالری و نمای تک‌عکس · بلوک
 * هوش مصنوعی · نوار کنش و جابه‌جایی دسکتاپ/موبایل · نوار پایین موبایل و
 * برگهٔ بخش‌ها · دکمهٔ «N مورد دیگر» · هوای سه روز.
 *
 * منتقل نشد: دادهٔ ساختگی مرجع — aiData · TP · TP_REL · نمونهٔ هوا.
 * داده از PHP می‌آید، یا از نقطهٔ REST.
 */
( function () {
	'use strict';

	var page = document.querySelector( '.tp-page' );

	if ( ! page ) {
		return;
	}

	/* ══ هدر چسبان و نوار بخش‌ها — P5-D223 ════════════════════════════════
	   بالای نوار = پایینِ واقعیِ هدر چسبانِ وودمارت، بی‌فاصله.

	   «ارتفاع هدر» کافی نبود: وودمارت هدر را یا خودش می‌چسباند
	   (`.whb-sticked`) یا نسخهٔ دومی از آن را از بالا می‌لغزاند
	   (`.whb-clone`)، و در حالت «پنهان هنگام اسکرول» هدر بالا و پایین
	   می‌رود. نوار مدیریت وردپرس هم ۳۲ پیکسل بالاتر از همه است. پس پایینِ
	   هر چیزِ ثابت یا چسبانی که همین حالا به لبهٔ بالای صفحه چسبیده
	   اندازه گرفته می‌شود — در هر فریمِ اسکرول، و تا پایان هر گذار.

	   سه عدد روی `.tp-page` می‌نشیند:
	     --tp-snav-top   پایینِ هدر
	     --tp-header-h   همان — ستون کناری چسبان از آن می‌خواند
	     --tp-snav-h     بلندی نوار؛ لنگر هر بخش = هدر + نوار
	   ────────────────────────────────────────────────────────────────── */
	/* -۱ یعنی «هنوز اندازه نگرفته» — تا نخستین اندازه، حتی صفر، نوشته شود. */
	var snavTop = -1;
	var snavH   = -1;

	( function () {

		var nav   = page.querySelector( '.tp-snav' );
		var HEADS = '#wpadminbar, .whb-header, .whb-main-header, .whb-clone, .whb-sticky-row,'
			+ ' header, .site-header, #masthead';
		var heads = [];
		var stuck = null;
		var until = 0;
		var busy  = false;

		function collectHeads() {
			heads = [].slice.call( document.querySelectorAll( HEADS ) ).filter( function ( el ) {
				return ! page.contains( el );
			} );
		}

		/*
		 * پایینِ «پشتهٔ بالا» — هر چیزِ ثابت یا چسبانی که به لبهٔ بالا یا
		 * به پایینِ چیزِ بالاییِ دیگری چسبیده است.
		 *
		 * نوار مدیریت ۰ تا ۳۲ است و هدرِ وودمارت زیرش از ۳۲ شروع می‌شود؛
		 * شرطِ «بالایش صفر باشد» هدر را نمی‌شمرد و نوار زیرِ هدر می‌رفت.
		 * پس از بالا به پایین روی هم چیده می‌شوند و هر کدام که به پایینِ
		 * پشته برسد، پشته را بلندتر می‌کند.
		 */
		function headerBottom() {

			var boxes = [];

			for ( var i = 0; i < heads.length; i ++ ) {

				var cs = window.getComputedStyle( heads[ i ] );

				if ( 'fixed' !== cs.position && 'sticky' !== cs.position ) { continue; }
				if ( 'none' === cs.display || 'hidden' === cs.visibility || 0 === parseFloat( cs.opacity ) ) { continue; }

				var r = heads[ i ].getBoundingClientRect();

				if ( r.height >= 1 && r.bottom > 0 ) {
					boxes.push( r );
				}
			}

			boxes.sort( function ( a, b ) { return a.top - b.top; } );

			var bottom = 0;

			for ( var k = 0; k < boxes.length; k ++ ) {
				if ( boxes[ k ].top <= bottom + 1 && boxes[ k ].bottom > bottom ) {
					bottom = boxes[ k ].bottom;
				}
			}

			return Math.max( 0, Math.round( bottom ) );
		}

		function apply() {

			var top = headerBottom();

			if ( top !== snavTop ) {
				snavTop = top;
				page.style.setProperty( '--tp-snav-top', top + 'px' );
				page.style.setProperty( '--tp-header-h', top + 'px' );
			}

			if ( ! nav ) {
				return;
			}

			var h = nav.offsetHeight;

			if ( h && h !== snavH ) {
				snavH = h;
				page.style.setProperty( '--tp-snav-h', h + 'px' );
			}

			/* چسبیده یعنی جای طبیعیِ نوار از خطِ چسبیدن بالاتر رفته. */
			var prev    = nav.previousElementSibling;
			var natural = prev
				? prev.getBoundingClientRect().bottom + ( parseFloat( window.getComputedStyle( nav ).marginTop ) || 0 )
				: nav.getBoundingClientRect().top;
			var now     = h > 0 && natural < top - 0.5;

			if ( now !== stuck ) {
				stuck = now;
				nav.classList.toggle( 'tp-is-stuck', now );
			}
		}

		/*
		 * گذارِ هدر وودمارت چند صد میلی‌ثانیه طول می‌کشد؛ تا پایانش هر فریم.
		 * فهرست هدرها سرِ هر دور تازه می‌شود: وودمارت نسخهٔ دوم (`.whb-clone`)
		 * را با نخستین اسکرول می‌سازد، نه هنگام بارگذاری.
		 */
		function settle() {

			until = Date.now() + 450;

			/*
			 * فهرست هر بار تازه می‌شود، حتی وسطِ دوری که در جریان است: وودمارت
			 * نسخهٔ دوم را درست هنگام اسکرول می‌سازد، و دورِ جاری با فهرستِ
			 * کهنه آن را نمی‌دید — نوار زیرِ هدر می‌ماند. عکسِ صحنه گرفتش.
			 */
			collectHeads();

			if ( busy ) {
				return;
			}

			busy = true;

			( function frame() {
				apply();
				if ( Date.now() < until ) {
					window.requestAnimationFrame( frame );
				} else {
					busy = false;
				}
			} )();
		}

		collectHeads();
		apply();

		window.addEventListener( 'scroll', settle, { passive: true } );
		window.addEventListener( 'resize', settle, { passive: true } );
		window.addEventListener( 'load', settle, { once: true } );

		/*
		 * چسبیدن و رهاشدن با کلاس یا سبکِ خودِ هدر عوض می‌شود، گاهی بی هیچ
		 * اسکرولی، و گاهی هدر دیرتر از این اسکریپت ساخته می‌شود. پس کل سند
		 * پاییده می‌شود ولی فقط تغییرِ درونِ یکی از هدرها — نه درونِ صفحهٔ
		 * خودمان — دورِ اندازه‌گیری را راه می‌اندازد.
		 */
		if ( window.MutationObserver ) {

			new MutationObserver( function ( records ) {

				for ( var i = 0; i < records.length; i ++ ) {

					var t = records[ i ].target;

					if ( 1 !== t.nodeType || page.contains( t ) ) {
						continue;
					}

					if ( t.closest( HEADS ) ) {
						settle();
						return;
					}

					/* هدری که همین حالا به سند افزوده شد — مثل نسخهٔ دومِ وودمارت */
					var added = records[ i ].addedNodes;

					for ( var j = 0; j < added.length; j ++ ) {
						if ( 1 === added[ j ].nodeType && ( added[ j ].matches( HEADS ) || added[ j ].querySelector( HEADS ) ) ) {
							settle();
							return;
						}
					}
				}
			} ).observe( document.body, {
				attributes: true, attributeFilter: [ 'class', 'style' ], childList: true, subtree: true,
			} );
		}
	} )();

	/* ══ حالت فعال نوار بخش‌ها ═══════════════════════════════════════════
	   فهرست بخش‌ها از خودِ پیوندهای نوار می‌آید، نه از یک آرایهٔ ثابت:
	   نوار را PHP از ناحیه‌هایی می‌سازد که واقعاً محتوا داشتند، پس هر
	   فهرست ثابتی روی سیزده نوع پست غلط می‌شد.
	   ────────────────────────────────────────────────────────────────── */
	( function () {

		var nav = page.querySelector( '.tp-snav' );

		if ( ! nav ) {
			return;
		}

		var links = [].slice.call( nav.querySelectorAll( 'a' ) );
		var byId  = {};
		var ids   = [];

		links.forEach( function ( a ) {

			var href = a.getAttribute( 'href' ) || '';

			if ( '#' === href.charAt( 0 ) ) {
				byId[ href.slice( 1 ) ] = a;
				ids.push( href.slice( 1 ) );
			}
		} );

		if ( ! ids.length ) {
			return;
		}

		var lockUntil = 0;
		var strip     = nav.querySelector( '.tp-snav__in' );
		var calm      = window.matchMedia && window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches;

		/*
		 * پیوند فعال به میانهٔ نوار می‌آید — فقط افقی.  ۴٫۲٫۱ بند ۳
		 *
		 * پیش از این `scrollIntoView({block:'nearest'})` بود. «نزدیک‌ترین»
		 * برای عنصری درون نوار چسبان یعنی مرورگر گاهی **صفحه** را هم عمودی
		 * جابه‌جا می‌کرد تا پیوند را «دیدنی» کند — همان پرشِ هنگام اسکرول
		 * رو به بالا. حالا فقط خودِ نوار افقی می‌لغزد و صفحه دست نمی‌خورد.
		 */
		function reveal( link ) {

			if ( ! strip || strip.scrollWidth <= strip.clientWidth + 1 ) {
				return;
			}

			var box   = strip.getBoundingClientRect();
			var one   = link.getBoundingClientRect();
			var delta = ( one.left + one.width / 2 ) - ( box.left + box.width / 2 );

			if ( Math.abs( delta ) < 2 ) {
				return;
			}

			strip.scrollTo( { left: strip.scrollLeft + delta, behavior: calm ? 'auto' : 'smooth' } );
		}

		function setActive( id ) {

			links.forEach( function ( a ) { a.classList.remove( 'tp-is-active' ); } );

			var link = byId[ id ];

			if ( ! link ) {
				return;
			}

			link.classList.add( 'tp-is-active' );
			reveal( link );
		}

		function pick() {

			if ( Date.now() < lockUntil ) {
				return;
			}

			/* بخشی فعال است که بالایش از زیرِ نوار گذشته — هدر + نوار + کمی نفس. */
			var threshold = Math.max( 0, snavTop ) + ( snavH > 0 ? snavH : nav.offsetHeight ) + 24;
			var bestId    = null;
			var bestTop   = -Infinity;

			ids.forEach( function ( id ) {

				var el = document.getElementById( id );

				if ( ! el ) {
					return;
				}

				var top = el.getBoundingClientRect().top;

				if ( top <= threshold && top > bestTop ) {
					bestTop = top;
					bestId  = id;
				}
			} );

			setActive( bestId || ids[ 0 ] );
		}

		links.forEach( function ( a ) {
			a.addEventListener( 'click', function () {
				var href = a.getAttribute( 'href' ) || '';
				if ( '#' !== href.charAt( 0 ) ) { return; }
				setActive( href.slice( 1 ) );
				lockUntil = Date.now() + 1600;
			} );
		} );

		window.addEventListener( 'hashchange', function () {
			var id = ( location.hash || '' ).replace( '#', '' );
			if ( id ) { setActive( id ); lockUntil = Date.now() + 1200; }
		} );

		var ticking = false;

		window.addEventListener( 'scroll', function () {

			if ( ticking ) {
				return;
			}

			ticking = true;

			window.requestAnimationFrame( function () {
				pick();
				ticking = false;
			} );
		}, { passive: true } );

		window.addEventListener( 'resize', function () { lockUntil = 0; pick(); }, { passive: true } );

		if ( location.hash ) {
			setActive( location.hash.replace( '#', '' ) );
		} else {
			pick();
		}

		window.addEventListener( 'load', pick, { once: true } );
	} )();

	/* ══ اسلایدرها ══════════════════════════════════════════════════════ */
	Array.prototype.forEach.call( page.querySelectorAll( '[data-target]' ), function ( btn ) {

		btn.addEventListener( 'click', function () {

			var el = document.getElementById( btn.getAttribute( 'data-target' ) );

			if ( ! el ) {
				return;
			}

			var amount = Math.round( el.clientWidth * 0.85 ) * ( '1' === btn.getAttribute( 'data-dir' ) ? -1 : 1 );

			el.scrollBy( { left: amount, behavior: 'smooth' } );
		} );
	} );

	/* ══ مدیر مودال ═════════════════════════════════════════════════════
	   قفل روی `body` و `documentElement` هر دو: iOS فقط دومی را می‌فهمد
	   و اندروید فقط اولی را.
	   ────────────────────────────────────────────────────────────────── */
	var lastFocus = null;
	var openStack = [];

	function openModal( modal, focusEl ) {

		if ( ! modal ) {
			return;
		}

		if ( ! openStack.length ) {
			lastFocus = document.activeElement;
			document.body.style.overflow = 'hidden';
			document.documentElement.style.overflow = 'hidden';
		}

		openStack.push( modal );
		modal.classList.add( 'tp-show' );

		if ( focusEl && focusEl.focus ) {
			focusEl.focus();
		}
	}

	function closeModal( modal ) {

		if ( ! modal ) {
			return;
		}

		modal.classList.remove( 'tp-show' );
		openStack = openStack.filter( function ( one ) { return one !== modal; } );

		/* مودالی که با بستن کاری دارد — مثل شاسیِ پخش که باید بایستد.  P5-D222 */
		if ( 'function' === typeof modal.tpOnClose ) {
			modal.tpOnClose();
		}

		if ( openStack.length ) {
			return;
		}

		document.body.style.overflow = '';
		document.documentElement.style.overflow = '';

		if ( lastFocus && lastFocus.focus ) {
			lastFocus.focus();
		}

		lastFocus = null;
	}

	function trapFocus( modal ) {

		if ( ! modal ) {
			return;
		}

		modal.addEventListener( 'keydown', function ( e ) {

			if ( 'Tab' !== e.key || ! modal.classList.contains( 'tp-show' ) ) {
				return;
			}

			var f = modal.querySelectorAll( 'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])' );

			if ( ! f.length ) {
				return;
			}

			var first = f[ 0 ];
			var last  = f[ f.length - 1 ];

			if ( e.shiftKey && document.activeElement === first ) {
				e.preventDefault();
				last.focus();
			} else if ( ! e.shiftKey && document.activeElement === last ) {
				e.preventDefault();
				first.focus();
			}
		} );
	}

	var mapModal    = document.getElementById( 'tpMapModal' );
	var galleryBox  = document.getElementById( 'tpGalleryModal' );
	var soloBox     = document.getElementById( 'tpGallerySolo' );

	[ mapModal, galleryBox, soloBox ].forEach( trapFocus );

	[ mapModal, galleryBox, soloBox ].forEach( function ( modal ) {

		if ( ! modal ) {
			return;
		}

		modal.addEventListener( 'click', function ( e ) {
			if ( e.target === modal ) { closeModal( modal ); }
		} );
	} );

	document.addEventListener( 'keydown', function ( e ) {

		if ( 'Escape' !== e.key || ! openStack.length ) {
			return;
		}

		/* یک پله عقب، نه همه با هم. */
		closeModal( openStack[ openStack.length - 1 ] );
	} );

	page.addEventListener( 'click', function ( e ) {

		var target = e.target.closest ? e.target : e.target.parentNode;

		if ( ! target || ! target.closest ) {
			return;
		}

		if ( target.closest( '[data-tp-map-open]' ) && mapModal ) {
			openModal( mapModal, mapModal.querySelector( '[data-tp-close]' ) );
		}

		if ( target.closest( '[data-tp-gallery-open]' ) && galleryBox ) {
			openModal( galleryBox, galleryBox.querySelector( '[data-tp-close]' ) );
		}
	} );

	document.addEventListener( 'click', function ( e ) {

		if ( ! e.target.closest ) {
			return;
		}

		var x = e.target.closest( '[data-tp-close]' );

		if ( ! x ) {
			return;
		}

		var modal = x.closest( '.tp-modal, .tp-gallery-modal, .tp-sheet' );

		if ( modal && modal.classList.contains( 'tp-sheet' ) ) {
			modal.removeAttribute( 'open' );
			return;
		}

		closeModal( modal );
	} );

	/* ══ گالری — نمای تک‌عکس ════════════════════════════════════════════
	   کلیک روی هر کاشی، چه در موزاییک چه در مودال، همان عکس را در
	   اندازهٔ کامل نشان می‌دهد. فهرست عکس‌ها را PHP روی مودال گذاشته،
	   پس هر دو جا از یک ترتیب می‌خوانند.
	   ────────────────────────────────────────────────────────────────── */
	( function () {

		if ( ! soloBox || ! galleryBox ) {
			return;
		}

		var shots = [];

		try {
			shots = JSON.parse( galleryBox.getAttribute( 'data-tp-shots' ) || '[]' );
		} catch ( err ) {
			shots = [];
		}

		if ( ! shots.length ) {
			return;
		}

		var img     = soloBox.querySelector( '.tp-solo__img' );
		var title   = soloBox.querySelector( '[data-tp-solo-title]' );
		var cap     = soloBox.querySelector( '[data-tp-solo-caption]' );
		var counter = soloBox.querySelector( '[data-tp-solo-count]' );
		var stage   = soloBox.querySelector( '[data-tp-solo-stage]' );
		var at      = 0;
		var n       = shots.length;

		function fa( v ) {
			return String( v ).replace( /[0-9]/g, function ( d ) { return '۰۱۲۳۴۵۶۷۸۹'[ d ]; } );
		}

		/* همسایه‌ها از پیش بار می‌شوند تا «بعدی» منتظر شبکه نماند.  بند ۸ */
		function preload( index ) {
			var one = shots[ ( ( index % n ) + n ) % n ];
			if ( one && one.src ) {
				var pre = new Image();
				pre.src = one.src;
			}
		}

		/* دو سرِ فهرست به هم می‌رسند: بعد از آخری، اولی؛ قبل از اولی، آخری. */
		function show( index ) {

			at = ( ( index % n ) + n ) % n;

			img.setAttribute( 'src', shots[ at ].src );
			img.setAttribute( 'alt', shots[ at ].alt || '' );

			if ( title ) { title.textContent = shots[ at ].t || ''; }
			if ( cap ) { cap.textContent = shots[ at ].c || ''; }
			if ( counter ) { counter.textContent = fa( at + 1 ) + ' / ' + fa( n ); }

			preload( at + 1 );
			preload( at - 1 );
		}

		/* کشیدنِ انگشت به راست = بعدی — راست‌به‌چپ، مثل ورق زدنِ کتاب فارسی. */
		if ( stage ) {

			var sx = 0, sy = 0, touching = false;

			stage.addEventListener( 'touchstart', function ( e ) {
				if ( 1 !== e.touches.length ) { touching = false; return; }
				touching = true;
				sx = e.touches[0].clientX;
				sy = e.touches[0].clientY;
			}, { passive: true } );

			stage.addEventListener( 'touchend', function ( e ) {

				if ( ! touching || ! e.changedTouches.length ) {
					return;
				}

				touching = false;

				var dx = e.changedTouches[0].clientX - sx;
				var dy = e.changedTouches[0].clientY - sy;

				if ( Math.abs( dx ) < 40 || Math.abs( dx ) < Math.abs( dy ) ) {
					return;
				}

				show( dx > 0 ? at + 1 : at - 1 );
			}, { passive: true } );
		}

		page.addEventListener( 'click', function ( e ) {

			if ( ! e.target.closest ) {
				return;
			}

			var tile = e.target.closest( '[data-tp-shot]' );

			if ( ! tile ) {
				return;
			}

			var id = tile.getAttribute( 'data-tp-shot' );

			for ( var i = 0; i < shots.length; i ++ ) {
				if ( String( shots[ i ].id ) === String( id ) ) { show( i ); break; }
			}

			openModal( soloBox, soloBox.querySelector( '[data-tp-close]' ) );
		} );

		soloBox.addEventListener( 'click', function ( e ) {

			if ( ! e.target.closest ) {
				return;
			}

			if ( e.target.closest( '[data-tp-shot-next]' ) ) { show( at + 1 ); }
			if ( e.target.closest( '[data-tp-shot-prev]' ) ) { show( at - 1 ); }
		} );

		document.addEventListener( 'keydown', function ( e ) {

			if ( ! soloBox.classList.contains( 'tp-show' ) ) {
				return;
			}

			if ( 'ArrowLeft' === e.key ) { show( at + 1 ); }
			if ( 'ArrowRight' === e.key ) { show( at - 1 ); }
		} );
	} )();

	/* ══ صوت و ویدیو — P5-D222 ══════════════════════════════════════════
	   یوتیوب، آپارات و پروندهٔ ویدیو در شاسیِ تمام‌صفحه پخش می‌شوند.
	   `iframe` یا `<video>` فقط با کلیک ساخته می‌شود — پیش از آن هیچ
	   درخواستی به سرویس بیرونی نمی‌رود — و با بستن برداشته می‌شود، پس
	   پخش هم می‌ایستد. نشانیِ جاسازی را سرور از شناسهٔ معتبر ساخته است.
	   ────────────────────────────────────────────────────────────────── */
	( function () {

		var box = document.getElementById( 'tpMediaSolo' );

		if ( ! box ) {
			return;
		}

		var stage = box.querySelector( '[data-tp-media-stage]' );
		var name  = box.querySelector( '[data-tp-media-name]' );

		trapFocus( box );

		box.addEventListener( 'click', function ( e ) {
			if ( e.target === box ) { closeModal( box ); }
		} );

		box.tpOnClose = function () {
			stage.innerHTML = '';
		};

		page.addEventListener( 'click', function ( e ) {

			var t = e.target.closest ? e.target.closest( '[data-tp-media]' ) : null;

			if ( ! t ) {
				return;
			}

			e.preventDefault();

			var kind  = t.getAttribute( 'data-tp-media-kind' );
			var src   = t.getAttribute( 'data-tp-media' ) || '';
			var title = t.getAttribute( 'data-tp-media-title' ) || '';
			var el;

			if ( 'video' === kind ) {
				el = document.createElement( 'video' );
				el.controls = true;
				el.autoplay = true;
				el.setAttribute( 'playsinline', '' );
			} else {
				el = document.createElement( 'iframe' );
				el.setAttribute( 'allow', 'autoplay; encrypted-media; picture-in-picture; fullscreen' );
				el.setAttribute( 'allowfullscreen', '' );
				el.setAttribute( 'referrerpolicy', 'strict-origin-when-cross-origin' );
				el.setAttribute( 'title', title );
			}

			el.src = src;
			stage.innerHTML = '';
			stage.appendChild( el );

			if ( name ) { name.textContent = title; }

			openModal( box, box.querySelector( '[data-tp-close]' ) );
		} );
	} )();

	/* ══ مودالِ فهرست — P5-D221 ══════════════════════════════════════════
	   «همه شهرها / همه جاذبه‌ها / همه فرهنگ». کارت‌ها و پیوندها در HTML
	   سرورند؛ این‌جا فقط باز و بسته می‌شود و جست‌وجو پنهان و پیدا می‌کند.

	   نام پیش از مقایسه یکدست می‌شود، هم نام و هم پرسش:
	     ي ى ← ی · ك ← ک · نیم‌فاصله و فاصله حذف · اِعراب حذف
	     (اِصفَهان = اصفهان) · رقم فارسی و عربی ← لاتین
	   فاصله هم حذف می‌شود چون «نوش آباد» و «نوش‌آباد» یک نام‌اند.
	   ────────────────────────────────────────────────────────────────── */
	function tpNorm( s ) {
		return String( s || '' )
			.replace( /[\u064A\u0649]/g, '\u06CC' )
			.replace( /\u0643/g, '\u06A9' )
			.replace( /[\u064B-\u065F\u0670\u06D6-\u06ED]/g, '' )
			.replace( /[\u06F0-\u06F9]/g, function ( d ) { return String( d.charCodeAt( 0 ) - 0x06F0 ); } )
			.replace( /[\u0660-\u0669]/g, function ( d ) { return String( d.charCodeAt( 0 ) - 0x0660 ); } )
			.replace( /[\u200B-\u200F\s]+/g, '' )
			.toLowerCase();
	}

	( function () {

		var lists = [].slice.call( page.querySelectorAll( '[data-tp-list]' ) );

		if ( ! lists.length ) {
			return;
		}

		function fa( n ) {
			return String( n ).replace( /[0-9]/g, function ( d ) { return '۰۱۲۳۴۵۶۷۸۹'[ d ]; } );
		}

		lists.forEach( function ( box ) {

			trapFocus( box );

			/* پرده خودِ مودال است، مثل گالری: کلیک روی آن می‌بندد. */
			box.addEventListener( 'click', function ( e ) {
				if ( e.target === box ) { closeModal( box ); }
			} );

			var q      = box.querySelector( '[data-tp-list-q]' );
			var count  = box.querySelector( '[data-tp-list-count]' );
			var empty  = box.querySelector( '.tp-list__empty' );
			var blocks = [].slice.call( box.querySelectorAll( '.tp-list__block' ) );
			var items  = [].slice.call( box.querySelectorAll( '.tp-list__item' ) ).map( function ( li ) {
				var b = li.querySelector( 'b' );
				return { el: li, key: tpNorm( b ? b.textContent : li.textContent ) };
			} );
			var total  = items.length;

			box.tpFilter = function () {

				var needle = q ? tpNorm( q.value ) : '';
				var shown  = 0;

				items.forEach( function ( it ) {
					var ok = '' === needle || -1 !== it.key.indexOf( needle );
					it.el.hidden = ! ok;
					if ( ok ) { shown ++; }
				} );

				/* سرفصل خانواده‌ای که عضوِ پیدایی ندارد هم پنهان می‌شود */
				blocks.forEach( function ( b ) {
					b.hidden = ! b.querySelector( '.tp-list__item:not([hidden])' );
				} );

				if ( empty ) { empty.hidden = shown > 0; }

				if ( count ) {
					count.textContent = '' === needle ? fa( total ) + ' مورد' : fa( shown ) + ' از ' + fa( total );
				}
			};

			if ( q ) {
				q.addEventListener( 'input', box.tpFilter );
			}
		} );

		/* `.more` پیوند است — به خودِ مودال؛ این‌جا جلوی پرش گرفته می‌شود. */
		page.addEventListener( 'click', function ( e ) {

			var a = e.target.closest ? e.target.closest( '[data-tp-list-open]' ) : null;

			if ( ! a ) {
				return;
			}

			var box = document.getElementById( ( a.getAttribute( 'href' ) || '' ).replace( '#', '' ) );

			if ( ! box ) {
				return;
			}

			e.preventDefault();

			/* هر بار از نو: فهرست کامل، جست‌وجوی خالی، فوکوس روی جعبه */
			var q = box.querySelector( '[data-tp-list-q]' );

			if ( q ) { q.value = ''; }
			if ( box.tpFilter ) { box.tpFilter(); }

			box.scrollTop = 0;
			openModal( box, q );
		} );
	} )();

	/* ══ بلوک هوش مصنوعی ════════════════════════════════════════════════ */
	( function () {

		var out = page.querySelector( '[data-tp-ai-out]' );

		if ( ! out ) {
			return;
		}

		var data = {};

		try {
			data = JSON.parse( out.getAttribute( 'data-tp-ai' ) || '{}' );
		} catch ( err ) {
			data = {};
		}

		var body  = out.querySelector( 'p' );
		var label = out.querySelector( '[data-tp-ai-type]' );

		Array.prototype.forEach.call( page.querySelectorAll( '[data-ai]' ), function ( btn ) {

			btn.addEventListener( 'click', function () {

				var kind = btn.getAttribute( 'data-ai' );

				if ( 'copy' === kind ) {

					if ( navigator.clipboard && navigator.clipboard.writeText ) {

						navigator.clipboard.writeText( body.textContent || '' ).then( function () {

							var was = btn.innerHTML;

							btn.textContent = 'کپی شد ✓';
							btn.disabled    = true;

							window.setTimeout( function () {
								btn.innerHTML = was;
								btn.disabled  = false;
							}, 1500 );
						} ).catch( function () {} );
					}

					return;
				}

				if ( ! data[ kind ] ) {
					return;
				}

				body.textContent = data[ kind ];

				if ( label ) {
					label.textContent = btn.textContent.trim();
				}

				Array.prototype.forEach.call( page.querySelectorAll( '[data-ai]' ), function ( b ) {
					if ( 'copy' !== b.getAttribute( 'data-ai' ) ) {
						b.classList.toggle( 'tp-is-active', b === btn );
					}
				} );
			} );
		} );
	} )();

	/* ══ دکمهٔ «N مورد دیگر» ═════════════════════════════════════════════ */
	Array.prototype.forEach.call( page.querySelectorAll( '[data-tp-more]' ), function ( btn ) {

		btn.addEventListener( 'click', function () {

			var card = btn.closest( '.tp-rail-card' ) || btn.parentNode;

			Array.prototype.forEach.call( card.querySelectorAll( '[data-tp-rest-item]' ), function ( one ) {
				one.removeAttribute( 'hidden' );
			} );

			btn.remove();
		} );
	} );

	/* ══ نوار کنش ═══════════════════════════════════════════════════════
	   یک عنصر، دو جای نشستن — در دسکتاپ کارتی در ستون کناری، در موبایل
	   نواری بالای مسیر راهنما. دو نسخه یعنی دو وضعیت «ذخیره‌شده» که با
	   هم واگرا می‌شوند.
	   ────────────────────────────────────────────────────────────────── */
	( function () {

		var bar = page.querySelector( '[data-tp-actionbar]' );

		if ( ! bar ) {
			return;
		}

		var home   = bar.parentNode;
		var crumb  = page.querySelector( '.tp-crumb' );
		var narrow = window.matchMedia( '(max-width: 720px)' );

		function place() {

			if ( narrow.matches ) {

				if ( crumb && bar.nextSibling !== crumb ) {
					crumb.parentNode.insertBefore( bar, crumb );
				}

				bar.className = 'tp-actionbar';

			} else {

				if ( bar.parentNode !== home ) {
					home.appendChild( bar );
				}

				bar.className = 'tp-rail-card tp-actionbar tp-actionbar--rail';
			}
		}

		place();

		if ( narrow.addEventListener ) {
			narrow.addEventListener( 'change', place );
		} else if ( narrow.addListener ) {
			narrow.addListener( place );
		}

		var note = bar.querySelector( '.tp-act__note' );

		function say( text ) {

			if ( ! note ) {
				return;
			}

			note.textContent = text;

			window.setTimeout( function () {
				if ( note.textContent === text ) { note.textContent = ''; }
			}, 2600 );
		}

		var share = bar.querySelector( '[data-tp-share]' );

		if ( share ) {

			share.addEventListener( 'click', function () {

				var data = { title: document.title, url: location.href };

				if ( navigator.share ) {
					navigator.share( data ).catch( function () {} );
					return;
				}

				if ( navigator.clipboard ) {
					navigator.clipboard.writeText( location.href ).then( function () {
						say( 'نشانی کپی شد.' );
					} ).catch( function () {} );
				}
			} );
		}

		var save = bar.querySelector( '[data-tp-save]' );

		if ( save ) {

			save.addEventListener( 'click', function () {

				var on = 'true' === save.getAttribute( 'aria-pressed' );

				save.setAttribute( 'aria-pressed', on ? 'false' : 'true' );
				save.classList.toggle( 'tp-is-on', ! on );

				say( on ? 'از فهرست شما برداشته شد.' : 'در حساب شما ذخیره شد.' );
			} );
		}
	} )();

	/* ══ نوار پایین موبایل و برگهٔ بخش‌ها ══════════════════════════════ */
	( function () {

		var mnav = page.querySelector( '.tp-mnav' );

		if ( ! mnav ) {
			return;
		}

		var sheet = document.getElementById( 'tpSheet' );

		mnav.addEventListener( 'click', function ( e ) {

			var btn = e.target.closest ? e.target.closest( '[data-tp-go]' ) : null;

			if ( btn ) {

				var key = btn.getAttribute( 'data-tp-go' );

				if ( 'top' === key ) {
					window.scrollTo( { top: 0, behavior: 'smooth' } );
					return;
				}

				if ( 'save' === key ) {
					var s = page.querySelector( '[data-tp-save]' );
					if ( s ) { s.click(); }
					return;
				}

				var el = document.getElementById( key );

				if ( el ) {
					el.scrollIntoView( { behavior: 'smooth', block: 'start' } );
				}

				return;
			}

			if ( e.target.closest && e.target.closest( '[data-tp-sheet-open]' ) && sheet ) {
				sheet.setAttribute( 'open', '' );
			}
		} );

		if ( sheet ) {

			sheet.addEventListener( 'click', function ( e ) {
				if ( e.target.hasAttribute( 'data-tp-close' ) || 'A' === e.target.tagName ) {
					sheet.removeAttribute( 'open' );
				}
			} );

			document.addEventListener( 'keydown', function ( e ) {
				if ( 'Escape' === e.key ) { sheet.removeAttribute( 'open' ); }
			} );
		}
	} )();

	/* ══ نشانگر نقشه ════════════════════════════════════════════════════ */
	Array.prototype.forEach.call( page.querySelectorAll( '.tp-map-pin' ), function ( pin ) {

		pin.addEventListener( 'click', function () {

			pin.style.transform = 'translate(-50%,-50%) scale(1.2)';

			window.setTimeout( function () {
				pin.style.transform = 'translate(-50%,-50%)';
			}, 160 );
		} );
	} );

	/* ══ هوای سه روز ════════════════════════════════════════════════════
	   دادهٔ زنده است و داخل HTML کش‌شده نمی‌آید، وگرنه هر بازدیدکننده
	   هوای روزِ ساختِ کش را می‌بیند. پس پس از بارگذاری از نقطهٔ REST
	   خوانده می‌شود — همان چیزی که مرجع با `demo` جایش را نگه داشته بود.
	   ────────────────────────────────────────────────────────────────── */
	( function () {

		var box = page.querySelector( '[data-tp-weather]' );

		if ( ! box || ! window.fetch ) {
			return;
		}

		var root = ( window.TopersiaG && window.TopersiaG.rest ) || '';

		if ( ! root ) {
			return;
		}

		var note = box.parentNode.querySelector( '.tp-wx__src' );

		var ICON = {
			sun:  '<circle cx="12" cy="12" r="4.4"/><path d="M12 2.6v2.2M12 19.2v2.2M2.6 12h2.2M19.2 12h2.2M5.4 5.4l1.6 1.6M17 17l1.6 1.6M18.6 5.4L17 7M7 17l-1.6 1.6"/>',
			part: '<circle cx="9" cy="9" r="3.4"/><path d="M6.5 18h9a3.5 3.5 0 0 0 0-7 5 5 0 0 0-9.6 1.4A3 3 0 0 0 6.5 18z"/>',
			wind: '<path d="M3 8h11a3 3 0 1 0-3-3M3 13h15a3 3 0 1 1-3 3M3 18h8"/>',
			rain: '<path d="M6.5 15h9a3.5 3.5 0 0 0 0-7 5 5 0 0 0-9.6 1.4A3 3 0 0 0 6.5 15z"/><path d="M8 18l-1 2M12 18l-1 2M16 18l-1 2"/>',
			snow: '<path d="M6.5 15h9a3.5 3.5 0 0 0 0-7 5 5 0 0 0-9.6 1.4A3 3 0 0 0 6.5 15z"/><path d="M9 19h.01M12 20h.01M15 19h.01"/>'
		};

		function fa( n ) {
			return String( n ).replace( /[0-9]/g, function ( d ) { return '۰۱۲۳۴۵۶۷۸۹'[ d ]; } );
		}

		fetch( root + '?coords=' + encodeURIComponent( box.getAttribute( 'data-tp-coords' ) || '' ) )
			.then( function ( r ) { return r.ok ? r.json() : null; } )
			.then( function ( data ) {

				if ( ! data || ! data.days || ! data.days.length ) {
					if ( note ) { note.textContent = ''; }
					return;
				}

				box.innerHTML = data.days.map( function ( x ) {

					return '<div class="tp-wx__day"><span class="tp-wx__d">' + x.d + '</span>'
						+ '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round">'
						+ ( ICON[ x.i ] || ICON.sun ) + '</svg>'
						+ '<b>' + fa( x.t ) + '°</b><span class="tp-wx__n">' + fa( x.n ) + '°</span>'
						+ '<span class="tp-wx__s">' + x.s + '</span></div>';
				} ).join( '' );

				if ( note ) {
					note.textContent = data.note || '';
				}
			} )
			.catch( function () {
				if ( note ) { note.textContent = ''; }
			} );
	} )();

}() );
