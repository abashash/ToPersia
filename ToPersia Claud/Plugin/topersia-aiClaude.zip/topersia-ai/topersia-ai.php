<?php
/**
 * Plugin Name:       ToPersia AI
 * Plugin URI:        https://topersia.com
 * Description:       AI infrastructure layer for ToPersia: entity-aware AI summaries, Ask AI links, and an extensible provider architecture for JetEngine/WPML/Elementor content.
 * Version:           1.1.0
 * Requires at least: 5.9
 * Requires PHP:      7.4
 * Author:            ToPersia
 * Text Domain:       topersia-ai
 * Domain Path:       /languages
 * License:           GPLv2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 *
 * @package ToPersia\AI
 */

namespace ToPersia\AI;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Do not access this file directly.
}

// ---------------------------------------------------------------------
// Constants
// ---------------------------------------------------------------------

define( 'TOPERSIA_AI_VERSION', '1.1.0' );
define( 'TOPERSIA_AI_DB_VERSION', '1.1.0' );
define( 'TOPERSIA_AI_FILE', __FILE__ );
define( 'TOPERSIA_AI_PATH', plugin_dir_path( __FILE__ ) );
define( 'TOPERSIA_AI_URL', plugin_dir_url( __FILE__ ) );
define( 'TOPERSIA_AI_BASENAME', plugin_basename( __FILE__ ) );
define( 'TOPERSIA_AI_SLUG', 'topersia-ai' );

// Minimum PHP guard. WordPress already checks "Requires PHP" on modern
// versions, but we guard explicitly for older WP installs too.
if ( version_compare( PHP_VERSION, '7.4', '<' ) ) {
	add_action(
		'admin_notices',
		function () {
			echo '<div class="notice notice-error"><p>' .
				esc_html__( 'ToPersia AI requires PHP 7.4 or higher. The plugin has been disabled.', 'topersia-ai' ) .
				'</p></div>';
		}
	);
	return;
}

// ---------------------------------------------------------------------
// Autoloading
// ---------------------------------------------------------------------

require_once TOPERSIA_AI_PATH . 'includes/Core/Autoloader.php';
Core\Autoloader::register();

// ---------------------------------------------------------------------
// Activation / deactivation / uninstall hooks
// ---------------------------------------------------------------------

register_activation_hook( __FILE__, array( Core\Activator::class, 'activate' ) );
register_deactivation_hook( __FILE__, array( Core\Deactivator::class, 'deactivate' ) );

// ---------------------------------------------------------------------
// Bootstrap
// ---------------------------------------------------------------------

/**
 * Returns the single Plugin instance.
 *
 * @return Core\Plugin
 */
function topersia_ai() {
	return Core\Plugin::instance();
}

add_action( 'plugins_loaded', __NAMESPACE__ . '\\topersia_ai' );
