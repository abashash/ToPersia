=== ToPersia AI ===
Contributors: topersia
Tags: ai, chatgpt, claude, summary, wpml, jetengine
Requires at least: 5.9
Tested up to: 6.6
Requires PHP: 7.4
Stable tag: 1.1.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

AI infrastructure layer for ToPersia: entity-aware AI summaries and "Ask AI" external links, with an extensible provider architecture.

== Description ==

ToPersia AI adds two content-facing modules to any WordPress site:

1. **Ask AI** — a row of buttons under (or anywhere in) your content that opens ChatGPT, Claude, Gemini, Perplexity, Grok, or Copilot with a context-aware prompt about the current page pre-filled.
2. **AI Summary** — a short, stored "Quick Summary" block generated from your content and cached per post/language, with manual editing and one-click regeneration from the admin.

Both modules are entity-aware: when JetEngine custom fields, taxonomies, and relations are present, they are folded into the prompt automatically. When WPML is active, summaries and prompts are handled per language.

= Key features =

* Six built-in AI providers (ChatGPT, Claude, Gemini, Perplexity, Grok, Copilot), each swappable/extensible via `topersia_ai_register_providers`
* Per-entity-type, per-language prompt templates, editable from the admin
* Shortcode, Gutenberg block, and Elementor Pro widgets for both modules — same server-rendered markup everywhere
* Optional, privacy-safe click/view analytics with **no IP address, user agent, or personal data ever stored**
* JetEngine and WPML support that degrades gracefully when either plugin is absent
* No required build step: all shipped JS/CSS is hand-written, framework-free
* Deactivation and uninstall are non-destructive by default — your data is only removed on uninstall if you explicitly opt in under Settings

= Requirements for AI Summary generation =

The Ask AI module needs no API key — it links out to each provider's own web app. The AI Summary module needs a configured AI provider (an OpenAI-compatible API key, entered under Settings → AI Provider) to generate new summaries; without one, you can still write/edit summaries manually.

== Installation ==

1. Upload the `topersia-ai` folder to `/wp-content/plugins/`, or upload the zip via Plugins → Add New → Upload Plugin.
2. Activate the plugin.
3. Go to ToPersia AI → Settings to enable modules, choose providers, and (optionally) add an AI provider API key for summary generation.
4. Go to ToPersia AI → Prompt Templates to customise prompts per entity type.

== Frequently Asked Questions ==

= Does this send my content to any AI provider automatically? =

The Ask AI module never sends anything automatically — it only opens a link the visitor chooses to click, with the provider's own web app doing the rest. The AI Summary module calls your configured AI provider's API only when you (or your automatic-regeneration setting) trigger a generation.

= Does this track visitors? =

Analytics, if enabled, records anonymous aggregate counts only (post ID, event type, provider, timestamp) — no IP address, cookies, user agent, or any other personal data.

= What happens to my data if I uninstall the plugin? =

By default, nothing is deleted. Data is only removed on uninstall if you tick "On uninstall → Permanently delete all ToPersia AI data" under Settings first.

== Changelog ==

= 1.1.0 =
* New: unified "AI Travel Brief" card — breadcrumb, tabbed content (Summary / Key Points / Itinerary Suggestion / JSON Export), and an engine-pill row (`[topersia_ai_brief]` shortcode, Elementor widget, Gutenberg block).
* New: built-in **internal, offline summarization engine** (extractive, TF + lead-position + title-overlap scoring) — works with zero configuration, no API key, no external request. Now the default engine; AI providers remain available and are selected in Settings.
* AI Summary now also produces Key Points and an Itinerary Suggestion alongside the summary text.
* `summaries` table gained `key_points` and `itinerary` columns (automatic `dbDelta` migration on upgrade).

= 1.0.0 =
* Initial release: Ask AI, AI Summary, prompt template manager, JetEngine/WPML/Elementor/Gutenberg integrations, privacy-safe analytics.
