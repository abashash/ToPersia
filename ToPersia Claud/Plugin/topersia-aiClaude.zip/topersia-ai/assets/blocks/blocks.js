/**
 * ToPersia AI block editor registrations.
 *
 * Plain ES5-compatible JS using WordPress's bundled `wp-*` script handles.
 * No JSX, no build step - registered directly via wp_register_script().
 */
( function ( wp ) {
	'use strict';

	var registerBlockType = wp.blocks.registerBlockType;
	var el = wp.element.createElement;
	var InspectorControls = wp.blockEditor.InspectorControls;
	var PanelBody = wp.components.PanelBody;
	var TextControl = wp.components.TextControl;
	var ServerSideRender = wp.serverSideRender;
	var __ = wp.i18n.__;

	function editComponent( config ) {
		return function ( props ) {
			var attributes = props.attributes;
			var setAttributes = props.setAttributes;

			return el(
				wp.element.Fragment,
				{},
				el(
					InspectorControls,
					{},
					el(
						PanelBody,
						{ title: __( 'Settings', 'topersia-ai' ) },
						el( TextControl, {
							label: __( 'Post ID (optional)', 'topersia-ai' ),
							type: 'number',
							value: attributes.postId || '',
							onChange: function ( value ) {
								setAttributes( { postId: parseInt( value, 10 ) || 0 } );
							},
						} )
					)
				),
				el( 'div', { className: 'topersia-ai-block-preview' },
					el( ServerSideRender, {
						block: config.name,
						attributes: attributes,
					} )
				)
			);
		};
	}

	registerBlockType( 'topersia-ai/ask-ai', {
		title: __( 'ToPersia — Ask AI', 'topersia-ai' ),
		description: __( 'AI provider buttons for this page.', 'topersia-ai' ),
		icon: 'admin-comments',
		category: 'widgets',
		attributes: { postId: { type: 'number', default: 0 } },
		edit: editComponent( { name: 'topersia-ai/ask-ai' } ),
		save: function () {
			return null; // Server-rendered.
		},
	} );

	registerBlockType( 'topersia-ai/summary', {
		title: __( 'ToPersia — AI Summary', 'topersia-ai' ),
		description: __( 'AI-generated content summary.', 'topersia-ai' ),
		icon: 'excerpt-view',
		category: 'widgets',
		attributes: { postId: { type: 'number', default: 0 } },
		edit: editComponent( { name: 'topersia-ai/summary' } ),
		save: function () {
			return null; // Server-rendered.
		},
	} );

	registerBlockType( 'topersia-ai/brief', {
		title: __( 'ToPersia — AI Travel Brief', 'topersia-ai' ),
		description: __( 'Unified summary, key points, itinerary suggestion and export card.', 'topersia-ai' ),
		icon: 'align-full-width',
		category: 'widgets',
		attributes: { postId: { type: 'number', default: 0 } },
		edit: editComponent( { name: 'topersia-ai/brief' } ),
		save: function () {
			return null; // Server-rendered.
		},
	} );
} )( window.wp );
