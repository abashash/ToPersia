/**
 * ToPersia AI admin screen behaviour: summary regeneration button.
 * Plain vanilla JS, no build step, no framework dependency.
 */
( function () {
	'use strict';

	document.addEventListener( 'click', function ( event ) {
		var button = event.target.closest( '.topersia-ai-generate-btn' );
		if ( ! button ) {
			return;
		}

		var row = button.closest( 'tr' );
		if ( ! row ) {
			return;
		}

		var postId = row.getAttribute( 'data-post-id' );
		var language = row.getAttribute( 'data-language' ) || '';

		if ( ! postId || ! window.topersiaAiAdmin ) {
			return;
		}

		var i18n = window.topersiaAiAdmin.i18n || {};
		var originalText = button.textContent;

		button.disabled = true;
		button.textContent = i18n.generating || 'Generating…';

		fetch( window.topersiaAiAdmin.restUrl + 'summary/' + encodeURIComponent( postId ) + '/generate', {
			method: 'POST',
			headers: {
				'Content-Type': 'application/json',
				'X-WP-Nonce': window.topersiaAiAdmin.nonce,
			},
			body: JSON.stringify( { post_id: parseInt( postId, 10 ), language: language } ),
		} )
			.then( function ( response ) {
				return response.json().then( function ( data ) {
					return { ok: response.ok, data: data };
				} );
			} )
			.then( function ( result ) {
				button.disabled = false;

				if ( result.ok ) {
					var statusCell = row.querySelector( '.topersia-ai-status' );
					if ( statusCell && result.data.summary ) {
						statusCell.textContent = result.data.summary.status;
						statusCell.className = 'topersia-ai-status topersia-ai-status--' + result.data.summary.status;
					}
					button.textContent = i18n.saved || 'Saved.';
					window.setTimeout( function () {
						button.textContent = originalText;
					}, 2000 );
				} else {
					button.textContent = originalText;
					window.alert( ( i18n.error || 'Something went wrong.' ) + ( result.data && result.data.message ? ' ' + result.data.message : '' ) );
				}
			} )
			.catch( function () {
				button.disabled = false;
				button.textContent = originalText;
				window.alert( i18n.error || 'Something went wrong.' );
			} );
	} );
} )();
