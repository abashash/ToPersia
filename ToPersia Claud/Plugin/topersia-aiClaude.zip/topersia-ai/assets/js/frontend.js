/**
 * ToPersia AI frontend behaviour:
 *  - fires an anonymous, aggregate click-tracking beacon when an Ask AI
 *    button is clicked (no personal data collected — see AnalyticsTracker)
 *  - copies the prompt to the clipboard for providers flagged with a
 *    clipboard fallback (see GeminiProvider)
 *
 * Plain vanilla JS, no build step, no framework dependency, degrades
 * silently if fetch/clipboard APIs are unavailable.
 */
( function () {
	'use strict';

	function track( postId, provider ) {
		if ( ! window.topersiaAiFrontend || ! window.fetch ) {
			return;
		}

		fetch( window.topersiaAiFrontend.restUrl + 'track', {
			method: 'POST',
			headers: { 'Content-Type': 'application/json' },
			body: JSON.stringify( {
				post_id: parseInt( postId, 10 ),
				event_type: 'ask_ai_click',
				provider: provider,
				module: 'ask_ai',
			} ),
			keepalive: true,
		} ).catch( function () {
			// Best-effort only; never block navigation on tracking failure.
		} );
	}

	document.addEventListener( 'click', function ( event ) {
		var link = event.target.closest( '.topersia-ai-ask__button' );
		if ( ! link ) {
			return;
		}

		var postId = link.getAttribute( 'data-post-id' );
		var provider = link.getAttribute( 'data-provider' );

		track( postId, provider );

		var clipboardPrompt = link.getAttribute( 'data-clipboard-prompt' );
		if ( clipboardPrompt && navigator.clipboard && navigator.clipboard.writeText ) {
			navigator.clipboard.writeText( clipboardPrompt ).then( function () {
				if ( window.topersiaAiFrontend && window.topersiaAiFrontend.i18n && window.topersiaAiFrontend.i18n.copied ) {
					var hint = document.createElement( 'span' );
					hint.className = 'topersia-ai-ask__clipboard-hint';
					hint.textContent = window.topersiaAiFrontend.i18n.copied;
					link.parentNode.appendChild( hint );
					window.setTimeout( function () {
						hint.remove();
					}, 4000 );
				}
			} ).catch( function () {
				// Clipboard write can fail (permissions, insecure context); the
				// link still opens the provider, so this is a soft failure.
			} );
		}
	} );

	// AI Travel Brief: tab switching (all panels are pre-rendered server-side
	// and simply shown/hidden — no extra request, fully cache-safe).
	document.addEventListener( 'click', function ( event ) {
		var tab = event.target.closest( '.topersia-ai-brief__tab' );
		if ( ! tab ) {
			return;
		}

		var card = tab.closest( '.topersia-ai-brief' );
		if ( ! card ) {
			return;
		}

		var targetPanel = tab.getAttribute( 'data-panel' );

		card.querySelectorAll( '.topersia-ai-brief__tab' ).forEach( function ( t ) {
			t.classList.toggle( 'is-active', t === tab );
		} );

		card.querySelectorAll( '.topersia-ai-brief__panel' ).forEach( function ( panel ) {
			panel.classList.toggle( 'is-active', panel.getAttribute( 'data-panel' ) === targetPanel );
		} );
	} );

	// AI Travel Brief: engine pill clicks (same anonymous, aggregate
	// tracking as the standalone Ask AI buttons above).
	document.addEventListener( 'click', function ( event ) {
		var pill = event.target.closest( '.topersia-ai-brief__pill[href]' );
		if ( ! pill ) {
			return;
		}

		track( pill.getAttribute( 'data-post-id' ), pill.getAttribute( 'data-provider' ) );
	} );

	// AI Travel Brief: "Copy JSON" button.
	document.addEventListener( 'click', function ( event ) {
		var button = event.target.closest( '.topersia-ai-brief__copy-btn' );
		if ( ! button ) {
			return;
		}

		var panel = button.closest( '.topersia-ai-brief__panel' );
		var pre = panel ? panel.querySelector( '.topersia-ai-brief__json' ) : null;

		if ( ! pre || ! navigator.clipboard || ! navigator.clipboard.writeText ) {
			return;
		}

		var originalText = button.textContent;

		navigator.clipboard.writeText( pre.textContent ).then( function () {
			button.textContent = ( window.topersiaAiFrontend && window.topersiaAiFrontend.i18n && window.topersiaAiFrontend.i18n.copied ) || originalText;
			window.setTimeout( function () {
				button.textContent = originalText;
			}, 2000 );
		} ).catch( function () {
			// Soft failure: the JSON is still visible and selectable manually.
		} );
	} );
} )();
