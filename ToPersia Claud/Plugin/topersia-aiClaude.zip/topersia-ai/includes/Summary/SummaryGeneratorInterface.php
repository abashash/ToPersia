<?php
/**
 * Contract for a backend capable of turning a prompt into summary text.
 * Concrete implementations may call a remote AI API (OpenAI, Anthropic,
 * ...) or, in the future, a local model. SummaryManager depends only on
 * this interface, never on a concrete provider.
 *
 * @package ToPersia\AI\Summary
 */

namespace ToPersia\AI\Summary;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

interface SummaryGeneratorInterface {

	/**
	 * Generates summary text for the given prompt/context.
	 *
	 * @param string               $prompt  Rendered prompt.
	 * @param array<string,mixed>  $context Context array (see ContextBuilder).
	 * @return string|\WP_Error Summary text, or WP_Error on failure.
	 */
	public function generate( $prompt, array $context );

	/**
	 * Whether this generator is currently configured and usable (e.g. an
	 * API key is present in settings).
	 *
	 * @return bool
	 */
	public function is_configured();

	/**
	 * Machine identifier stored alongside generated summaries, e.g. "openai".
	 *
	 * @return string
	 */
	public function get_id();
}
