<?php
/**
 * Business logic for AI-generated summaries: staleness detection,
 * generation (via a pluggable SummaryGeneratorInterface), manual overrides,
 * and caching of the resolved value used by the frontend.
 *
 * @package ToPersia\AI\Summary
 */

namespace ToPersia\AI\Summary;

use ToPersia\AI\Context\ContextBuilder;
use ToPersia\AI\Prompt\PromptEngine;
use ToPersia\AI\Prompt\PromptManager;
use ToPersia\AI\Cache\CacheManager;
use ToPersia\AI\Integrations\WPML\WPMLIntegration;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class SummaryManager {

	/** @var SummaryRepository */
	private $repository;

	/** @var ContextBuilder */
	private $context_builder;

	/** @var PromptEngine */
	private $prompt_engine;

	/** @var PromptManager */
	private $prompt_manager;

	/** @var CacheManager */
	private $cache;

	public function __construct(
		SummaryRepository $repository,
		ContextBuilder $context_builder,
		PromptEngine $prompt_engine,
		CacheManager $cache
	) {
		$this->repository      = $repository;
		$this->context_builder = $context_builder;
		$this->prompt_engine   = $prompt_engine;
		$this->prompt_manager  = new PromptManager();
		$this->cache           = $cache;

		add_action( 'save_post', array( $this, 'maybe_mark_stale_on_save' ), 20, 3 );
		add_action( 'topersia_ai_regenerate_summary', array( $this, 'generate' ) );
	}

	/**
	 * Whether the summary module is enabled for a given post type.
	 *
	 * @param string $post_type Post type slug.
	 * @return bool
	 */
	public function is_enabled_for( $post_type ) {
		$settings = get_option( 'topersia_ai_settings', array() );

		if ( empty( $settings['summary_enabled'] ) ) {
			return false;
		}

		$enabled_types = isset( $settings['summary_post_types'] ) ? (array) $settings['summary_post_types'] : array( 'post' );

		return in_array( $post_type, $enabled_types, true );
	}

	/**
	 * Returns the current summary row for a post (current language), or
	 * null if none exists yet.
	 *
	 * @param int         $post_id  Post ID.
	 * @param string|null $language Language code, defaults to current.
	 * @return array|null
	 */
	public function get_summary( $post_id, $language = null ) {
		$language = $language ?? WPMLIntegration::current_language();

		return $this->repository->find( $post_id, $language );
	}

	/**
	 * Generates (or regenerates) a summary, key points, and an itinerary
	 * suggestion for a post using the configured engine (internal or AI),
	 * then persists all three with status "current".
	 *
	 * @param int         $post_id  Post ID.
	 * @param string|null $language Language code, defaults to current.
	 * @return array|\WP_Error Updated summary row, or WP_Error on failure.
	 */
	public function generate( $post_id, $language = null ) {
		$language = $language ?? WPMLIntegration::current_language();
		$context  = $this->context_builder->build( $post_id );

		if ( empty( $context ) ) {
			return new \WP_Error( 'topersia_ai_invalid_post', __( 'The requested post could not be loaded.', 'topersia-ai' ) );
		}

		$this->repository->upsert( $post_id, $language, array( 'status' => 'generating' ) );

		$generator     = $this->get_generator();
		$summary_tpl   = $this->prompt_manager->get_template( $context['entity_type'], 'summary', $language );
		$summary_prompt = $this->prompt_engine->render( $summary_tpl, $context );

		$summary_result = $generator->generate( $summary_prompt, $context );

		if ( is_wp_error( $summary_result ) ) {
			$this->repository->upsert( $post_id, $language, array( 'status' => 'failed' ) );
			return $summary_result;
		}

		$key_points = $this->generate_key_points( $generator, $context, $language );
		$itinerary  = $this->generate_itinerary( $generator, $context, $language );

		$this->repository->upsert(
			$post_id,
			$language,
			array(
				'content'      => $summary_result,
				'key_points'   => wp_json_encode( $key_points ),
				'itinerary'    => $itinerary,
				'status'       => 'current',
				'source'       => 'internal' === $generator->get_id() ? 'internal' : 'ai',
				'provider'     => $generator->get_id(),
				'prompt_hash'  => hash( 'sha256', $summary_prompt ),
				'content_hash' => $this->content_hash( $post_id ),
				'generated_at' => current_time( 'mysql' ),
			)
		);

		$this->cache->delete( $this->cache->key_for_post( $post_id, 'summary_' . $language ) );

		return $this->repository->find( $post_id, $language );
	}

	/**
	 * Produces key points using whichever engine is active. The internal
	 * engine computes these directly from content/structured data (no
	 * extra cost); an AI engine gets a dedicated "key_points" prompt
	 * template so it can be tuned independently from the summary prompt.
	 *
	 * @param SummaryGeneratorInterface $generator Active generator.
	 * @param array<string,mixed>       $context   Context array.
	 * @param string                    $language  Language code.
	 * @return string[]
	 */
	private function generate_key_points( SummaryGeneratorInterface $generator, array $context, $language ) {
		if ( $generator instanceof InternalGenerator ) {
			return $generator->key_points( $context, 5 );
		}

		$template = $this->prompt_manager->get_template( $context['entity_type'], 'key_points', $language );
		$prompt   = $this->prompt_engine->render( $template, $context );
		$result   = $generator->generate( $prompt, $context );

		if ( is_wp_error( $result ) ) {
			return array();
		}

		// AI responses for this module are expected as one point per line.
		$lines = preg_split( '/\r\n|\r|\n/', (string) $result );
		$lines = array_map( static function ( $line ) {
			return trim( ltrim( trim( $line ), '-•*0123456789.() ' ) );
		}, (array) $lines );

		return array_values( array_filter( $lines, static fn( $l ) => '' !== $l ) );
	}

	/**
	 * Produces an itinerary suggestion using whichever engine is active.
	 *
	 * @param SummaryGeneratorInterface $generator Active generator.
	 * @param array<string,mixed>       $context   Context array.
	 * @param string                    $language  Language code.
	 * @return string
	 */
	private function generate_itinerary( SummaryGeneratorInterface $generator, array $context, $language ) {
		if ( $generator instanceof InternalGenerator ) {
			return $generator->itinerary( $context );
		}

		$template = $this->prompt_manager->get_template( $context['entity_type'], 'itinerary', $language );
		$prompt   = $this->prompt_engine->render( $template, $context );
		$result   = $generator->generate( $prompt, $context );

		return is_wp_error( $result ) ? '' : (string) $result;
	}

	/**
	 * Decodes a summary row's stored key_points JSON into a plain array.
	 *
	 * @param array|null $summary_row Row from get_summary()/find().
	 * @return string[]
	 */
	public function decode_key_points( $summary_row ) {
		if ( empty( $summary_row['key_points'] ) ) {
			return array();
		}

		$decoded = json_decode( $summary_row['key_points'], true );

		return is_array( $decoded ) ? $decoded : array();
	}

	/**
	 * Saves a manually-edited summary, marking it as "manual" so automatic
	 * regeneration never silently overwrites it.
	 *
	 * @param int    $post_id  Post ID.
	 * @param string $language Language code.
	 * @param string $content  Manually-edited summary text.
	 * @return int Row ID.
	 */
	public function save_manual( $post_id, $language, $content ) {
		$id = $this->repository->upsert(
			$post_id,
			$language,
			array(
				'content' => wp_kses_post( $content ),
				'status'  => 'manual',
				'source'  => 'manual',
			)
		);

		$this->cache->delete( $this->cache->key_for_post( $post_id, 'summary_' . $language ) );

		return $id;
	}

	/**
	 * Marks a post's summaries stale when its content is edited, unless
	 * automatic regeneration is enabled (in which case we regenerate).
	 *
	 * @param int      $post_id Post ID.
	 * @param \WP_Post $post    Post object.
	 * @param bool     $update  Whether this is an existing post being updated.
	 * @return void
	 */
	public function maybe_mark_stale_on_save( $post_id, $post, $update ) {
		if ( wp_is_post_autosave( $post_id ) || wp_is_post_revision( $post_id ) ) {
			return;
		}

		if ( ! $update || ! $this->is_enabled_for( $post->post_type ) ) {
			return;
		}

		$existing = $this->get_summary( $post_id );

		if ( ! $existing || 'manual' === $existing['status'] ) {
			return; // Nothing to invalidate, or a manual override we must not touch.
		}

		$new_hash = $this->content_hash( $post_id );

		if ( $new_hash === $existing['content_hash'] ) {
			return; // Content did not meaningfully change.
		}

		$settings = get_option( 'topersia_ai_settings', array() );

		if ( ! empty( $settings['summary_auto_generate'] ) ) {
			// Defer to avoid slowing down the post-save request/response cycle.
			wp_schedule_single_event( time() + 5, 'topersia_ai_regenerate_summary', array( $post_id ) );
			return;
		}

		$this->repository->mark_all_stale( $post_id );
	}

	/**
	 * Computes a stable hash of a post's summarisable content, used to
	 * detect real content changes vs. no-op saves.
	 *
	 * @param int $post_id Post ID.
	 * @return string
	 */
	private function content_hash( $post_id ) {
		$post = get_post( $post_id );

		if ( ! $post ) {
			return '';
		}

		return hash( 'sha256', $post->post_title . '|' . $post->post_content . '|' . $post->post_excerpt );
	}

	/**
	 * Resolves the active summary generator based on the "summary_engine"
	 * setting:
	 *  - "internal" (the default): the built-in, offline extractive engine
	 *    - no API key, no external request, always available.
	 *  - "ai": the configured AI backend, defaulting to the built-in
	 *    OpenAI-compatible generator and swappable via the
	 *    `topersia_ai_summary_generator` filter. Falls back to the
	 *    internal engine if "ai" is selected but no provider is actually
	 *    configured, so generation never simply fails for a site that
	 *    hasn't added an API key yet.
	 *
	 * @return SummaryGeneratorInterface
	 */
	private function get_generator() {
		$settings = get_option( 'topersia_ai_settings', array() );
		$engine   = isset( $settings['summary_engine'] ) ? $settings['summary_engine'] : 'internal';

		if ( 'ai' === $engine ) {
			$generator = apply_filters( 'topersia_ai_summary_generator', new OpenAIGenerator() );

			if ( $generator instanceof SummaryGeneratorInterface && $generator->is_configured() ) {
				return $generator;
			}

			// No AI provider configured — fall back rather than fail.
			return new InternalGenerator();
		}

		return new InternalGenerator();
	}
}
