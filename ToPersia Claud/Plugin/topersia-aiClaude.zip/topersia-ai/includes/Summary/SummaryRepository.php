<?php
/**
 * Low-level CRUD for AI-generated content summaries. Contains no business
 * logic (staleness, generation, ...) - that lives in SummaryManager.
 *
 * @package ToPersia\AI\Summary
 */

namespace ToPersia\AI\Summary;

use ToPersia\AI\Database\Database;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class SummaryRepository {

	/**
	 * Finds a summary row for a post + language.
	 *
	 * @param int    $post_id  Post ID.
	 * @param string $language Language code.
	 * @return array|null Associative row, or null when not found.
	 */
	public function find( $post_id, $language ) {
		global $wpdb;
		$table = Database::summaries_table();

		$row = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM {$table} WHERE post_id = %d AND language = %s LIMIT 1",
				$post_id,
				$language
			),
			ARRAY_A
		);

		return is_array( $row ) ? $row : null;
	}

	/**
	 * Inserts or updates a summary row for a post + language (upsert).
	 *
	 * @param int   $post_id  Post ID.
	 * @param string $language Language code.
	 * @param array $fields   Column => value pairs to write.
	 * @return int Row ID.
	 */
	public function upsert( $post_id, $language, array $fields ) {
		global $wpdb;
		$table    = Database::summaries_table();
		$existing = $this->find( $post_id, $language );
		$now      = current_time( 'mysql' );

		$fields['updated_at'] = $now;

		if ( $existing ) {
			$wpdb->update(
				$table,
				$fields,
				array(
					'post_id'  => $post_id,
					'language' => $language,
				)
			);

			return (int) $existing['id'];
		}

		$fields['post_id']    = $post_id;
		$fields['language']   = $language;
		$fields['created_at'] = $now;

		$wpdb->insert( $table, $fields );

		return (int) $wpdb->insert_id;
	}

	/**
	 * Deletes a summary row.
	 *
	 * @param int    $post_id  Post ID.
	 * @param string $language Language code.
	 * @return bool
	 */
	public function delete( $post_id, $language ) {
		global $wpdb;
		$table = Database::summaries_table();

		return (bool) $wpdb->delete( $table, array( 'post_id' => $post_id, 'language' => $language ) );
	}

	/**
	 * Marks every summary for a post as stale, across all languages. Used
	 * when the source content changes.
	 *
	 * @param int $post_id Post ID.
	 * @return void
	 */
	public function mark_all_stale( $post_id ) {
		global $wpdb;
		$table = Database::summaries_table();

		$wpdb->update(
			$table,
			array(
				'status'     => 'stale',
				'updated_at' => current_time( 'mysql' ),
			),
			array( 'post_id' => $post_id )
		);
	}

	/**
	 * Returns a paginated list of summaries for the admin list table.
	 *
	 * @param array $args {
	 *     @type string $status Optional status filter.
	 *     @type int    $page   1-based page number.
	 *     @type int    $per_page Rows per page.
	 * }
	 * @return array{items: array<int,array>, total: int}
	 */
	public function paginate( array $args = array() ) {
		global $wpdb;
		$table = Database::summaries_table();

		$page     = max( 1, (int) ( $args['page'] ?? 1 ) );
		$per_page = max( 1, (int) ( $args['per_page'] ?? 20 ) );
		$offset   = ( $page - 1 ) * $per_page;

		$where  = 'WHERE 1=1';
		$params = array();

		if ( ! empty( $args['status'] ) ) {
			$where   .= ' AND status = %s';
			$params[] = sanitize_key( $args['status'] );
		}

		$count_sql = "SELECT COUNT(*) FROM {$table} {$where}";
		$total     = (int) ( $params ? $wpdb->get_var( $wpdb->prepare( $count_sql, $params ) ) : $wpdb->get_var( $count_sql ) );

		$list_sql    = "SELECT * FROM {$table} {$where} ORDER BY updated_at DESC LIMIT %d OFFSET %d";
		$list_params = array_merge( $params, array( $per_page, $offset ) );
		$items       = $wpdb->get_results( $wpdb->prepare( $list_sql, $list_params ), ARRAY_A );

		return array(
			'items' => is_array( $items ) ? $items : array(),
			'total' => $total,
		);
	}
}
