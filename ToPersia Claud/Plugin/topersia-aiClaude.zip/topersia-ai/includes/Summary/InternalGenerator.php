<?php
/**
 * Built-in, offline "internal engine": produces a summary, key points, and
 * a basic itinerary suggestion purely from the post's own content and
 * structured data (JetEngine fields/relations, taxonomies) — no AI API
 * call, no API key, nothing ever leaves the server.
 *
 * The algorithm is a classic extractive-summarization approach (TF scoring
 * + lead-position bias + title-overlap bonus), not a generative model: it
 * selects and reorders sentences that already exist in the source content
 * rather than writing new ones. This makes it fast, free, fully
 * deterministic, and safe to run on every post without rate limits or
 * cost — a sensible default, and a solid fallback when no AI provider is
 * configured.
 *
 * @package ToPersia\AI\Summary
 */

namespace ToPersia\AI\Summary;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class InternalGenerator implements SummaryGeneratorInterface {

	/**
	 * Small, deliberately compact stopword list (Persian + English). This
	 * is not meant to be linguistically exhaustive — it only needs to
	 * filter out the highest-frequency function words that would otherwise
	 * dominate the frequency score.
	 *
	 * @var string[]
	 */
	private $stopwords = array(
		// Persian.
		'و', 'در', 'به', 'از', 'که', 'این', 'را', 'با', 'است', 'برای',
		'آن', 'یک', 'های', 'شود', 'شد', 'می', 'تا', 'هم', 'یا', 'اما',
		'نیز', 'بر', 'روی', 'اگر', 'چون', 'خود', 'ها', 'کند', 'کرد',
		'بود', 'شده', 'دارد', 'داشت', 'دیگر', 'همه', 'هر', 'وی', 'او',
		// English.
		'the', 'a', 'an', 'and', 'or', 'but', 'of', 'to', 'in', 'on',
		'for', 'with', 'is', 'are', 'was', 'were', 'this', 'that', 'it',
		'as', 'at', 'by', 'from', 'be', 'has', 'have', 'had',
	);

	public function get_id() {
		return 'internal';
	}

	/**
	 * The internal engine needs no configuration - it always works.
	 *
	 * @return bool
	 */
	public function is_configured() {
		return true;
	}

	/**
	 * {@inheritDoc}
	 *
	 * Ignores $prompt (which is written for a conversational AI) and works
	 * directly from $context, since extractive summarization operates on
	 * the source sentences themselves, not on an instruction string.
	 */
	public function generate( $prompt, array $context ) {
		$summary = $this->summarize( $context, 3 );

		if ( '' === $summary ) {
			return new \WP_Error( 'topersia_ai_internal_no_content', __( 'Not enough content to summarize.', 'topersia-ai' ) );
		}

		return $summary;
	}

	/**
	 * Produces a short extractive summary: the N highest-scoring sentences,
	 * restored to their original order for readability.
	 *
	 * @param array<string,mixed> $context     Context array (see ContextBuilder).
	 * @param int                 $sentence_count Number of sentences to keep.
	 * @return string Plain-text summary (may contain simple paragraph breaks).
	 */
	public function summarize( array $context, $sentence_count = 3 ) {
		$sentences = $this->split_sentences( $context['content_text'] ?? '' );

		if ( empty( $sentences ) ) {
			return '';
		}

		$scored = $this->score_sentences( $sentences, $context );

		arsort( $scored );
		$top_indexes = array_slice( array_keys( $scored ), 0, max( 1, (int) $sentence_count ), true );
		sort( $top_indexes ); // Restore original reading order.

		$picked = array();
		foreach ( $top_indexes as $index ) {
			$picked[] = trim( $sentences[ $index ] );
		}

		return esc_html( implode( ' ', $picked ) );
	}

	/**
	 * Produces a list of "key points": distinct high-scoring sentences not
	 * already used in the summary, plus any structured JetEngine fields
	 * that look like standalone facts (short values, e.g. "Best season:
	 * Spring"), which tend to make excellent bullet points.
	 *
	 * @param array<string,mixed> $context Context array.
	 * @param int                 $limit   Maximum number of points.
	 * @return string[] Plain-text bullet strings.
	 */
	public function key_points( array $context, $limit = 5 ) {
		$points = array();

		// Structured facts first - they are the highest-signal, lowest-risk
		// bullet points since they come from admin-entered custom fields.
		if ( ! empty( $context['jetengine']['meta_fields'] ) && is_array( $context['jetengine']['meta_fields'] ) ) {
			foreach ( $context['jetengine']['meta_fields'] as $key => $value ) {
				if ( ! is_scalar( $value ) || '' === trim( (string) $value ) ) {
					continue;
				}
				if ( function_exists( 'mb_strlen' ) ? mb_strlen( (string) $value ) > 80 : strlen( (string) $value ) > 80 ) {
					continue; // Too long to be a "fact"; leave it to sentence extraction.
				}
				$label    = ucwords( str_replace( array( '_', '-' ), ' ', $key ) );
				$points[] = sprintf( '%s: %s', $label, $value );
				if ( count( $points ) >= $limit ) {
					return array_map( 'esc_html', $points );
				}
			}
		}

		$sentences = $this->split_sentences( $context['content_text'] ?? '' );

		if ( empty( $sentences ) ) {
			return array_map( 'esc_html', $points );
		}

		$scored = $this->score_sentences( $sentences, $context );
		arsort( $scored );

		foreach ( array_keys( $scored ) as $index ) {
			if ( count( $points ) >= $limit ) {
				break;
			}
			$points[] = trim( $sentences[ $index ] );
		}

		return array_map( 'esc_html', $points );
	}

	/**
	 * Produces a simple, templated itinerary suggestion built from
	 * JetEngine Relations (related posts) when available, falling back to
	 * taxonomy terms as loose "themes" to explore. This is intentionally a
	 * structural suggestion, not a generated narrative - that distinction
	 * is what keeps it honest about being non-AI.
	 *
	 * @param array<string,mixed> $context Context array.
	 * @return string Plain-text itinerary suggestion, or '' if there is
	 *                nothing structured enough to build one from.
	 */
	public function itinerary( array $context ) {
		$title     = isset( $context['title'] ) ? $context['title'] : '';
		$relations = ! empty( $context['jetengine']['relations'] ) && is_array( $context['jetengine']['relations'] )
			? $context['jetengine']['relations']
			: array();

		$stops = array();
		foreach ( $relations as $items ) {
			foreach ( (array) $items as $item ) {
				if ( ! empty( $item['title'] ) ) {
					$stops[] = $item['title'];
				}
				if ( count( $stops ) >= 4 ) {
					break 2;
				}
			}
		}

		if ( empty( $stops ) && ! empty( $context['tags'] ) ) {
			$stops = array_slice( (array) $context['tags'], 0, 3 );
		}

		if ( empty( $stops ) || '' === $title ) {
			return '';
		}

		$lines   = array();
		$lines[] = sprintf(
			/* translators: %s: destination title. */
			__( '۱. بازدید را از «%s» شروع کنید.', 'topersia-ai' ),
			$title
		);

		$step = 2;
		foreach ( $stops as $stop ) {
			$lines[] = sprintf(
				/* translators: 1: step number, 2: place name. */
				__( '%1$d. سپس سری به «%2$s» بزنید.', 'topersia-ai' ),
				$step,
				$stop
			);
			++$step;
		}

		return esc_html( implode( ' ', $lines ) );
	}

	/**
	 * Splits plain text into sentences. Handles both Latin (`. ! ?`) and
	 * Persian (`؟` and `.`/`!` reused as-is) sentence terminators.
	 *
	 * @param string $text Plain text.
	 * @return string[] Sentences, trimmed, empty ones removed.
	 */
	private function split_sentences( $text ) {
		$text = trim( (string) $text );

		if ( '' === $text ) {
			return array();
		}

		$parts = preg_split( '/(?<=[\.!\?؟])\s+/u', $text );

		if ( ! is_array( $parts ) ) {
			return array( $text );
		}

		$parts = array_map( 'trim', $parts );
		$parts = array_values( array_filter( $parts, static fn( $s ) => '' !== $s ) );

		return $parts;
	}

	/**
	 * Scores each sentence: sum of non-stopword token frequencies, with a
	 * lead-position bonus (earlier sentences tend to carry more summary
	 * value) and a title-overlap bonus (sentences that share words with
	 * the title are usually on-topic).
	 *
	 * @param string[]             $sentences Sentences to score.
	 * @param array<string,mixed>  $context   Context array (for the title).
	 * @return array<int,float> index => score, in original sentence order.
	 */
	private function score_sentences( array $sentences, array $context ) {
		$all_tokens  = array();
		$per_sentence = array();

		foreach ( $sentences as $index => $sentence ) {
			$tokens                    = $this->tokenize( $sentence );
			$per_sentence[ $index ]    = $tokens;
			$all_tokens                = array_merge( $all_tokens, $tokens );
		}

		$frequency = array_count_values( $all_tokens );
		$title_tokens = array_flip( $this->tokenize( isset( $context['title'] ) ? $context['title'] : '' ) );

		$scores    = array();
		$total     = max( 1, count( $sentences ) );

		foreach ( $per_sentence as $index => $tokens ) {
			if ( empty( $tokens ) ) {
				$scores[ $index ] = 0.0;
				continue;
			}

			$freq_score = 0;
			$title_hits = 0;

			foreach ( $tokens as $token ) {
				$freq_score += isset( $frequency[ $token ] ) ? $frequency[ $token ] : 0;
				if ( isset( $title_tokens[ $token ] ) ) {
					++$title_hits;
				}
			}

			$normalized = $freq_score / count( $tokens );
			$lead_bonus = 1 - ( $index / ( $total * 4 ) ); // Small, gentle bias toward earlier sentences.
			$title_bonus = 1 + ( 0.15 * $title_hits );

			$scores[ $index ] = $normalized * $lead_bonus * $title_bonus;
		}

		return $scores;
	}

	/**
	 * Tokenizes a string into lowercase, stopword-filtered word tokens.
	 * Unicode-aware so Persian text is handled correctly.
	 *
	 * @param string $text Text to tokenize.
	 * @return string[]
	 */
	private function tokenize( $text ) {
		if ( '' === trim( (string) $text ) ) {
			return array();
		}

		preg_match_all( '/[\p{L}\p{N}]+/u', mb_strtolower( $text ), $matches );
		$tokens = isset( $matches[0] ) ? $matches[0] : array();

		return array_values(
			array_filter(
				$tokens,
				function ( $token ) {
					return mb_strlen( $token ) > 1 && ! in_array( $token, $this->stopwords, true );
				}
			)
		);
	}
}
