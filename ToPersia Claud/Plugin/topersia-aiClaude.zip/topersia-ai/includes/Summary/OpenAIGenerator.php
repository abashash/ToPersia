<?php
/**
 * Generates summaries via an OpenAI-compatible Chat Completions endpoint.
 *
 * Uses wp_remote_post exclusively (no cURL directly, no external SDKs, no
 * Node.js build step) so it runs on any standard WordPress host. The API
 * key is read from options and is NEVER echoed to the page, sent in a REST
 * response body, or passed to frontend JavaScript.
 *
 * IMPORTANT (development note, also documented in docs/TESTING.md): this
 * class could not be exercised end-to-end in the development sandbox
 * because outbound network access was unavailable there. Review the
 * request/response handling before relying on it in production and test
 * against a real API key on a live WordPress install first.
 *
 * @package ToPersia\AI\Summary
 */

namespace ToPersia\AI\Summary;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class OpenAIGenerator implements SummaryGeneratorInterface {

	public function get_id() {
		return 'openai';
	}

	public function is_configured() {
		return '' !== $this->get_api_key();
	}

	/**
	 * {@inheritDoc}
	 */
	public function generate( $prompt, array $context ) {
		if ( ! $this->is_configured() ) {
			return new \WP_Error( 'topersia_ai_not_configured', __( 'No OpenAI API key is configured. Add one under ToPersia AI → Settings → AI Providers.', 'topersia-ai' ) );
		}

		$settings = get_option( 'topersia_ai_settings', array() );
		$model    = ! empty( $settings['openai_model'] ) ? $settings['openai_model'] : 'gpt-4o-mini';

		$body = array(
			'model'       => $model,
			'messages'    => array(
				array(
					'role'    => 'system',
					'content' => 'You write concise, factual content summaries in the same language as the source content. Never invent facts that are not present in the provided context.',
				),
				array(
					'role'    => 'user',
					'content' => $prompt,
				),
			),
			'temperature' => 0.3,
			'max_tokens'  => 500,
		);

		$response = wp_remote_post(
			'https://api.openai.com/v1/chat/completions',
			array(
				'timeout' => 25,
				'headers' => array(
					'Authorization' => 'Bearer ' . $this->get_api_key(),
					'Content-Type'  => 'application/json',
				),
				'body'    => wp_json_encode( $body ),
			)
		);

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$code = wp_remote_retrieve_response_code( $response );
		$data = json_decode( wp_remote_retrieve_body( $response ), true );

		if ( $code < 200 || $code >= 300 ) {
			$message = isset( $data['error']['message'] ) ? $data['error']['message'] : __( 'Unknown API error.', 'topersia-ai' );
			return new \WP_Error( 'topersia_ai_api_error', $message, array( 'status' => $code ) );
		}

		$text = isset( $data['choices'][0]['message']['content'] ) ? trim( $data['choices'][0]['message']['content'] ) : '';

		if ( '' === $text ) {
			return new \WP_Error( 'topersia_ai_empty_response', __( 'The AI provider returned an empty response.', 'topersia-ai' ) );
		}

		return wp_kses_post( $text );
	}

	/**
	 * Reads the OpenAI API key from options. Stored server-side only.
	 *
	 * @return string
	 */
	private function get_api_key() {
		$settings = get_option( 'topersia_ai_settings', array() );

		return isset( $settings['openai_api_key'] ) ? trim( (string) $settings['openai_api_key'] ) : '';
	}
}
