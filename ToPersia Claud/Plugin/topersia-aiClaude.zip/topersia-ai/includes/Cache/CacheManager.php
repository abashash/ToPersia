<?php
/**
 * Thin wrapper around WordPress's object cache / transients API, giving the
 * rest of the plugin a single place to change caching strategy later
 * (e.g. swap to a dedicated cache group or external store).
 *
 * @package ToPersia\AI\Cache
 */

namespace ToPersia\AI\Cache;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class CacheManager {

	const GROUP  = 'topersia_ai';
	const PREFIX = 'topersia_ai_';

	/**
	 * Retrieves a cached value.
	 *
	 * @param string $key Cache key (unprefixed).
	 * @return mixed|false Value, or false on miss.
	 */
	public function get( $key ) {
		if ( wp_using_ext_object_cache() ) {
			return wp_cache_get( $key, self::GROUP );
		}

		return get_transient( self::PREFIX . $key );
	}

	/**
	 * Stores a value in cache.
	 *
	 * @param string $key   Cache key (unprefixed).
	 * @param mixed  $value Value to store.
	 * @param int    $ttl   Time to live, in seconds.
	 * @return bool
	 */
	public function set( $key, $value, $ttl = null ) {
		if ( null === $ttl ) {
			$settings = get_option( 'topersia_ai_settings', array() );
			$ttl      = isset( $settings['cache_ttl'] ) ? (int) $settings['cache_ttl'] : DAY_IN_SECONDS;
		}

		if ( wp_using_ext_object_cache() ) {
			return wp_cache_set( $key, $value, self::GROUP, $ttl );
		}

		return set_transient( self::PREFIX . $key, $value, $ttl );
	}

	/**
	 * Deletes a cached value.
	 *
	 * @param string $key Cache key (unprefixed).
	 * @return bool
	 */
	public function delete( $key ) {
		if ( wp_using_ext_object_cache() ) {
			return wp_cache_delete( $key, self::GROUP );
		}

		return delete_transient( self::PREFIX . $key );
	}

	/**
	 * Builds a stable cache key for a post's rendered Ask AI / summary
	 * output so identical requests are not rebuilt on every page view.
	 *
	 * @param int    $post_id Post ID.
	 * @param string $suffix  Extra disambiguator, e.g. "ask_ai" or "summary".
	 * @return string
	 */
	public function key_for_post( $post_id, $suffix ) {
		return 'post_' . (int) $post_id . '_' . sanitize_key( $suffix );
	}

	/**
	 * Flushes every plugin-owned transient. Used on deactivation and when
	 * settings change in a way that invalidates cached output (e.g. label
	 * or provider list changes).
	 *
	 * @return void
	 */
	public static function flush_all() {
		global $wpdb;

		$like = $wpdb->esc_like( '_transient_' . self::PREFIX ) . '%';
		$wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->options} WHERE option_name LIKE %s", $like ) ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared

		$like_timeout = $wpdb->esc_like( '_transient_timeout_' . self::PREFIX ) . '%';
		$wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->options} WHERE option_name LIKE %s", $like_timeout ) ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared

		if ( wp_using_ext_object_cache() && function_exists( 'wp_cache_flush_group' ) ) {
			wp_cache_flush_group( self::GROUP );
		}
	}
}
