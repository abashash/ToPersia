<?php
/**
 * REST API endpoints under the `topersia-ai/v1` namespace.
 *
 * Every route is nonce-protected via the standard `X-WP-Nonce` header
 * (WordPress validates this automatically for logged-in requests when the
 * nonce action is "wp_rest" and `permission_callback` checks capabilities
 * explicitly - we never rely on nonce presence alone for authorization).
 *
 * @package ToPersia\AI\REST
 */

namespace ToPersia\AI\REST;

use ToPersia\AI\Summary\SummaryManager;
use ToPersia\AI\Analytics\AnalyticsTracker;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class RestController {

	const NAMESPACE = 'topersia-ai/v1';

	/** @var SummaryManager */
	private $summary_manager;

	/** @var AnalyticsTracker */
	private $analytics;

	public function __construct( SummaryManager $summary_manager, AnalyticsTracker $analytics ) {
		$this->summary_manager = $summary_manager;
		$this->analytics       = $analytics;

		add_action( 'rest_api_init', array( $this, 'register_routes' ) );
	}

	/**
	 * Registers all REST routes.
	 *
	 * @return void
	 */
	public function register_routes() {
		register_rest_route(
			self::NAMESPACE,
			'/summary/(?P<post_id>\d+)/generate',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'generate_summary' ),
				'permission_callback' => array( $this, 'can_edit_post_permission' ),
				'args'                => array(
					'post_id'  => array( 'required' => true, 'type' => 'integer' ),
					'language' => array( 'required' => false, 'type' => 'string' ),
				),
			)
		);

		register_rest_route(
			self::NAMESPACE,
			'/summary/(?P<post_id>\d+)',
			array(
				'methods'             => 'PUT',
				'callback'            => array( $this, 'save_manual_summary' ),
				'permission_callback' => array( $this, 'can_edit_post_permission' ),
				'args'                => array(
					'post_id'  => array( 'required' => true, 'type' => 'integer' ),
					'content'  => array( 'required' => true, 'type' => 'string' ),
					'language' => array( 'required' => false, 'type' => 'string' ),
				),
			)
		);

		register_rest_route(
			self::NAMESPACE,
			'/track',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'track_event' ),
				'permission_callback' => '__return_true', // Public: anonymous, aggregate click tracking only.
				'args'                => array(
					'post_id'    => array( 'required' => true, 'type' => 'integer' ),
					'event_type' => array( 'required' => true, 'type' => 'string' ),
					'provider'   => array( 'required' => false, 'type' => 'string' ),
					'module'     => array( 'required' => false, 'type' => 'string' ),
				),
			)
		);
	}

	/**
	 * Permission check shared by the two summary-editing routes.
	 *
	 * @param \WP_REST_Request $request Request object.
	 * @return bool|\WP_Error
	 */
	public function can_edit_post_permission( \WP_REST_Request $request ) {
		$post_id = (int) $request->get_param( 'post_id' );

		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return new \WP_Error( 'topersia_ai_forbidden', __( 'You are not allowed to edit this post.', 'topersia-ai' ), array( 'status' => 403 ) );
		}

		return true;
	}

	/**
	 * POST /summary/{post_id}/generate
	 *
	 * @param \WP_REST_Request $request Request object.
	 * @return \WP_REST_Response|\WP_Error
	 */
	public function generate_summary( \WP_REST_Request $request ) {
		$post_id  = (int) $request->get_param( 'post_id' );
		$language = $request->get_param( 'language' );

		$result = $this->summary_manager->generate( $post_id, $language ?: null );

		if ( is_wp_error( $result ) ) {
			return new \WP_REST_Response(
				array( 'message' => $result->get_error_message() ),
				500
			);
		}

		return new \WP_REST_Response( array( 'summary' => $result ), 200 );
	}

	/**
	 * PUT /summary/{post_id}
	 *
	 * @param \WP_REST_Request $request Request object.
	 * @return \WP_REST_Response
	 */
	public function save_manual_summary( \WP_REST_Request $request ) {
		$post_id  = (int) $request->get_param( 'post_id' );
		$content  = (string) $request->get_param( 'content' );
		$language = $request->get_param( 'language' );
		$language = $language ? sanitize_text_field( $language ) : \ToPersia\AI\Integrations\WPML\WPMLIntegration::current_language();

		$id = $this->summary_manager->save_manual( $post_id, $language, $content );

		return new \WP_REST_Response( array( 'id' => $id ), 200 );
	}

	/**
	 * POST /track — public, anonymous, aggregate-only event tracking.
	 * Rate-limited implicitly by requiring a valid post_id and known
	 * event_type; no user data is accepted or stored (see AnalyticsTracker).
	 *
	 * @param \WP_REST_Request $request Request object.
	 * @return \WP_REST_Response
	 */
	public function track_event( \WP_REST_Request $request ) {
		$post_id    = (int) $request->get_param( 'post_id' );
		$event_type = sanitize_key( (string) $request->get_param( 'event_type' ) );
		$provider   = $request->get_param( 'provider' );
		$module     = $request->get_param( 'module' );

		$allowed_events = array( 'ask_ai_click', 'summary_view' );

		if ( ! get_post( $post_id ) || ! in_array( $event_type, $allowed_events, true ) ) {
			return new \WP_REST_Response( array( 'tracked' => false ), 400 );
		}

		$this->analytics->record(
			$post_id,
			$event_type,
			$provider ? sanitize_key( $provider ) : null,
			$module ? sanitize_key( $module ) : 'ask_ai'
		);

		return new \WP_REST_Response( array( 'tracked' => true ), 200 );
	}
}
