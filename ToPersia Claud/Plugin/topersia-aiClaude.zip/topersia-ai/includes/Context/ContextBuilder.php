<?php
/**
 * Builds a structured, entity-aware context array for a given post.
 *
 * This is the single place that knows how to pull "what is this page
 * about" out of WordPress core, JetEngine (if present) and WPML (if
 * present). Nothing in this class is ToPersia-specific: entity type
 * detection relies on filterable heuristics so any site can adapt it.
 *
 * @package ToPersia\AI\Context
 */

namespace ToPersia\AI\Context;

use ToPersia\AI\Integrations\JetEngine\JetEngineIntegration;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class ContextBuilder {

	/**
	 * Post types recognised as tourism entities out of the box. Sites can
	 * extend/replace this map via the `topersia_ai_entity_type_map` filter
	 * instead of us hard-coding ToPersia's 42 post types here.
	 *
	 * @var array<string,string>
	 */
	private $default_entity_map = array(
		'destination'     => 'destination',
		'country'         => 'country',
		'province'        => 'province',
		'city'            => 'city',
		'attraction'      => 'attraction',
		'hotel'           => 'hotel',
		'restaurant'      => 'restaurant',
		'tour'            => 'tour',
		'activity'        => 'activity',
		'event'           => 'event',
		'travel-guide'    => 'travel-guide',
		'article'         => 'article',
		'transportation'  => 'transportation',
		'post'            => 'article',
		'page'            => 'other',
	);

	/**
	 * Builds the full context array for a post.
	 *
	 * @param int $post_id Post ID.
	 * @return array<string,mixed>
	 */
	public function build( $post_id ) {
		$post = get_post( $post_id );

		if ( ! $post instanceof \WP_Post ) {
			return array();
		}

		$context = array(
			'post_id'        => $post->ID,
			'title'          => get_the_title( $post ),
			'url'            => get_permalink( $post ),
			'excerpt'        => $this->get_excerpt( $post ),
			'content_text'   => $this->get_plain_content( $post ),
			'post_type'      => $post->post_type,
			'entity_type'    => $this->detect_entity_type( $post ),
			'language'       => $this->detect_language( $post ),
			'site_name'      => get_bloginfo( 'name' ),
			'categories'     => $this->get_terms( $post->ID, 'category' ),
			'tags'           => $this->get_terms( $post->ID, 'post_tag' ),
			'taxonomies'     => $this->get_all_taxonomy_terms( $post ),
			'jetengine'      => $this->get_jetengine_data( $post ),
		);

		$context['breadcrumb'] = $this->build_breadcrumb( $post, $context );

		/**
		 * Filters the fully-built context array before it is handed to the
		 * prompt engine or any AI provider.
		 *
		 * @param array    $context Context data.
		 * @param \WP_Post $post    Source post.
		 */
		return apply_filters( 'topersia_ai_context', $context, $post );
	}

	/**
	 * Returns a plain-text excerpt, generating one from content if needed.
	 *
	 * @param \WP_Post $post Post object.
	 * @return string
	 */
	private function get_excerpt( \WP_Post $post ) {
		if ( ! empty( $post->post_excerpt ) ) {
			return wp_strip_all_tags( $post->post_excerpt );
		}

		$content = $this->get_plain_content( $post );

		return wp_trim_words( $content, 55, '…' );
	}

	/**
	 * Strips shortcodes/blocks/HTML down to plain text for prompt building.
	 *
	 * @param \WP_Post $post Post object.
	 * @return string
	 */
	private function get_plain_content( \WP_Post $post ) {
		$content = $post->post_content;
		$content = strip_shortcodes( $content );
		$content = wp_strip_all_tags( $content );
		$content = preg_replace( '/\s+/u', ' ', $content );

		return trim( (string) $content );
	}

	/**
	 * Detects the entity type of a post using the filterable map, falling
	 * back to a generic "other" when nothing matches.
	 *
	 * @param \WP_Post $post Post object.
	 * @return string
	 */
	private function detect_entity_type( \WP_Post $post ) {
		$map = apply_filters( 'topersia_ai_entity_type_map', $this->default_entity_map );

		if ( isset( $map[ $post->post_type ] ) ) {
			return $map[ $post->post_type ];
		}

		return apply_filters( 'topersia_ai_entity_type', 'other', $post );
	}

	/**
	 * Detects the content language, deferring to WPML when active.
	 *
	 * @param \WP_Post $post Post object.
	 * @return string
	 */
	private function detect_language( \WP_Post $post ) {
		if ( function_exists( 'apply_filters' ) && has_filter( 'wpml_post_language_details' ) ) {
			$details = apply_filters( 'wpml_post_language_details', null, $post->ID );
			if ( is_array( $details ) && ! empty( $details['language_code'] ) ) {
				return $details['language_code'];
			}
		}

		return substr( get_locale(), 0, 2 );
	}

	/**
	 * Returns term names for a taxonomy.
	 *
	 * @param int    $post_id  Post ID.
	 * @param string $taxonomy Taxonomy slug.
	 * @return string[]
	 */
	private function get_terms( $post_id, $taxonomy ) {
		if ( ! taxonomy_exists( $taxonomy ) ) {
			return array();
		}

		$terms = get_the_terms( $post_id, $taxonomy );

		if ( ! is_array( $terms ) ) {
			return array();
		}

		return wp_list_pluck( $terms, 'name' );
	}

	/**
	 * Returns term names for every taxonomy registered on the post type,
	 * keyed by taxonomy slug. Useful for entity attributes such as
	 * "country", "region" or "amenity" that ToPersia models as taxonomies.
	 *
	 * @param \WP_Post $post Post object.
	 * @return array<string,string[]>
	 */
	private function get_all_taxonomy_terms( \WP_Post $post ) {
		$taxonomies = get_object_taxonomies( $post->post_type, 'names' );
		$result     = array();

		foreach ( $taxonomies as $taxonomy ) {
			$terms = $this->get_terms( $post->ID, $taxonomy );
			if ( ! empty( $terms ) ) {
				$result[ $taxonomy ] = $terms;
			}
		}

		return $result;
	}

	/**
	 * Delegates JetEngine field retrieval to the JetEngine integration,
	 * which itself no-ops safely when JetEngine is not active.
	 *
	 * @param \WP_Post $post Post object.
	 * @return array<string,mixed>
	 */
	private function get_jetengine_data( \WP_Post $post ) {
		if ( ! class_exists( JetEngineIntegration::class ) ) {
			return array();
		}

		return JetEngineIntegration::get_entity_data( $post->ID, $post->post_type );
	}

	/**
	 * Builds a breadcrumb trail describing where this content sits in the
	 * site's entity hierarchy, e.g. "Province → City → Attraction".
	 *
	 * Since ToPersia's actual parent/child relationships between entity
	 * post types are typically modelled with JetEngine Relations rather
	 * than native WordPress post parents, this builds the best breadcrumb
	 * it reasonably can from generic signals (post type hierarchy,
	 * taxonomy terms) and is fully filterable via `topersia_ai_breadcrumb`
	 * so a site can wire in its exact relation chain without touching
	 * plugin code.
	 *
	 * @param \WP_Post             $post    Post object.
	 * @param array<string,mixed>  $context Context array built so far.
	 * @return string[] Ordered breadcrumb labels.
	 */
	private function build_breadcrumb( \WP_Post $post, array $context ) {
		$crumbs = array();

		// 1) Native WP post-type hierarchy (works for hierarchical post
		// types, e.g. Page, or a CPT registered with 'hierarchical' => true).
		$ancestors = get_post_ancestors( $post );
		if ( ! empty( $ancestors ) ) {
			$ancestors = array_reverse( $ancestors );
			foreach ( $ancestors as $ancestor_id ) {
				$title = get_the_title( $ancestor_id );
				if ( $title ) {
					$crumbs[] = $title;
				}
			}
		}

		// 2) The entity type itself (e.g. "Attraction").
		if ( ! empty( $context['entity_type'] ) && 'other' !== $context['entity_type'] ) {
			$crumbs[] = ucfirst( str_replace( '-', ' ', $context['entity_type'] ) );
		}

		// 3) One or two leading taxonomy terms as loose thematic crumbs
		// (e.g. "Culture", "Practical") when no hierarchy was found above.
		if ( ! empty( $context['categories'] ) ) {
			foreach ( array_slice( (array) $context['categories'], 0, 2 ) as $term ) {
				$crumbs[] = $term;
			}
		}

		$crumbs = array_values( array_unique( array_filter( $crumbs ) ) );

		/**
		 * Filters the breadcrumb trail built for a post's AI Travel Brief.
		 * Use this to wire in exact JetEngine Relations-based hierarchy
		 * (e.g. Province → City → Attraction) instead of the generic
		 * fallback above.
		 *
		 * @param string[] $crumbs  Breadcrumb labels, in order.
		 * @param \WP_Post $post    Source post.
		 * @param array    $context Context array built so far.
		 */
		return apply_filters( 'topersia_ai_breadcrumb', $crumbs, $post, $context );
	}
}
