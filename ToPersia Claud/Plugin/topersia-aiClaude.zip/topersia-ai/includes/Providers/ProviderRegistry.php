<?php
/**
 * Registers built-in AI providers and exposes them to the rest of the
 * plugin. Third-party code can add its own providers via the
 * `topersia_ai_register_providers` action, e.g.:
 *
 *   add_action( 'topersia_ai_register_providers', function( $registry ) {
 *       $registry->register( new My_Custom_Provider() );
 *   } );
 *
 * @package ToPersia\AI\Providers
 */

namespace ToPersia\AI\Providers;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class ProviderRegistry {

	/**
	 * Registered providers, keyed by ID.
	 *
	 * @var array<string,ProviderInterface>
	 */
	private $providers = array();

	public function __construct() {
		$this->register( new ChatGPTProvider() );
		$this->register( new ClaudeProvider() );
		$this->register( new GeminiProvider() );
		$this->register( new PerplexityProvider() );
		$this->register( new GrokProvider() );
		$this->register( new CopilotProvider() );

		/**
		 * Allows extensions to register additional AI providers.
		 *
		 * @param ProviderRegistry $registry This registry instance.
		 */
		do_action( 'topersia_ai_register_providers', $this );
	}

	/**
	 * Registers a provider. A provider registered with an already-used ID
	 * replaces the previous one, which lets sites override a built-in
	 * provider's behaviour without forking the plugin.
	 *
	 * @param ProviderInterface $provider Provider instance.
	 * @return void
	 */
	public function register( ProviderInterface $provider ) {
		$this->providers[ $provider->get_id() ] = $provider;
	}

	/**
	 * Returns a provider by ID, or null if not registered.
	 *
	 * @param string $id Provider ID.
	 * @return ProviderInterface|null
	 */
	public function get( $id ) {
		return isset( $this->providers[ $id ] ) ? $this->providers[ $id ] : null;
	}

	/**
	 * Returns every registered provider, regardless of availability.
	 *
	 * @return ProviderInterface[]
	 */
	public function all() {
		return $this->providers;
	}

	/**
	 * Returns only providers currently enabled/available (per site
	 * settings), in the admin-configured order.
	 *
	 * @return ProviderInterface[]
	 */
	public function available() {
		$settings = get_option( 'topersia_ai_settings', array() );
		$order    = isset( $settings['ask_ai_providers'] ) ? (array) $settings['ask_ai_providers'] : array_keys( $this->providers );

		$ordered = array();

		foreach ( $order as $id ) {
			if ( isset( $this->providers[ $id ] ) && $this->providers[ $id ]->is_available() ) {
				$ordered[] = $this->providers[ $id ];
			}
		}

		return $ordered;
	}
}
