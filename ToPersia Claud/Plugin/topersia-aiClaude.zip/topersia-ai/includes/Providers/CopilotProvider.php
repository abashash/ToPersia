<?php
/**
 * Microsoft Copilot external-link provider.
 *
 * @package ToPersia\AI\Providers
 */

namespace ToPersia\AI\Providers;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class CopilotProvider extends AbstractProvider {

	public function get_id() {
		return 'copilot';
	}

	public function get_name() {
		return __( 'Copilot', 'topersia-ai' );
	}

	public function get_icon() {
		return '<svg viewBox="0 0 24 24" width="20" height="20" fill="currentColor" aria-hidden="true"><path d="M12 2a5 5 0 0 1 5 5v3.2a5 5 0 0 1 2.6 4.4c0 1.6-.9 3-2.2 3.8a4.9 4.9 0 0 1-4.6 2.6H12a4.9 4.9 0 0 1-4.6-2.6A4.4 4.4 0 0 1 5.2 14.6 5 5 0 0 1 7 7v0a5 5 0 0 1 5-5Zm-2 8.5a1.3 1.3 0 1 0 0 2.6 1.3 1.3 0 0 0 0-2.6Zm4 0a1.3 1.3 0 1 0 0 2.6 1.3 1.3 0 0 0 0-2.6Z"/></svg>';
	}

	public function build_external_url( $prompt, array $context = array() ) {
		$base = apply_filters( 'topersia_ai_provider_base_url_copilot', 'https://copilot.microsoft.com/' );

		return $base . '?q=' . $this->encode_prompt( $prompt );
	}

	public function get_capabilities() {
		return array(
			'external_link'       => true,
			'api'                 => false,
			'clipboard_fallback'  => true, // Copilot's prompt pre-fill support varies; clipboard is a safe fallback.
		);
	}
}
