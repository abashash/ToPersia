<?php
/**
 * Perplexity external-link provider.
 *
 * @package ToPersia\AI\Providers
 */

namespace ToPersia\AI\Providers;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class PerplexityProvider extends AbstractProvider {

	public function get_id() {
		return 'perplexity';
	}

	public function get_name() {
		return __( 'Perplexity', 'topersia-ai' );
	}

	public function get_icon() {
		return '<svg viewBox="0 0 24 24" width="20" height="20" fill="currentColor" aria-hidden="true"><path d="M12 2 3 7v10l9 5 9-5V7l-9-5Zm0 2.3 6.5 3.6L12 11.5 5.5 7.9 12 4.3Zm-7 5.4 6 3.3v6.6l-6-3.3v-6.6Zm8 9.9v-6.6l6-3.3v6.6l-6 3.3Z"/></svg>';
	}

	public function build_external_url( $prompt, array $context = array() ) {
		$base = apply_filters( 'topersia_ai_provider_base_url_perplexity', 'https://www.perplexity.ai/search' );

		return $base . '?q=' . $this->encode_prompt( $prompt );
	}
}
