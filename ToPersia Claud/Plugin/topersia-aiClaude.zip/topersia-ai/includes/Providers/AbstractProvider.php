<?php
/**
 * Shared behaviour for AI provider adapters.
 *
 * @package ToPersia\AI\Providers
 */

namespace ToPersia\AI\Providers;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

abstract class AbstractProvider implements ProviderInterface {

	/**
	 * {@inheritDoc}
	 */
	public function get_icon_type() {
		return 'svg';
	}

	/**
	 * {@inheritDoc}
	 */
	public function get_capabilities() {
		return array(
			'external_link' => true,
			'api'            => false,
		);
	}

	/**
	 * {@inheritDoc}
	 *
	 * Default availability: enabled in the "ask_ai_providers" setting.
	 */
	public function is_available() {
		$settings = get_option( 'topersia_ai_settings', array() );
		$enabled  = isset( $settings['ask_ai_providers'] ) ? (array) $settings['ask_ai_providers'] : array();

		return in_array( $this->get_id(), $enabled, true );
	}

	/**
	 * Helper: URL-encodes a prompt for use in a query string, trimming to a
	 * safe length so we never build a URL that gets silently truncated or
	 * rejected by the target service.
	 *
	 * @param string $prompt    Prompt text.
	 * @param int    $max_chars Maximum characters before encoding.
	 * @return string
	 */
	protected function encode_prompt( $prompt, $max_chars = 1800 ) {
		if ( function_exists( 'mb_substr' ) && function_exists( 'mb_strlen' ) && mb_strlen( $prompt ) > $max_chars ) {
			$prompt = mb_substr( $prompt, 0, $max_chars ) . '…';
		} elseif ( strlen( $prompt ) > $max_chars ) {
			$prompt = substr( $prompt, 0, $max_chars ) . '…';
		}

		return rawurlencode( $prompt );
	}
}
