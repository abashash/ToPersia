<?php
/**
 * Contract every AI provider adapter must implement.
 *
 * Providers are intentionally "dumb": they know how to describe themselves
 * and how to build a URL (or, in future API mode, how to call an API). They
 * never know about WordPress posts, JetEngine, or prompt templates - that
 * knowledge lives in AskAIRenderer / PromptEngine / ContextBuilder.
 *
 * @package ToPersia\AI\Providers
 */

namespace ToPersia\AI\Providers;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

interface ProviderInterface {

	/**
	 * Stable machine identifier, e.g. "chatgpt".
	 *
	 * @return string
	 */
	public function get_id();

	/**
	 * Human-readable display name, e.g. "ChatGPT".
	 *
	 * @return string
	 */
	public function get_name();

	/**
	 * Icon strategy: either an inline SVG string or a dashicon-style slug,
	 * depending on `get_icon_type()`.
	 *
	 * @return string
	 */
	public function get_icon();

	/**
	 * "svg" or "dashicon" - tells the renderer how to interpret get_icon().
	 *
	 * @return string
	 */
	public function get_icon_type();

	/**
	 * Builds the external URL that opens this provider with the given
	 * prompt pre-filled (where the provider's public UI supports it).
	 *
	 * @param string $prompt Rendered prompt text.
	 * @param array  $context Full context array, for providers that need
	 *                        more than the prompt (rare, but kept for
	 *                        forward compatibility).
	 * @return string
	 */
	public function build_external_url( $prompt, array $context = array() );

	/**
	 * Declares which optional capabilities this provider supports.
	 * Recognised keys: "external_link", "api".
	 *
	 * @return array<string,bool>
	 */
	public function get_capabilities();

	/**
	 * Whether the provider is currently usable (e.g. enabled in settings,
	 * and - for API mode - an API key is configured).
	 *
	 * @return bool
	 */
	public function is_available();
}
