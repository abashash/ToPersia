<?php
/**
 * Google Gemini external-link provider.
 *
 * Gemini's public web UI does not reliably support prompt pre-fill via
 * query string the way ChatGPT/Claude/Perplexity do, so this adapter opens
 * Gemini and copies the prompt to the clipboard client-side (handled in
 * assets/js/frontend.js) as a graceful fallback. The capability is flagged
 * accordingly so the frontend can show a short hint.
 *
 * @package ToPersia\AI\Providers
 */

namespace ToPersia\AI\Providers;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class GeminiProvider extends AbstractProvider {

	public function get_id() {
		return 'gemini';
	}

	public function get_name() {
		return __( 'Gemini', 'topersia-ai' );
	}

	public function get_icon() {
		return '<svg viewBox="0 0 24 24" width="20" height="20" fill="currentColor" aria-hidden="true"><path d="M12 2c.9 4.9 5.1 9.1 10 10-4.9.9-9.1 5.1-10 10-.9-4.9-5.1-9.1-10-10 4.9-.9 9.1-5.1 10-10Z"/></svg>';
	}

	public function build_external_url( $prompt, array $context = array() ) {
		$base = apply_filters( 'topersia_ai_provider_base_url_gemini', 'https://gemini.google.com/app' );

		// Gemini does not reliably honour a "q" param on the public web
		// app, so we pass it anyway (harmless if ignored) and rely on the
		// clipboard-copy fallback in JS for a good UX either way.
		return $base . '?q=' . $this->encode_prompt( $prompt );
	}

	public function get_capabilities() {
		return array(
			'external_link'   => true,
			'api'             => false,
			'clipboard_fallback' => true,
		);
	}
}
