<?php
/**
 * ChatGPT (OpenAI) external-link provider.
 *
 * @package ToPersia\AI\Providers
 */

namespace ToPersia\AI\Providers;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class ChatGPTProvider extends AbstractProvider {

	public function get_id() {
		return 'chatgpt';
	}

	public function get_name() {
		return __( 'ChatGPT', 'topersia-ai' );
	}

	public function get_icon() {
		return '<svg viewBox="0 0 24 24" width="20" height="20" fill="currentColor" aria-hidden="true"><path d="M22.28 9.82a5.99 5.99 0 0 0-.52-4.92 6.05 6.05 0 0 0-6.51-2.9A6.07 6.07 0 0 0 4.98 4.18a5.99 5.99 0 0 0-4 2.9 6.05 6.05 0 0 0 .75 7.1 5.99 5.99 0 0 0 .51 4.92 6.05 6.05 0 0 0 6.52 2.9 6 6 0 0 0 4.4 1.96 6.07 6.07 0 0 0 5.8-4.22 5.99 5.99 0 0 0 4-2.9 6.05 6.05 0 0 0-.68-7.02Z" fill-opacity="0"/><path d="M12 5.2c1.9-1.6 4.7-1.5 6.4.4 1.1 1.2 1.5 2.9 1.1 4.5l-.2.6.5.4c1.4 1.1 2 3 1.4 4.7-.6 1.7-2.2 2.8-4 2.8h-.6l-.3.5c-1 1.7-3 2.5-4.9 2-1-.3-1.8-.9-2.4-1.8l-.3-.5h-.6c-1.9 0-3.6-1.2-4.1-3-.4-1.4 0-2.9 1-4l.4-.5-.2-.6c-.5-1.6 0-3.3 1.2-4.4C7.7 4.7 9.9 4.4 12 5.2Zm-.9 2.1c-1 .1-1.9.7-2.4 1.6-.2.4-.3.8-.4 1.2l3.6-2.1c.1-.4-.1-.7-.8-.7Zm5.3 8.5c.9-.4 1.5-1.3 1.5-2.3l-3.6 2.1c.6.5 1.4.5 2.1.2Z"/></svg>';
	}

	public function build_external_url( $prompt, array $context = array() ) {
		$base = apply_filters( 'topersia_ai_provider_base_url_chatgpt', 'https://chat.openai.com/' );

		return $base . '?q=' . $this->encode_prompt( $prompt );
	}
}
