<?php
/**
 * Grok (xAI) external-link provider.
 *
 * @package ToPersia\AI\Providers
 */

namespace ToPersia\AI\Providers;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class GrokProvider extends AbstractProvider {

	public function get_id() {
		return 'grok';
	}

	public function get_name() {
		return __( 'Grok', 'topersia-ai' );
	}

	public function get_icon() {
		return '<svg viewBox="0 0 24 24" width="20" height="20" fill="currentColor" aria-hidden="true"><path d="M4 4h3.4l4.6 6.4L16.6 4H20l-6.6 8.9L20.4 20H17l-5-6.9L6.6 20H3l6.9-9.3L4 4Z"/></svg>';
	}

	public function build_external_url( $prompt, array $context = array() ) {
		$base = apply_filters( 'topersia_ai_provider_base_url_grok', 'https://grok.com/' );

		return $base . '?q=' . $this->encode_prompt( $prompt );
	}
}
