<?php
/**
 * Claude (Anthropic) external-link provider.
 *
 * @package ToPersia\AI\Providers
 */

namespace ToPersia\AI\Providers;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class ClaudeProvider extends AbstractProvider {

	public function get_id() {
		return 'claude';
	}

	public function get_name() {
		return __( 'Claude', 'topersia-ai' );
	}

	public function get_icon() {
		return '<svg viewBox="0 0 24 24" width="20" height="20" fill="currentColor" aria-hidden="true"><path d="M6.5 3h3.1l5.9 15.2h-3.3l-1.2-3.3H5L3.8 18.2H.6L6.5 3Zm.6 9.1h3l-1.5-4.3-1.5 4.3Zm10.7-9.1H21l2.4 15.2h-3.2l-.4-2.9h-3.9l-.5 2.9h-3.1L17.8 3Zm.2 9.6h2.6l-.6-4.3-2 4.3Z"/></svg>';
	}

	public function build_external_url( $prompt, array $context = array() ) {
		$base = apply_filters( 'topersia_ai_provider_base_url_claude', 'https://claude.ai/new' );

		return $base . '?q=' . $this->encode_prompt( $prompt );
	}
}
