<?php
/**
 * Handles plugin activation: schema creation and default options.
 *
 * @package ToPersia\AI\Core
 */

namespace ToPersia\AI\Core;

use ToPersia\AI\Database\Database;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Activator {

	/**
	 * Runs on plugin activation.
	 *
	 * @return void
	 */
	public static function activate() {
		if ( ! current_user_can( 'activate_plugins' ) ) {
			return;
		}

		Database::install();
		self::set_default_options();

		update_option( 'topersia_ai_db_version', TOPERSIA_AI_DB_VERSION );
		update_option( 'topersia_ai_version', TOPERSIA_AI_VERSION );

		// Flush rewrite rules in case future modules register endpoints/CPTs.
		flush_rewrite_rules();
	}

	/**
	 * Sets sane default options on first activation only (never overwrites).
	 *
	 * @return void
	 */
	private static function set_default_options() {
		$defaults = array(
			'topersia_ai_settings' => array(
				'ask_ai_enabled'        => true,
				'ask_ai_label'          => __( 'این مطلب را با هوش مصنوعی بررسی کنید', 'topersia-ai' ),
				'ask_ai_providers'      => array( 'chatgpt', 'claude', 'perplexity', 'gemini', 'grok', 'copilot' ),
				'ask_ai_placement'      => 'after_content',
				'summary_enabled'       => true,
				'summary_engine'        => 'internal',
				'summary_auto_generate' => false,
				'summary_post_types'    => array( 'post' ),
				'cache_ttl'             => DAY_IN_SECONDS,
				'analytics_enabled'     => true,
				'icon_style'            => 'brand',
				'button_style'          => 'outlined',
				'accent_color'          => '#2563eb',
				'border_radius'         => 8,
			),
		);

		foreach ( $defaults as $option => $value ) {
			if ( false === get_option( $option ) ) {
				add_option( $option, $value );
			}
		}
	}
}
