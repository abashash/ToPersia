<?php
/**
 * Central plugin container. Boots every module in a predictable order and
 * exposes shared services (context builder, prompt engine, provider
 * registry, summary manager, ...) to the rest of the plugin.
 *
 * @package ToPersia\AI\Core
 */

namespace ToPersia\AI\Core;

use ToPersia\AI\Context\ContextBuilder;
use ToPersia\AI\Prompt\PromptEngine;
use ToPersia\AI\Providers\ProviderRegistry;
use ToPersia\AI\Summary\SummaryManager;
use ToPersia\AI\Summary\SummaryRepository;
use ToPersia\AI\Cache\CacheManager;
use ToPersia\AI\Analytics\AnalyticsTracker;
use ToPersia\AI\AskAI\AskAIRenderer;
use ToPersia\AI\Brief\BriefRenderer;
use ToPersia\AI\Frontend\FrontendRenderer;
use ToPersia\AI\Frontend\Assets as FrontendAssets;
use ToPersia\AI\Shortcode\Shortcode;
use ToPersia\AI\REST\RestController;
use ToPersia\AI\Admin\AdminMenu;
use ToPersia\AI\Admin\Assets as AdminAssets;
use ToPersia\AI\Integrations\JetEngine\JetEngineIntegration;
use ToPersia\AI\Integrations\WPML\WPMLIntegration;
use ToPersia\AI\Integrations\Elementor\ElementorModule;
use ToPersia\AI\Integrations\Gutenberg\BlockRegistrar;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Plugin {

	/**
	 * Singleton instance.
	 *
	 * @var Plugin|null
	 */
	private static $instance = null;

	/**
	 * Simple service container.
	 *
	 * @var array<string,object>
	 */
	private $services = array();

	/**
	 * Returns (and lazily creates) the singleton instance.
	 *
	 * @return Plugin
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
			self::$instance->boot();
		}

		return self::$instance;
	}

	/**
	 * Private constructor - use instance().
	 */
	private function __construct() {}

	/**
	 * Boots every module. Order matters: services that others depend on are
	 * constructed first.
	 *
	 * @return void
	 */
	private function boot() {
		$this->load_textdomain();
		$this->maybe_upgrade();

		// Core services, shared across modules.
		$this->services['cache']     = new CacheManager();
		$this->services['context']   = new ContextBuilder();
		$this->services['prompts']   = new PromptEngine();
		$this->services['providers'] = new ProviderRegistry();
		$this->services['analytics'] = new AnalyticsTracker();

		$repository = new SummaryRepository();
		$this->services['summary_repository'] = $repository;
		$this->services['summary_manager']    = new SummaryManager(
			$repository,
			$this->services['context'],
			$this->services['prompts'],
			$this->services['cache']
		);

		$this->services['ask_ai'] = new AskAIRenderer(
			$this->services['providers'],
			$this->services['context'],
			$this->services['prompts']
		);

		$this->services['brief'] = new BriefRenderer(
			$this->services['context'],
			$this->services['prompts'],
			$this->services['providers'],
			$this->services['summary_manager']
		);

		// Integrations register themselves defensively (capability checks).
		$this->services['jetengine'] = new JetEngineIntegration();
		$this->services['wpml']      = new WPMLIntegration();

		// Delivery surfaces.
		$frontend_renderer = new FrontendRenderer(
			$this->services['ask_ai'],
			$this->services['summary_manager'],
			$this->services['brief']
		);
		$this->services['frontend']         = $frontend_renderer;
		$this->services['frontend_assets']  = new FrontendAssets();
		$this->services['shortcode']        = new Shortcode( $frontend_renderer );
		$this->services['elementor']        = new ElementorModule( $frontend_renderer );
		$this->services['gutenberg']        = new BlockRegistrar();
		$this->services['rest']             = new RestController(
			$this->services['summary_manager'],
			$this->services['analytics']
		);

		if ( is_admin() ) {
			$this->services['admin_menu']   = new AdminMenu( $this->services['summary_manager'] );
			$this->services['admin_assets'] = new AdminAssets();
		}

		/**
		 * Fires once ToPersia AI has finished booting all core services.
		 * Future first-party modules (AI Travel Assistant, AI FAQ, ...) and
		 * third-party extensions should hook here.
		 *
		 * @param Plugin $plugin The booted plugin container.
		 */
		do_action( 'topersia_ai_loaded', $this );
	}

	/**
	 * Loads the plugin translation files.
	 *
	 * @return void
	 */
	private function load_textdomain() {
		load_plugin_textdomain( 'topersia-ai', false, dirname( TOPERSIA_AI_BASENAME ) . '/languages' );
	}

	/**
	 * Runs lightweight DB migrations when the stored DB version is older
	 * than the code's expected version.
	 *
	 * @return void
	 */
	private function maybe_upgrade() {
		$installed = get_option( 'topersia_ai_db_version' );

		if ( $installed === TOPERSIA_AI_DB_VERSION ) {
			return;
		}

		if ( ! class_exists( '\\ToPersia\\AI\\Database\\Database' ) ) {
			return;
		}

		\ToPersia\AI\Database\Database::install();
		update_option( 'topersia_ai_db_version', TOPERSIA_AI_DB_VERSION );
	}

	/**
	 * Retrieves a registered service by key.
	 *
	 * @param string $key Service key.
	 * @return object|null
	 */
	public function get( $key ) {
		return isset( $this->services[ $key ] ) ? $this->services[ $key ] : null;
	}

	/**
	 * Prevent cloning of the singleton.
	 */
	private function __clone() {}

	/**
	 * Prevent unserializing of the singleton.
	 */
	public function __wakeup() {
		throw new \Exception( 'Cannot unserialize a singleton.' );
	}
}
