<?php
/**
 * Handles plugin deactivation.
 *
 * Deactivation must be non-destructive: user data (summaries, prompts,
 * analytics) is preserved. Only uninstall.php removes data, and only
 * when the site owner has explicitly opted in via settings.
 *
 * @package ToPersia\AI\Core
 */

namespace ToPersia\AI\Core;

use ToPersia\AI\Cache\CacheManager;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Deactivator {

	/**
	 * Runs on plugin deactivation.
	 *
	 * @return void
	 */
	public static function deactivate() {
		if ( ! current_user_can( 'activate_plugins' ) ) {
			return;
		}

		if ( class_exists( CacheManager::class ) ) {
			CacheManager::flush_all();
		}

		flush_rewrite_rules();
	}
}
