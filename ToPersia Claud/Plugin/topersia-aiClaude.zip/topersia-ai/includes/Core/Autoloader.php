<?php
/**
 * Lightweight PSR-4-style autoloader.
 *
 * We avoid a Composer dependency so the plugin has zero build/runtime
 * requirements beyond PHP itself (see NO NODE.JS / production constraints).
 *
 * @package ToPersia\AI\Core
 */

namespace ToPersia\AI\Core;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Autoloader {

	/**
	 * Root namespace handled by this autoloader.
	 *
	 * @var string
	 */
	private static $namespace = 'ToPersia\\AI\\';

	/**
	 * Base directory the namespace maps to.
	 *
	 * @var string
	 */
	private static $base_dir;

	/**
	 * Register the autoloader with PHP's SPL stack.
	 *
	 * @return void
	 */
	public static function register() {
		self::$base_dir = TOPERSIA_AI_PATH . 'includes/';
		spl_autoload_register( array( __CLASS__, 'autoload' ) );
	}

	/**
	 * Attempt to load a class file for the given fully-qualified class name.
	 *
	 * @param string $class Fully-qualified class name.
	 * @return void
	 */
	public static function autoload( $class ) {
		if ( 0 !== strpos( $class, self::$namespace ) ) {
			return; // Not ours.
		}

		$relative = substr( $class, strlen( self::$namespace ) );
		$relative = str_replace( '\\', DIRECTORY_SEPARATOR, $relative );
		$file     = self::$base_dir . $relative . '.php';

		if ( is_readable( $file ) ) {
			require $file;
		}
	}
}
