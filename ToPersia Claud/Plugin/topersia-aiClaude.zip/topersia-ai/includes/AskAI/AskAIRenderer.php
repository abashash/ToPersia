<?php
/**
 * Renders the "Ask AI" component: a row of provider buttons that open an
 * external AI service with a context-aware prompt pre-filled.
 *
 * @package ToPersia\AI\AskAI
 */

namespace ToPersia\AI\AskAI;

use ToPersia\AI\Providers\ProviderRegistry;
use ToPersia\AI\Context\ContextBuilder;
use ToPersia\AI\Prompt\PromptEngine;
use ToPersia\AI\Prompt\PromptManager;
use ToPersia\AI\Integrations\WPML\WPMLIntegration;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AskAIRenderer {

	/** @var ProviderRegistry */
	private $providers;

	/** @var ContextBuilder */
	private $context_builder;

	/** @var PromptEngine */
	private $prompt_engine;

	/** @var PromptManager */
	private $prompt_manager;

	public function __construct( ProviderRegistry $providers, ContextBuilder $context_builder, PromptEngine $prompt_engine ) {
		$this->providers       = $providers;
		$this->context_builder = $context_builder;
		$this->prompt_engine   = $prompt_engine;
		$this->prompt_manager  = new PromptManager();
	}

	/**
	 * Renders the Ask AI markup for a post.
	 *
	 * @param int $post_id Post ID.
	 * @return string HTML (escaped internally).
	 */
	public function render( $post_id ) {
		$settings = get_option( 'topersia_ai_settings', array() );

		if ( empty( $settings['ask_ai_enabled'] ) ) {
			return '';
		}

		$available = $this->providers->available();

		if ( empty( $available ) ) {
			return '';
		}

		$context  = $this->context_builder->build( $post_id );
		if ( empty( $context ) ) {
			return '';
		}

		$language = isset( $context['language'] ) ? $context['language'] : WPMLIntegration::current_language();
		$template = $this->prompt_manager->get_template( $context['entity_type'], 'ask_ai', $language );
		$prompt   = $this->prompt_engine->render( $template, $context );
		$label    = ! empty( $settings['ask_ai_label'] ) ? $settings['ask_ai_label'] : __( 'Ask AI about this page', 'topersia-ai' );
		$is_rtl   = WPMLIntegration::is_rtl_language( $language );

		ob_start();
		?>
		<div class="topersia-ai-ask" dir="<?php echo esc_attr( $is_rtl ? 'rtl' : 'ltr' ); ?>" data-post-id="<?php echo esc_attr( $post_id ); ?>">
			<p class="topersia-ai-ask__label"><?php echo esc_html( $label ); ?></p>
			<div class="topersia-ai-ask__buttons" role="group" aria-label="<?php echo esc_attr( $label ); ?>">
				<?php foreach ( $available as $provider ) : ?>
					<?php
					$url          = $provider->build_external_url( $prompt, $context );
					$capabilities = $provider->get_capabilities();
					$clipboard    = ! empty( $capabilities['clipboard_fallback'] );
					?>
					<a
						class="topersia-ai-ask__button"
						href="<?php echo esc_url( $url ); ?>"
						target="_blank"
						rel="noopener noreferrer nofollow"
						data-provider="<?php echo esc_attr( $provider->get_id() ); ?>"
						data-post-id="<?php echo esc_attr( $post_id ); ?>"
						<?php if ( $clipboard ) : ?>data-clipboard-prompt="<?php echo esc_attr( $prompt ); ?>"<?php endif; ?>
					>
						<span class="topersia-ai-ask__icon" aria-hidden="true"><?php echo $this->render_icon( $provider ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
						<span class="topersia-ai-ask__name"><?php echo esc_html( $provider->get_name() ); ?></span>
					</a>
				<?php endforeach; ?>
			</div>
		</div>
		<?php
		return (string) ob_get_clean();
	}

	/**
	 * Safely renders a provider's icon. SVG icons are hard-coded in
	 * first-party provider classes (never derived from user input), so
	 * this is the one deliberate, narrow exception to output escaping.
	 * Third-party providers are responsible for sanitising their own icon
	 * output.
	 *
	 * @param \ToPersia\AI\Providers\ProviderInterface $provider Provider.
	 * @return string
	 */
	private function render_icon( $provider ) {
		if ( 'svg' === $provider->get_icon_type() ) {
			return wp_kses(
				$provider->get_icon(),
				array(
					'svg'  => array(
						'viewbox'     => true,
						'width'       => true,
						'height'      => true,
						'fill'        => true,
						'aria-hidden' => true,
						'xmlns'       => true,
					),
					'path' => array(
						'd'            => true,
						'fill'         => true,
						'fill-opacity' => true,
					),
				)
			);
		}

		return '<span class="dashicons ' . esc_attr( $provider->get_icon() ) . '"></span>';
	}
}
