<?php
/**
 * Prompt Templates admin screen: list, create, edit, delete templates per
 * entity type / module / language. Uses classic admin-post.php form
 * submissions (nonce + capability checked) rather than JS/REST, since this
 * is low-frequency admin authoring, not a live frontend interaction.
 *
 * @package ToPersia\AI\Admin
 */

namespace ToPersia\AI\Admin;

use ToPersia\AI\Prompt\PromptManager;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class PromptManagerPage {

	const ACTION = 'topersia_ai_save_prompt';
	const NONCE  = 'topersia_ai_prompt_nonce';

	/** @var PromptManager */
	private $manager;

	public function __construct() {
		$this->manager = new PromptManager();

		add_action( 'admin_post_' . self::ACTION, array( $this, 'handle_save' ) );
		add_action( 'admin_post_topersia_ai_delete_prompt', array( $this, 'handle_delete' ) );
	}

	/**
	 * Handles the save (create/update) form submission.
	 *
	 * @return void
	 */
	public function handle_save() {
		if ( ! current_user_can( AdminMenu::CAPABILITY ) ) {
			wp_die( esc_html__( 'You are not allowed to do this.', 'topersia-ai' ) );
		}

		check_admin_referer( self::ACTION, self::NONCE );

		$result = $this->manager->save(
			array(
				'id'          => isset( $_POST['id'] ) ? absint( $_POST['id'] ) : 0,
				'slug'        => isset( $_POST['slug'] ) ? sanitize_key( wp_unslash( $_POST['slug'] ) ) : '',
				'label'       => isset( $_POST['label'] ) ? sanitize_text_field( wp_unslash( $_POST['label'] ) ) : '',
				'entity_type' => isset( $_POST['entity_type'] ) ? sanitize_key( wp_unslash( $_POST['entity_type'] ) ) : 'other',
				'module'      => isset( $_POST['module'] ) ? sanitize_key( wp_unslash( $_POST['module'] ) ) : 'summary',
				'template'    => isset( $_POST['template'] ) ? wp_kses_post( wp_unslash( $_POST['template'] ) ) : '',
				'language'    => isset( $_POST['language'] ) ? sanitize_text_field( wp_unslash( $_POST['language'] ) ) : '',
				'is_default'  => ! empty( $_POST['is_default'] ),
			)
		);

		$redirect_args = array( 'page' => 'topersia-ai-prompts' );

		if ( is_wp_error( $result ) ) {
			$redirect_args['topersia_ai_error'] = rawurlencode( $result->get_error_message() );
		} else {
			$redirect_args['topersia_ai_saved'] = 1;
		}

		wp_safe_redirect( add_query_arg( $redirect_args, admin_url( 'admin.php' ) ) );
		exit;
	}

	/**
	 * Handles prompt deletion.
	 *
	 * @return void
	 */
	public function handle_delete() {
		if ( ! current_user_can( AdminMenu::CAPABILITY ) ) {
			wp_die( esc_html__( 'You are not allowed to do this.', 'topersia-ai' ) );
		}

		check_admin_referer( 'topersia_ai_delete_prompt', 'topersia_ai_delete_nonce' );

		$id = isset( $_GET['id'] ) ? absint( $_GET['id'] ) : 0;

		if ( $id ) {
			$this->manager->delete( $id );
		}

		wp_safe_redirect( add_query_arg( array( 'page' => 'topersia-ai-prompts', 'topersia_ai_deleted' => 1 ), admin_url( 'admin.php' ) ) );
		exit;
	}

	/**
	 * Renders the page: list table + add/edit form.
	 *
	 * @return void
	 */
	public function render() {
		if ( ! current_user_can( AdminMenu::CAPABILITY ) ) {
			return;
		}

		$editing = null;
		if ( ! empty( $_GET['edit'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only list filter, no state change.
			$id = absint( $_GET['edit'] ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			foreach ( $this->manager->all() as $row ) {
				if ( (int) $row['id'] === $id ) {
					$editing = $row;
					break;
				}
			}
		}

		$prompts = $this->manager->all();
		?>
		<div class="wrap topersia-ai-admin">
			<h1><?php esc_html_e( 'ToPersia AI — Prompt Templates', 'topersia-ai' ); ?></h1>

			<?php if ( ! empty( $_GET['topersia_ai_saved'] ) ) : // phpcs:ignore WordPress.Security.NonceVerification.Recommended ?>
				<div class="notice notice-success is-dismissible"><p><?php esc_html_e( 'Prompt template saved.', 'topersia-ai' ); ?></p></div>
			<?php endif; ?>
			<?php if ( ! empty( $_GET['topersia_ai_deleted'] ) ) : // phpcs:ignore WordPress.Security.NonceVerification.Recommended ?>
				<div class="notice notice-success is-dismissible"><p><?php esc_html_e( 'Prompt template deleted.', 'topersia-ai' ); ?></p></div>
			<?php endif; ?>
			<?php if ( ! empty( $_GET['topersia_ai_error'] ) ) : // phpcs:ignore WordPress.Security.NonceVerification.Recommended ?>
				<div class="notice notice-error is-dismissible"><p><?php echo esc_html( wp_unslash( $_GET['topersia_ai_error'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended,WordPress.Security.ValidatedSanitizedInput.InputNotSanitized ?></p></div>
			<?php endif; ?>

			<h2><?php echo $editing ? esc_html__( 'Edit Prompt Template', 'topersia-ai' ) : esc_html__( 'Add Prompt Template', 'topersia-ai' ); ?></h2>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<?php wp_nonce_field( self::ACTION, self::NONCE ); ?>
				<input type="hidden" name="action" value="<?php echo esc_attr( self::ACTION ); ?>" />
				<input type="hidden" name="id" value="<?php echo esc_attr( $editing['id'] ?? '' ); ?>" />

				<table class="form-table" role="presentation">
					<tr>
						<th scope="row"><label for="slug"><?php esc_html_e( 'Slug', 'topersia-ai' ); ?></label></th>
						<td><input type="text" id="slug" name="slug" class="regular-text" value="<?php echo esc_attr( $editing['slug'] ?? '' ); ?>" required /></td>
					</tr>
					<tr>
						<th scope="row"><label for="label"><?php esc_html_e( 'Label', 'topersia-ai' ); ?></label></th>
						<td><input type="text" id="label" name="label" class="regular-text" value="<?php echo esc_attr( $editing['label'] ?? '' ); ?>" /></td>
					</tr>
					<tr>
						<th scope="row"><label for="entity_type"><?php esc_html_e( 'Entity type', 'topersia-ai' ); ?></label></th>
						<td>
							<input type="text" id="entity_type" name="entity_type" class="regular-text" value="<?php echo esc_attr( $editing['entity_type'] ?? 'other' ); ?>" />
							<p class="description"><?php esc_html_e( 'e.g. attraction, hotel, city, restaurant, tour, other. Must match the entity type your post types map to.', 'topersia-ai' ); ?></p>
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="module"><?php esc_html_e( 'Module', 'topersia-ai' ); ?></label></th>
						<td>
							<select id="module" name="module">
								<option value="summary" <?php selected( $editing['module'] ?? '', 'summary' ); ?>><?php esc_html_e( 'AI Summary', 'topersia-ai' ); ?></option>
								<option value="key_points" <?php selected( $editing['module'] ?? '', 'key_points' ); ?>><?php esc_html_e( 'Key Points (AI engine only)', 'topersia-ai' ); ?></option>
								<option value="itinerary" <?php selected( $editing['module'] ?? '', 'itinerary' ); ?>><?php esc_html_e( 'Itinerary Suggestion (AI engine only)', 'topersia-ai' ); ?></option>
								<option value="ask_ai" <?php selected( $editing['module'] ?? '', 'ask_ai' ); ?>><?php esc_html_e( 'Ask AI', 'topersia-ai' ); ?></option>
							</select>
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="language"><?php esc_html_e( 'Language (optional)', 'topersia-ai' ); ?></label></th>
						<td><input type="text" id="language" name="language" value="<?php echo esc_attr( $editing['language'] ?? '' ); ?>" placeholder="fa" /></td>
					</tr>
					<tr>
						<th scope="row"><label for="template"><?php esc_html_e( 'Template', 'topersia-ai' ); ?></label></th>
						<td>
							<textarea id="template" name="template" rows="6" class="large-text code" required><?php echo esc_textarea( $editing['template'] ?? '' ); ?></textarea>
							<p class="description">
								<?php esc_html_e( 'Available placeholders:', 'topersia-ai' ); ?>
								<code>{title} {url} {excerpt} {content} {site} {entity_type} {language} {categories} {tags}</code>
							</p>
						</td>
					</tr>
					<tr>
						<th scope="row"><?php esc_html_e( 'Default', 'topersia-ai' ); ?></th>
						<td>
							<label>
								<input type="checkbox" name="is_default" value="1" <?php checked( ! empty( $editing['is_default'] ) ); ?> />
								<?php esc_html_e( 'Use as the default template for this entity type + module', 'topersia-ai' ); ?>
							</label>
						</td>
					</tr>
				</table>

				<?php submit_button( $editing ? __( 'Update Template', 'topersia-ai' ) : __( 'Add Template', 'topersia-ai' ) ); ?>
			</form>

			<h2><?php esc_html_e( 'Existing Templates', 'topersia-ai' ); ?></h2>
			<table class="widefat striped">
				<thead>
					<tr>
						<th><?php esc_html_e( 'Slug', 'topersia-ai' ); ?></th>
						<th><?php esc_html_e( 'Entity type', 'topersia-ai' ); ?></th>
						<th><?php esc_html_e( 'Module', 'topersia-ai' ); ?></th>
						<th><?php esc_html_e( 'Language', 'topersia-ai' ); ?></th>
						<th><?php esc_html_e( 'Default', 'topersia-ai' ); ?></th>
						<th><?php esc_html_e( 'Actions', 'topersia-ai' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php if ( empty( $prompts ) ) : ?>
						<tr><td colspan="6"><?php esc_html_e( 'No custom templates yet — the built-in default template is used everywhere.', 'topersia-ai' ); ?></td></tr>
					<?php endif; ?>
					<?php foreach ( $prompts as $prompt ) : ?>
						<tr>
							<td><?php echo esc_html( $prompt['slug'] ); ?></td>
							<td><?php echo esc_html( $prompt['entity_type'] ); ?></td>
							<td><?php echo esc_html( $prompt['module'] ); ?></td>
							<td><?php echo esc_html( $prompt['language'] ? $prompt['language'] : __( 'All', 'topersia-ai' ) ); ?></td>
							<td><?php echo $prompt['is_default'] ? '✓' : ''; ?></td>
							<td>
								<a href="<?php echo esc_url( add_query_arg( array( 'page' => 'topersia-ai-prompts', 'edit' => $prompt['id'] ), admin_url( 'admin.php' ) ) ); ?>"><?php esc_html_e( 'Edit', 'topersia-ai' ); ?></a>
								|
								<a
									href="<?php echo esc_url( wp_nonce_url( add_query_arg( array( 'action' => 'topersia_ai_delete_prompt', 'id' => $prompt['id'] ), admin_url( 'admin-post.php' ) ), 'topersia_ai_delete_prompt', 'topersia_ai_delete_nonce' ) ); ?>"
									onclick="return confirm('<?php echo esc_js( __( 'Delete this prompt template?', 'topersia-ai' ) ); ?>');"
								><?php esc_html_e( 'Delete', 'topersia-ai' ); ?></a>
							</td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		</div>
		<?php
	}
}
