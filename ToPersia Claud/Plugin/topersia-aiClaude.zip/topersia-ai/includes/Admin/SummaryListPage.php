<?php
/**
 * Summaries admin screen: paginated list of generated/stale/manual
 * summaries with a one-click "Generate" action (wired to the REST API via
 * assets/js/admin.js).
 *
 * @package ToPersia\AI\Admin
 */

namespace ToPersia\AI\Admin;

use ToPersia\AI\Summary\SummaryManager;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class SummaryListPage {

	/** @var SummaryManager */
	private $summary_manager;

	public function __construct( SummaryManager $summary_manager ) {
		$this->summary_manager = $summary_manager;
	}

	/**
	 * Renders the page.
	 *
	 * @return void
	 */
	public function render() {
		if ( ! current_user_can( AdminMenu::CAPABILITY ) ) {
			return;
		}

		$repository = new \ToPersia\AI\Summary\SummaryRepository();

		$page   = isset( $_GET['paged'] ) ? max( 1, absint( $_GET['paged'] ) ) : 1; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only pagination.
		$status = isset( $_GET['status'] ) ? sanitize_key( wp_unslash( $_GET['status'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended

		$result   = $repository->paginate( array( 'page' => $page, 'per_page' => 20, 'status' => $status ) );
		$items    = $result['items'];
		$total    = $result['total'];
		$statuses = array( '' => __( 'All statuses', 'topersia-ai' ), 'current' => __( 'Current', 'topersia-ai' ), 'stale' => __( 'Stale', 'topersia-ai' ), 'manual' => __( 'Manual', 'topersia-ai' ), 'failed' => __( 'Failed', 'topersia-ai' ), 'generating' => __( 'Generating', 'topersia-ai' ) );
		?>
		<div class="wrap topersia-ai-admin">
			<h1><?php esc_html_e( 'ToPersia AI — Summaries', 'topersia-ai' ); ?></h1>

			<form method="get">
				<input type="hidden" name="page" value="topersia-ai-summaries" />
				<select name="status" onchange="this.form.submit()">
					<?php foreach ( $statuses as $value => $label ) : ?>
						<option value="<?php echo esc_attr( $value ); ?>" <?php selected( $status, $value ); ?>><?php echo esc_html( $label ); ?></option>
					<?php endforeach; ?>
				</select>
			</form>

			<table class="widefat striped" style="margin-top:12px;">
				<thead>
					<tr>
						<th><?php esc_html_e( 'Post', 'topersia-ai' ); ?></th>
						<th><?php esc_html_e( 'Language', 'topersia-ai' ); ?></th>
						<th><?php esc_html_e( 'Status', 'topersia-ai' ); ?></th>
						<th><?php esc_html_e( 'Source', 'topersia-ai' ); ?></th>
						<th><?php esc_html_e( 'Updated', 'topersia-ai' ); ?></th>
						<th><?php esc_html_e( 'Actions', 'topersia-ai' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php if ( empty( $items ) ) : ?>
						<tr><td colspan="6"><?php esc_html_e( 'No summaries yet.', 'topersia-ai' ); ?></td></tr>
					<?php endif; ?>
					<?php foreach ( $items as $item ) : ?>
						<?php $title = get_the_title( $item['post_id'] ); ?>
						<tr data-post-id="<?php echo esc_attr( $item['post_id'] ); ?>" data-language="<?php echo esc_attr( $item['language'] ); ?>">
							<td>
								<a href="<?php echo esc_url( get_edit_post_link( $item['post_id'] ) ); ?>"><?php echo esc_html( $title ? $title : '#' . (int) $item['post_id'] ); ?></a>
							</td>
							<td><?php echo esc_html( $item['language'] ? $item['language'] : '—' ); ?></td>
							<td><span class="topersia-ai-status topersia-ai-status--<?php echo esc_attr( $item['status'] ); ?>"><?php echo esc_html( $item['status'] ); ?></span></td>
							<td><?php echo esc_html( $item['source'] ); ?></td>
							<td><?php echo esc_html( $item['updated_at'] ); ?></td>
							<td>
								<button type="button" class="button topersia-ai-generate-btn"><?php esc_html_e( 'Regenerate', 'topersia-ai' ); ?></button>
							</td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>

			<?php
			$total_pages = (int) ceil( $total / 20 );
			if ( $total_pages > 1 ) :
				?>
				<div class="tablenav"><div class="tablenav-pages">
					<?php
					echo wp_kses_post(
						paginate_links(
							array(
								'base'      => add_query_arg( 'paged', '%#%' ),
								'format'    => '',
								'current'   => $page,
								'total'     => $total_pages,
							)
						)
					);
					?>
				</div></div>
			<?php endif; ?>
		</div>
		<?php
	}
}
