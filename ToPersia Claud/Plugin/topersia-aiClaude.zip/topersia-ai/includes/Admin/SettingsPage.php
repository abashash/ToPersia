<?php
/**
 * Settings screen: Ask AI, Summary, styling, and AI provider (API key)
 * configuration. Uses the WordPress Settings API exclusively (nonces,
 * sanitize callbacks, capability checks) - no custom form handling.
 *
 * @package ToPersia\AI\Admin
 */

namespace ToPersia\AI\Admin;

use ToPersia\AI\Providers\ProviderRegistry;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class SettingsPage {

	const OPTION_GROUP = 'topersia_ai_settings_group';
	const OPTION_NAME  = 'topersia_ai_settings';

	public function __construct() {
		add_action( 'admin_init', array( $this, 'register_settings' ) );
	}

	/**
	 * Registers the option and its sanitize callback.
	 *
	 * @return void
	 */
	public function register_settings() {
		register_setting(
			self::OPTION_GROUP,
			self::OPTION_NAME,
			array(
				'type'              => 'array',
				'sanitize_callback' => array( $this, 'sanitize' ),
				'default'           => array(),
			)
		);
	}

	/**
	 * Sanitizes and validates the entire settings array on save.
	 *
	 * @param array $input Raw POSTed values.
	 * @return array
	 */
	public function sanitize( $input ) {
		$input = is_array( $input ) ? $input : array();
		$clean = array();

		$clean['ask_ai_enabled']        = ! empty( $input['ask_ai_enabled'] );
		$clean['ask_ai_label']          = isset( $input['ask_ai_label'] ) ? sanitize_text_field( $input['ask_ai_label'] ) : '';
		$clean['ask_ai_providers']      = isset( $input['ask_ai_providers'] ) ? array_map( 'sanitize_key', (array) $input['ask_ai_providers'] ) : array();
		$clean['ask_ai_placement']      = isset( $input['ask_ai_placement'] ) && in_array( $input['ask_ai_placement'], array( 'after_content', 'manual' ), true )
			? $input['ask_ai_placement']
			: 'after_content';

		$clean['summary_enabled']       = ! empty( $input['summary_enabled'] );
		$clean['summary_engine']        = isset( $input['summary_engine'] ) && 'ai' === $input['summary_engine'] ? 'ai' : 'internal';
		$clean['summary_auto_generate'] = ! empty( $input['summary_auto_generate'] );
		$clean['summary_post_types']    = isset( $input['summary_post_types'] ) ? array_map( 'sanitize_key', (array) $input['summary_post_types'] ) : array();

		$clean['cache_ttl']         = isset( $input['cache_ttl'] ) ? max( 0, (int) $input['cache_ttl'] ) : DAY_IN_SECONDS;
		$clean['analytics_enabled'] = ! empty( $input['analytics_enabled'] );
		$clean['remove_data_on_uninstall'] = ! empty( $input['remove_data_on_uninstall'] );

		$clean['icon_style']    = isset( $input['icon_style'] ) && in_array( $input['icon_style'], array( 'brand', 'mono' ), true ) ? $input['icon_style'] : 'brand';
		$clean['button_style']  = isset( $input['button_style'] ) && in_array( $input['button_style'], array( 'outlined', 'filled' ), true ) ? $input['button_style'] : 'outlined';
		$clean['accent_color']  = isset( $input['accent_color'] ) ? sanitize_hex_color( $input['accent_color'] ) : '#2563eb';
		$clean['border_radius'] = isset( $input['border_radius'] ) ? max( 0, (int) $input['border_radius'] ) : 8;

		$clean['openai_api_key'] = isset( $input['openai_api_key'] ) ? sanitize_text_field( $input['openai_api_key'] ) : '';
		$clean['openai_model']   = isset( $input['openai_model'] ) ? sanitize_text_field( $input['openai_model'] ) : 'gpt-4o-mini';

		\ToPersia\AI\Cache\CacheManager::flush_all();

		return $clean;
	}

	/**
	 * Renders the settings page.
	 *
	 * @return void
	 */
	public function render() {
		if ( ! current_user_can( AdminMenu::CAPABILITY ) ) {
			return;
		}

		$settings   = wp_parse_args( get_option( self::OPTION_NAME, array() ), $this->defaults() );
		$providers  = ( new ProviderRegistry() )->all();
		$post_types = get_post_types( array( 'public' => true ), 'objects' );
		?>
		<div class="wrap topersia-ai-admin">
			<h1><?php esc_html_e( 'ToPersia AI — Settings', 'topersia-ai' ); ?></h1>

			<form method="post" action="options.php">
				<?php settings_fields( self::OPTION_GROUP ); ?>

				<h2><?php esc_html_e( 'Ask AI', 'topersia-ai' ); ?></h2>
				<table class="form-table" role="presentation">
					<tr>
						<th scope="row"><?php esc_html_e( 'Enable Ask AI', 'topersia-ai' ); ?></th>
						<td>
							<label>
								<input type="checkbox" name="<?php echo esc_attr( self::OPTION_NAME ); ?>[ask_ai_enabled]" value="1" <?php checked( ! empty( $settings['ask_ai_enabled'] ) ); ?> />
								<?php esc_html_e( 'Show Ask AI buttons on the site', 'topersia-ai' ); ?>
							</label>
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="ask_ai_label"><?php esc_html_e( 'Button group label', 'topersia-ai' ); ?></label></th>
						<td>
							<input type="text" class="regular-text" id="ask_ai_label" name="<?php echo esc_attr( self::OPTION_NAME ); ?>[ask_ai_label]" value="<?php echo esc_attr( $settings['ask_ai_label'] ); ?>" />
						</td>
					</tr>
					<tr>
						<th scope="row"><?php esc_html_e( 'Enabled providers', 'topersia-ai' ); ?></th>
						<td>
							<?php foreach ( $providers as $provider ) : ?>
								<label style="display:inline-block;margin-inline-end:16px;">
									<input type="checkbox" name="<?php echo esc_attr( self::OPTION_NAME ); ?>[ask_ai_providers][]" value="<?php echo esc_attr( $provider->get_id() ); ?>" <?php checked( in_array( $provider->get_id(), (array) $settings['ask_ai_providers'], true ) ); ?> />
									<?php echo esc_html( $provider->get_name() ); ?>
								</label>
							<?php endforeach; ?>
						</td>
					</tr>
					<tr>
						<th scope="row"><?php esc_html_e( 'Placement', 'topersia-ai' ); ?></th>
						<td>
							<select name="<?php echo esc_attr( self::OPTION_NAME ); ?>[ask_ai_placement]">
								<option value="after_content" <?php selected( $settings['ask_ai_placement'], 'after_content' ); ?>><?php esc_html_e( 'Automatically after content', 'topersia-ai' ); ?></option>
								<option value="manual" <?php selected( $settings['ask_ai_placement'], 'manual' ); ?>><?php esc_html_e( 'Manual only (shortcode / block / Elementor)', 'topersia-ai' ); ?></option>
							</select>
						</td>
					</tr>
				</table>

				<h2><?php esc_html_e( 'AI Summary', 'topersia-ai' ); ?></h2>
				<table class="form-table" role="presentation">
					<tr>
						<th scope="row"><?php esc_html_e( 'Summary engine', 'topersia-ai' ); ?></th>
						<td>
							<select name="<?php echo esc_attr( self::OPTION_NAME ); ?>[summary_engine]">
								<option value="internal" <?php selected( $settings['summary_engine'], 'internal' ); ?>><?php esc_html_e( 'Internal (offline, no API key, free)', 'topersia-ai' ); ?></option>
								<option value="ai" <?php selected( $settings['summary_engine'], 'ai' ); ?>><?php esc_html_e( 'AI provider (requires API key below)', 'topersia-ai' ); ?></option>
							</select>
							<p class="description"><?php esc_html_e( 'The internal engine extracts and reorders the most relevant existing sentences from your content — no external request is ever made. It is the default so summaries work immediately with zero setup.', 'topersia-ai' ); ?></p>
						</td>
					</tr>
					<tr>
						<th scope="row"><?php esc_html_e( 'Enable AI Summary', 'topersia-ai' ); ?></th>
						<td>
							<label>
								<input type="checkbox" name="<?php echo esc_attr( self::OPTION_NAME ); ?>[summary_enabled]" value="1" <?php checked( ! empty( $settings['summary_enabled'] ) ); ?> />
								<?php esc_html_e( 'Show a Quick Summary block on the site', 'topersia-ai' ); ?>
							</label>
						</td>
					</tr>
					<tr>
						<th scope="row"><?php esc_html_e( 'Auto-regenerate on edit', 'topersia-ai' ); ?></th>
						<td>
							<label>
								<input type="checkbox" name="<?php echo esc_attr( self::OPTION_NAME ); ?>[summary_auto_generate]" value="1" <?php checked( ! empty( $settings['summary_auto_generate'] ) ); ?> />
								<?php esc_html_e( 'Automatically regenerate summaries when post content changes (uses the configured AI provider). When off, summaries are marked "stale" for manual review instead.', 'topersia-ai' ); ?>
							</label>
						</td>
					</tr>
					<tr>
						<th scope="row"><?php esc_html_e( 'Enabled post types', 'topersia-ai' ); ?></th>
						<td>
							<?php foreach ( $post_types as $post_type ) : ?>
								<label style="display:inline-block;margin-inline-end:16px;">
									<input type="checkbox" name="<?php echo esc_attr( self::OPTION_NAME ); ?>[summary_post_types][]" value="<?php echo esc_attr( $post_type->name ); ?>" <?php checked( in_array( $post_type->name, (array) $settings['summary_post_types'], true ) ); ?> />
									<?php echo esc_html( $post_type->label ); ?>
								</label>
							<?php endforeach; ?>
							<p class="description"><?php esc_html_e( 'Select every ToPersia entity post type you want summaries for (attractions, hotels, cities, ...).', 'topersia-ai' ); ?></p>
						</td>
					</tr>
				</table>

				<h2><?php esc_html_e( 'AI Provider (Summary generation)', 'topersia-ai' ); ?></h2>
				<table class="form-table" role="presentation">
					<tr>
						<th scope="row"><label for="openai_api_key"><?php esc_html_e( 'OpenAI API key', 'topersia-ai' ); ?></label></th>
						<td>
							<input type="password" autocomplete="off" class="regular-text" id="openai_api_key" name="<?php echo esc_attr( self::OPTION_NAME ); ?>[openai_api_key]" value="<?php echo esc_attr( $settings['openai_api_key'] ); ?>" />
							<p class="description"><?php esc_html_e( 'Used only server-side to generate summaries. Never exposed to the frontend.', 'topersia-ai' ); ?></p>
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="openai_model"><?php esc_html_e( 'Model', 'topersia-ai' ); ?></label></th>
						<td>
							<input type="text" class="regular-text" id="openai_model" name="<?php echo esc_attr( self::OPTION_NAME ); ?>[openai_model]" value="<?php echo esc_attr( $settings['openai_model'] ); ?>" />
						</td>
					</tr>
				</table>

				<h2><?php esc_html_e( 'Appearance', 'topersia-ai' ); ?></h2>
				<table class="form-table" role="presentation">
					<tr>
						<th scope="row"><?php esc_html_e( 'Icon style', 'topersia-ai' ); ?></th>
						<td>
							<select name="<?php echo esc_attr( self::OPTION_NAME ); ?>[icon_style]">
								<option value="brand" <?php selected( $settings['icon_style'], 'brand' ); ?>><?php esc_html_e( 'Brand colours', 'topersia-ai' ); ?></option>
								<option value="mono" <?php selected( $settings['icon_style'], 'mono' ); ?>><?php esc_html_e( 'Monochrome', 'topersia-ai' ); ?></option>
							</select>
						</td>
					</tr>
					<tr>
						<th scope="row"><?php esc_html_e( 'Button style', 'topersia-ai' ); ?></th>
						<td>
							<select name="<?php echo esc_attr( self::OPTION_NAME ); ?>[button_style]">
								<option value="outlined" <?php selected( $settings['button_style'], 'outlined' ); ?>><?php esc_html_e( 'Outlined', 'topersia-ai' ); ?></option>
								<option value="filled" <?php selected( $settings['button_style'], 'filled' ); ?>><?php esc_html_e( 'Filled', 'topersia-ai' ); ?></option>
							</select>
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="accent_color"><?php esc_html_e( 'Accent colour', 'topersia-ai' ); ?></label></th>
						<td><input type="text" id="accent_color" class="topersia-ai-color-field" name="<?php echo esc_attr( self::OPTION_NAME ); ?>[accent_color]" value="<?php echo esc_attr( $settings['accent_color'] ); ?>" /></td>
					</tr>
					<tr>
						<th scope="row"><label for="border_radius"><?php esc_html_e( 'Border radius (px)', 'topersia-ai' ); ?></label></th>
						<td><input type="number" min="0" max="40" id="border_radius" name="<?php echo esc_attr( self::OPTION_NAME ); ?>[border_radius]" value="<?php echo esc_attr( $settings['border_radius'] ); ?>" /></td>
					</tr>
				</table>

				<h2><?php esc_html_e( 'Privacy & Performance', 'topersia-ai' ); ?></h2>
				<table class="form-table" role="presentation">
					<tr>
						<th scope="row"><?php esc_html_e( 'Analytics', 'topersia-ai' ); ?></th>
						<td>
							<label>
								<input type="checkbox" name="<?php echo esc_attr( self::OPTION_NAME ); ?>[analytics_enabled]" value="1" <?php checked( ! empty( $settings['analytics_enabled'] ) ); ?> />
								<?php esc_html_e( 'Track anonymous, aggregate click counts (no IP address, user agent, or personal data is ever stored)', 'topersia-ai' ); ?>
							</label>
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="cache_ttl"><?php esc_html_e( 'Cache lifetime (seconds)', 'topersia-ai' ); ?></label></th>
						<td><input type="number" min="0" id="cache_ttl" name="<?php echo esc_attr( self::OPTION_NAME ); ?>[cache_ttl]" value="<?php echo esc_attr( $settings['cache_ttl'] ); ?>" /></td>
					</tr>
					<tr>
						<th scope="row"><?php esc_html_e( 'On uninstall', 'topersia-ai' ); ?></th>
						<td>
							<label>
								<input type="checkbox" name="<?php echo esc_attr( self::OPTION_NAME ); ?>[remove_data_on_uninstall]" value="1" <?php checked( ! empty( $settings['remove_data_on_uninstall'] ) ); ?> />
								<?php esc_html_e( 'Permanently delete all ToPersia AI data (summaries, prompt templates, analytics, settings) when the plugin is deleted from Plugins → Installed Plugins', 'topersia-ai' ); ?>
							</label>
							<p class="description"><?php esc_html_e( 'Left unchecked, deleting the plugin keeps all data intact in case you reinstall it later.', 'topersia-ai' ); ?></p>
						</td>
					</tr>
				</table>

				<?php submit_button(); ?>
			</form>
		</div>
		<?php
	}

	/**
	 * Default values mirrored from Core\Activator so the page renders
	 * sensibly even before activation defaults have been persisted.
	 *
	 * @return array
	 */
	private function defaults() {
		return array(
			'ask_ai_enabled'        => true,
			'ask_ai_label'          => __( 'Ask AI about this page', 'topersia-ai' ),
			'ask_ai_providers'      => array( 'chatgpt', 'claude', 'perplexity', 'gemini', 'grok', 'copilot' ),
			'ask_ai_placement'      => 'after_content',
			'summary_enabled'       => true,
			'summary_engine'        => 'internal',
			'summary_auto_generate' => false,
			'summary_post_types'    => array( 'post' ),
			'cache_ttl'             => DAY_IN_SECONDS,
			'analytics_enabled'     => true,
			'remove_data_on_uninstall' => false,
			'icon_style'            => 'brand',
			'button_style'          => 'outlined',
			'accent_color'          => '#2563eb',
			'border_radius'         => 8,
			'openai_api_key'        => '',
			'openai_model'          => 'gpt-4o-mini',
		);
	}
}
