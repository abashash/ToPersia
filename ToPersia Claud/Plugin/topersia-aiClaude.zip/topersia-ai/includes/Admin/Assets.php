<?php
/**
 * Enqueues admin CSS/JS only on ToPersia AI's own admin screens.
 *
 * @package ToPersia\AI\Admin
 */

namespace ToPersia\AI\Admin;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Assets {

	public function __construct() {
		add_action( 'admin_enqueue_scripts', array( $this, 'maybe_enqueue' ) );
	}

	/**
	 * @param string $hook Current admin page hook suffix.
	 * @return void
	 */
	public function maybe_enqueue( $hook ) {
		if ( strpos( (string) $hook, 'topersia-ai' ) === false ) {
			return;
		}

		wp_enqueue_style( 'topersia-ai-admin', TOPERSIA_AI_URL . 'assets/css/admin.css', array(), TOPERSIA_AI_VERSION );
		wp_enqueue_script( 'topersia-ai-admin', TOPERSIA_AI_URL . 'assets/js/admin.js', array( 'wp-api-fetch' ), TOPERSIA_AI_VERSION, true );

		wp_localize_script(
			'topersia-ai-admin',
			'topersiaAiAdmin',
			array(
				'restUrl' => esc_url_raw( rest_url( 'topersia-ai/v1/' ) ),
				'nonce'   => wp_create_nonce( 'wp_rest' ),
				'i18n'    => array(
					'generating' => __( 'Generating…', 'topersia-ai' ),
					'saved'      => __( 'Saved.', 'topersia-ai' ),
					'error'      => __( 'Something went wrong.', 'topersia-ai' ),
					'confirmDelete' => __( 'Delete this prompt template?', 'topersia-ai' ),
				),
			)
		);
	}
}
