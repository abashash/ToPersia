<?php
/**
 * Registers the ToPersia AI top-level admin menu and its subpages.
 *
 * @package ToPersia\AI\Admin
 */

namespace ToPersia\AI\Admin;

use ToPersia\AI\Summary\SummaryManager;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AdminMenu {

	const CAPABILITY = 'manage_options';

	/** @var SummaryManager */
	private $summary_manager;

	/** @var SettingsPage */
	private $settings_page;

	/** @var PromptManagerPage */
	private $prompt_page;

	/** @var SummaryListPage */
	private $summary_page;

	public function __construct( SummaryManager $summary_manager ) {
		$this->summary_manager = $summary_manager;
		$this->settings_page   = new SettingsPage();
		$this->prompt_page     = new PromptManagerPage();
		$this->summary_page    = new SummaryListPage( $summary_manager );

		add_action( 'admin_menu', array( $this, 'register_menu' ) );
	}

	/**
	 * Registers the admin menu tree.
	 *
	 * @return void
	 */
	public function register_menu() {
		add_menu_page(
			__( 'ToPersia AI', 'topersia-ai' ),
			__( 'ToPersia AI', 'topersia-ai' ),
			self::CAPABILITY,
			'topersia-ai',
			array( $this->settings_page, 'render' ),
			'dashicons-superhero-alt',
			58
		);

		add_submenu_page(
			'topersia-ai',
			__( 'Settings', 'topersia-ai' ),
			__( 'Settings', 'topersia-ai' ),
			self::CAPABILITY,
			'topersia-ai',
			array( $this->settings_page, 'render' )
		);

		add_submenu_page(
			'topersia-ai',
			__( 'Prompt Templates', 'topersia-ai' ),
			__( 'Prompt Templates', 'topersia-ai' ),
			self::CAPABILITY,
			'topersia-ai-prompts',
			array( $this->prompt_page, 'render' )
		);

		add_submenu_page(
			'topersia-ai',
			__( 'Summaries', 'topersia-ai' ),
			__( 'Summaries', 'topersia-ai' ),
			self::CAPABILITY,
			'topersia-ai-summaries',
			array( $this->summary_page, 'render' )
		);
	}
}
