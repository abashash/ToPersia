<?php
/**
 * Renders prompt templates against a context array.
 *
 * Templates use `{placeholder}` tokens. Unknown placeholders are left
 * untouched rather than silently deleted, which makes template authoring
 * mistakes visible instead of producing a broken prompt.
 *
 * @package ToPersia\AI\Prompt
 */

namespace ToPersia\AI\Prompt;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class PromptEngine {

	/**
	 * Default prompt template used when no per-entity-type override exists.
	 *
	 * @return string
	 */
	public function default_template() {
		return apply_filters(
			'topersia_ai_default_prompt_template',
			__( 'Please read the following page and give me a concise summary in the same language as the content: {title} — {url}', 'topersia-ai' )
		);
	}

	/**
	 * Renders a template string against a context array.
	 *
	 * @param string               $template Template with {placeholders}.
	 * @param array<string,mixed>  $context  Context data (see ContextBuilder).
	 * @return string
	 */
	public function render( $template, array $context ) {
		$replacements = $this->flatten_context( $context );

		/**
		 * Filters the replacement map right before it is applied to the
		 * template, so integrations can add module-specific tokens.
		 *
		 * @param array $replacements Token => value map.
		 * @param array $context      Raw context array.
		 */
		$replacements = apply_filters( 'topersia_ai_prompt_replacements', $replacements, $context );

		$search  = array();
		$replace = array();

		foreach ( $replacements as $token => $value ) {
			$search[]  = '{' . $token . '}';
			$replace[] = is_scalar( $value ) ? (string) $value : '';
		}

		$rendered = str_replace( $search, $replace, $template );

		return apply_filters( 'topersia_ai_prompt', $rendered, $template, $context );
	}

	/**
	 * Flattens the (possibly nested) context array into scalar token values
	 * suitable for string replacement.
	 *
	 * @param array<string,mixed> $context Context array.
	 * @return array<string,string>
	 */
	private function flatten_context( array $context ) {
		$flat = array(
			'title'       => isset( $context['title'] ) ? $context['title'] : '',
			'url'         => isset( $context['url'] ) ? $context['url'] : '',
			'excerpt'     => isset( $context['excerpt'] ) ? $context['excerpt'] : '',
			'content'     => isset( $context['content_text'] ) ? $this->truncate( $context['content_text'], 4000 ) : '',
			'site'        => isset( $context['site_name'] ) ? $context['site_name'] : '',
			'entity_type' => isset( $context['entity_type'] ) ? $context['entity_type'] : '',
			'post_type'   => isset( $context['post_type'] ) ? $context['post_type'] : '',
			'language'    => isset( $context['language'] ) ? $context['language'] : '',
			'categories'  => isset( $context['categories'] ) ? implode( '، ', (array) $context['categories'] ) : '',
			'tags'        => isset( $context['tags'] ) ? implode( '، ', (array) $context['tags'] ) : '',
		);

		if ( ! empty( $context['taxonomies'] ) && is_array( $context['taxonomies'] ) ) {
			foreach ( $context['taxonomies'] as $taxonomy => $terms ) {
				$flat[ 'tax_' . $taxonomy ] = implode( '، ', (array) $terms );
			}
		}

		if ( ! empty( $context['jetengine']['meta_fields'] ) && is_array( $context['jetengine']['meta_fields'] ) ) {
			foreach ( $context['jetengine']['meta_fields'] as $key => $value ) {
				$flat[ 'field_' . $key ] = is_scalar( $value ) ? (string) $value : '';
			}
		}

		return $flat;
	}

	/**
	 * Truncates text to a maximum character length on a word boundary.
	 *
	 * @param string $text      Source text.
	 * @param int    $max_chars Maximum characters.
	 * @return string
	 */
	private function truncate( $text, $max_chars ) {
		if ( function_exists( 'mb_strlen' ) ) {
			if ( mb_strlen( $text ) <= $max_chars ) {
				return $text;
			}
			return mb_substr( $text, 0, $max_chars ) . '…';
		}

		if ( strlen( $text ) <= $max_chars ) {
			return $text;
		}

		return substr( $text, 0, $max_chars ) . '…';
	}
}
