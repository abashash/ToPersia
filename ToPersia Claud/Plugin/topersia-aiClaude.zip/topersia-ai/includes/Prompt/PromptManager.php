<?php
/**
 * CRUD for stored prompt templates (per entity type / language / module).
 *
 * @package ToPersia\AI\Prompt
 */

namespace ToPersia\AI\Prompt;

use ToPersia\AI\Database\Database;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class PromptManager {

	/**
	 * Finds the best-matching stored prompt template for an entity
	 * type/module/language, falling back to the built-in default.
	 *
	 * @param string $entity_type Entity type (see ContextBuilder).
	 * @param string $module      Module slug, e.g. "summary" or "ask_ai".
	 * @param string $language    Two-letter language code.
	 * @return string Template string.
	 */
	public function get_template( $entity_type, $module, $language ) {
		global $wpdb;
		$table = Database::prompts_table();

		// 1) exact match: entity + module + language.
		$row = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT template FROM {$table} WHERE entity_type = %s AND module = %s AND language = %s ORDER BY is_default DESC LIMIT 1",
				$entity_type,
				$module,
				$language
			)
		);

		// 2) entity + module, any language.
		if ( ! $row ) {
			$row = $wpdb->get_row(
				$wpdb->prepare(
					"SELECT template FROM {$table} WHERE entity_type = %s AND module = %s AND language = '' ORDER BY is_default DESC LIMIT 1",
					$entity_type,
					$module
				)
			);
		}

		// 3) generic "other" entity + module.
		if ( ! $row ) {
			$row = $wpdb->get_row(
				$wpdb->prepare(
					"SELECT template FROM {$table} WHERE entity_type = 'other' AND module = %s ORDER BY is_default DESC LIMIT 1",
					$module
				)
			);
		}

		if ( $row && ! empty( $row->template ) ) {
			return $row->template;
		}

		return apply_filters( 'topersia_ai_fallback_template', ( new PromptEngine() )->default_template(), $entity_type, $module, $language );
	}

	/**
	 * Saves (creates or updates) a prompt template.
	 *
	 * @param array $data {
	 *     @type int    $id          Optional. Existing prompt ID to update.
	 *     @type string $slug        Machine slug.
	 *     @type string $label       Human label shown in admin.
	 *     @type string $entity_type Entity type.
	 *     @type string $module      Module slug.
	 *     @type string $template    Template body.
	 *     @type string $language    Language code, empty for "all languages".
	 *     @type bool   $is_default  Whether this is the default for the entity/module.
	 * }
	 * @return int|\WP_Error Prompt ID on success.
	 */
	public function save( array $data ) {
		global $wpdb;
		$table = Database::prompts_table();
		$now   = current_time( 'mysql' );

		$fields = array(
			'slug'        => sanitize_key( $data['slug'] ?? '' ),
			'label'       => sanitize_text_field( $data['label'] ?? '' ),
			'entity_type' => sanitize_key( $data['entity_type'] ?? 'other' ),
			'module'      => sanitize_key( $data['module'] ?? 'summary' ),
			'template'    => wp_kses_post( $data['template'] ?? '' ),
			'language'    => sanitize_text_field( $data['language'] ?? '' ),
			'is_default'  => empty( $data['is_default'] ) ? 0 : 1,
			'updated_at'  => $now,
		);

		if ( '' === $fields['slug'] || '' === $fields['template'] ) {
			return new \WP_Error( 'topersia_ai_invalid_prompt', __( 'Slug and template are required.', 'topersia-ai' ) );
		}

		if ( ! empty( $data['id'] ) ) {
			$wpdb->update( $table, $fields, array( 'id' => (int) $data['id'] ) );
			return (int) $data['id'];
		}

		$fields['created_at'] = $now;
		$wpdb->insert( $table, $fields );

		return (int) $wpdb->insert_id;
	}

	/**
	 * Deletes a prompt template by ID.
	 *
	 * @param int $id Prompt ID.
	 * @return bool
	 */
	public function delete( $id ) {
		global $wpdb;
		$table = Database::prompts_table();

		return (bool) $wpdb->delete( $table, array( 'id' => (int) $id ) );
	}

	/**
	 * Lists all stored prompt templates.
	 *
	 * @return array<int,array>
	 */
	public function all() {
		global $wpdb;
		$table = Database::prompts_table();

		$rows = $wpdb->get_results( "SELECT * FROM {$table} ORDER BY entity_type ASC, module ASC", ARRAY_A );

		return is_array( $rows ) ? $rows : array();
	}
}
