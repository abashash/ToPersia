<?php
/**
 * Database schema management. Uses dbDelta exclusively for table
 * creation/updates and prepared statements everywhere else, matching the
 * pattern already validated in topersia-user-core.
 *
 * @package ToPersia\AI\Database
 */

namespace ToPersia\AI\Database;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Database {

	/**
	 * Returns the fully-qualified summaries table name.
	 *
	 * @return string
	 */
	public static function summaries_table() {
		global $wpdb;
		return $wpdb->prefix . 'topersia_ai_summaries';
	}

	/**
	 * Returns the fully-qualified prompts table name.
	 *
	 * @return string
	 */
	public static function prompts_table() {
		global $wpdb;
		return $wpdb->prefix . 'topersia_ai_prompts';
	}

	/**
	 * Returns the fully-qualified analytics events table name.
	 *
	 * @return string
	 */
	public static function analytics_table() {
		global $wpdb;
		return $wpdb->prefix . 'topersia_ai_analytics';
	}

	/**
	 * Creates or upgrades all plugin tables via dbDelta.
	 *
	 * @return void
	 */
	public static function install() {
		global $wpdb;

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$charset_collate = $wpdb->get_charset_collate();

		$summaries = self::summaries_table();
		$prompts   = self::prompts_table();
		$analytics = self::analytics_table();

		$sql_summaries = "CREATE TABLE {$summaries} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			post_id BIGINT UNSIGNED NOT NULL,
			language VARCHAR(10) NOT NULL DEFAULT '',
			content LONGTEXT NULL,
			key_points LONGTEXT NULL,
			itinerary LONGTEXT NULL,
			status VARCHAR(20) NOT NULL DEFAULT 'stale',
			source VARCHAR(20) NOT NULL DEFAULT 'ai',
			provider VARCHAR(50) NULL,
			prompt_hash VARCHAR(64) NULL,
			content_hash VARCHAR(64) NULL,
			generated_at DATETIME NULL,
			updated_at DATETIME NOT NULL,
			created_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY post_language (post_id, language),
			KEY status (status)
		) {$charset_collate};";

		$sql_prompts = "CREATE TABLE {$prompts} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			slug VARCHAR(100) NOT NULL,
			label VARCHAR(190) NOT NULL,
			entity_type VARCHAR(50) NOT NULL DEFAULT 'other',
			module VARCHAR(50) NOT NULL DEFAULT 'summary',
			template LONGTEXT NOT NULL,
			language VARCHAR(10) NOT NULL DEFAULT '',
			is_default TINYINT(1) NOT NULL DEFAULT 0,
			created_at DATETIME NOT NULL,
			updated_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY slug_entity_lang (slug, entity_type, language)
		) {$charset_collate};";

		$sql_analytics = "CREATE TABLE {$analytics} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			post_id BIGINT UNSIGNED NOT NULL,
			event_type VARCHAR(30) NOT NULL,
			provider VARCHAR(50) NULL,
			module VARCHAR(50) NOT NULL DEFAULT 'ask_ai',
			created_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			KEY post_event (post_id, event_type),
			KEY provider (provider)
		) {$charset_collate};";

		dbDelta( $sql_summaries );
		dbDelta( $sql_prompts );
		dbDelta( $sql_analytics );
	}
}
