<?php
/**
 * Registers [topersia_ai_ask] and [topersia_ai_summary] shortcodes so the
 * modules can be placed anywhere: Elementor Shortcode widget, classic
 * editor, widget areas, etc.
 *
 * @package ToPersia\AI\Shortcode
 */

namespace ToPersia\AI\Shortcode;

use ToPersia\AI\Frontend\FrontendRenderer;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Shortcode {

	/** @var FrontendRenderer */
	private $renderer;

	public function __construct( FrontendRenderer $renderer ) {
		$this->renderer = $renderer;

		add_shortcode( 'topersia_ai_ask', array( $this, 'render_ask' ) );
		add_shortcode( 'topersia_ai_summary', array( $this, 'render_summary' ) );
		add_shortcode( 'topersia_ai_brief', array( $this, 'render_brief' ) );
	}

	/**
	 * [topersia_ai_brief post_id="123"]
	 *
	 * @param array $atts Shortcode attributes.
	 * @return string
	 */
	public function render_brief( $atts ) {
		$atts    = shortcode_atts( array( 'post_id' => get_the_ID() ), $atts, 'topersia_ai_brief' );
		$post_id = (int) $atts['post_id'];

		if ( ! $post_id ) {
			return '';
		}

		return $this->renderer->render_brief( $post_id );
	}

	/**
	 * [topersia_ai_ask post_id="123"]
	 *
	 * @param array $atts Shortcode attributes.
	 * @return string
	 */
	public function render_ask( $atts ) {
		$atts    = shortcode_atts( array( 'post_id' => get_the_ID() ), $atts, 'topersia_ai_ask' );
		$post_id = (int) $atts['post_id'];

		if ( ! $post_id ) {
			return '';
		}

		return $this->renderer->render_ask_ai( $post_id );
	}

	/**
	 * [topersia_ai_summary post_id="123"]
	 *
	 * @param array $atts Shortcode attributes.
	 * @return string
	 */
	public function render_summary( $atts ) {
		$atts    = shortcode_atts( array( 'post_id' => get_the_ID() ), $atts, 'topersia_ai_summary' );
		$post_id = (int) $atts['post_id'];

		if ( ! $post_id ) {
			return '';
		}

		return $this->renderer->render_summary( $post_id );
	}
}
