<?php
/**
 * Conditionally enqueues frontend CSS/JS - only on singular pages where
 * ToPersia AI actually renders output, following the same
 * sitewide-to-conditional pattern already used in topersia-user-core.
 *
 * @package ToPersia\AI\Frontend
 */

namespace ToPersia\AI\Frontend;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Assets {

	public function __construct() {
		add_action( 'wp_enqueue_scripts', array( $this, 'maybe_enqueue' ) );
	}

	/**
	 * Enqueues assets only when needed: singular pages of an enabled post
	 * type, or any page containing the [topersia_ai_ask] / [topersia_ai_summary]
	 * shortcodes.
	 *
	 * @return void
	 */
	public function maybe_enqueue() {
		global $post;

		$should_load = false;

		if ( is_singular() && $post instanceof \WP_Post ) {
			$should_load = true;
		}

		if ( ! $should_load && $post instanceof \WP_Post && has_shortcode( $post->post_content, 'topersia_ai_ask' ) ) {
			$should_load = true;
		}

		if ( ! $should_load && $post instanceof \WP_Post && has_shortcode( $post->post_content, 'topersia_ai_summary' ) ) {
			$should_load = true;
		}

		if ( ! $should_load && $post instanceof \WP_Post && has_shortcode( $post->post_content, 'topersia_ai_brief' ) ) {
			$should_load = true;
		}

		$should_load = apply_filters( 'topersia_ai_should_enqueue_frontend_assets', $should_load );

		if ( ! $should_load ) {
			return;
		}

		wp_enqueue_style(
			'topersia-ai-frontend',
			TOPERSIA_AI_URL . 'assets/css/frontend.css',
			array(),
			TOPERSIA_AI_VERSION
		);

		wp_add_inline_style( 'topersia-ai-frontend', $this->build_inline_css() );

		wp_enqueue_script(
			'topersia-ai-frontend',
			TOPERSIA_AI_URL . 'assets/js/frontend.js',
			array(),
			TOPERSIA_AI_VERSION,
			true
		);

		wp_localize_script(
			'topersia-ai-frontend',
			'topersiaAiFrontend',
			array(
				'restUrl' => esc_url_raw( rest_url( 'topersia-ai/v1/' ) ),
				'nonce'   => wp_create_nonce( 'wp_rest' ),
				'i18n'    => array(
					'copied' => __( 'Prompt copied — paste it into the chat.', 'topersia-ai' ),
				),
			)
		);
	}

	/**
	 * Builds a small inline stylesheet reflecting the admin-configured
	 * accent colour and border radius, so site owners can restyle the
	 * component without editing CSS files directly.
	 *
	 * @return string
	 */
	private function build_inline_css() {
		$settings = get_option( 'topersia_ai_settings', array() );
		$accent   = ! empty( $settings['accent_color'] ) ? sanitize_hex_color( $settings['accent_color'] ) : '#2563eb';
		$radius   = isset( $settings['border_radius'] ) ? max( 0, (int) $settings['border_radius'] ) : 8;

		return sprintf(
			':root{--topersia-ai-accent:%s;--topersia-ai-radius:%dpx;}',
			esc_html( $accent ? $accent : '#2563eb' ),
			$radius
		);
	}
}
