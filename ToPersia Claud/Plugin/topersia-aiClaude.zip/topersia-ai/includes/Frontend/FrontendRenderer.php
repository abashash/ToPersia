<?php
/**
 * Delivers ToPersia AI's frontend output: auto-placement after post
 * content, plus reusable render methods for the shortcode, Elementor
 * widget, and Gutenberg block to call directly.
 *
 * Per the platform's full-page-cache constraint, this class renders plain
 * server HTML with no per-user branching - any personalisation happens
 * client-side, consistent with topersia-render's day/evening/night model.
 *
 * @package ToPersia\AI\Frontend
 */

namespace ToPersia\AI\Frontend;

use ToPersia\AI\AskAI\AskAIRenderer;
use ToPersia\AI\Brief\BriefRenderer;
use ToPersia\AI\Summary\SummaryManager;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class FrontendRenderer {

	/** @var AskAIRenderer */
	private $ask_ai;

	/** @var SummaryManager */
	private $summary_manager;

	/** @var BriefRenderer */
	private $brief;

	public function __construct( AskAIRenderer $ask_ai, SummaryManager $summary_manager, BriefRenderer $brief ) {
		$this->ask_ai          = $ask_ai;
		$this->summary_manager = $summary_manager;
		$this->brief           = $brief;

		add_filter( 'the_content', array( $this, 'maybe_append_to_content' ), 20 );
	}

	/**
	 * Appends the AI Travel Brief card after single post content when the
	 * admin-configured placement is "after_content".
	 *
	 * @param string $content Post content.
	 * @return string
	 */
	public function maybe_append_to_content( $content ) {
		if ( ! is_singular() || ! in_the_loop() || ! is_main_query() ) {
			return $content;
		}

		$settings  = get_option( 'topersia_ai_settings', array() );
		$placement = isset( $settings['ask_ai_placement'] ) ? $settings['ask_ai_placement'] : 'after_content';

		if ( 'after_content' !== $placement ) {
			return $content;
		}

		$post_id = get_the_ID();

		return $content . $this->render_brief( $post_id );
	}

	/**
	 * Renders the unified AI Travel Brief card (summary + key points +
	 * itinerary + export, with engine pills) for a post.
	 *
	 * @param int $post_id Post ID.
	 * @return string
	 */
	public function render_brief( $post_id ) {
		return $this->brief->render( $post_id );
	}

	/**
	 * Renders the Ask AI block for a post.
	 *
	 * @param int $post_id Post ID.
	 * @return string
	 */
	public function render_ask_ai( $post_id ) {
		return $this->ask_ai->render( $post_id );
	}

	/**
	 * Renders the summary block for a post, when one exists and the module
	 * is enabled for the post's type. Summary content is stored
	 * server-side per language, so this remains fully cache-safe.
	 *
	 * @param int $post_id Post ID.
	 * @return string
	 */
	public function render_summary( $post_id ) {
		$post_type = get_post_type( $post_id );

		if ( ! $post_type || ! $this->summary_manager->is_enabled_for( $post_type ) ) {
			return '';
		}

		$summary = $this->summary_manager->get_summary( $post_id );

		if ( ! $summary || empty( $summary['content'] ) || 'failed' === $summary['status'] ) {
			return '';
		}

		ob_start();
		?>
		<div class="topersia-ai-summary" data-post-id="<?php echo esc_attr( $post_id ); ?>" data-status="<?php echo esc_attr( $summary['status'] ); ?>">
			<h3 class="topersia-ai-summary__title"><?php esc_html_e( 'Quick Summary', 'topersia-ai' ); ?></h3>
			<div class="topersia-ai-summary__body"><?php echo wp_kses_post( $summary['content'] ); ?></div>
		</div>
		<?php
		return (string) ob_get_clean();
	}
}
