<?php
/**
 * Renders the unified "AI Travel Brief" card: breadcrumb, tabbed content
 * (Summary / Key Points / Itinerary Suggestion / JSON Export), a row of
 * engine pills (each AI provider, plus the built-in internal engine), and
 * a footer noting which engine actually produced the visible content.
 *
 * This is the primary, richer successor to the standalone Ask AI /
 * Summary blocks (`AskAIRenderer`, `FrontendRenderer::render_summary()`),
 * which remain available individually for the shortcode/block/Elementor
 * "granular" placement use case.
 *
 * @package ToPersia\AI\Brief
 */

namespace ToPersia\AI\Brief;

use ToPersia\AI\Context\ContextBuilder;
use ToPersia\AI\Prompt\PromptEngine;
use ToPersia\AI\Prompt\PromptManager;
use ToPersia\AI\Providers\ProviderRegistry;
use ToPersia\AI\Summary\SummaryManager;
use ToPersia\AI\Integrations\WPML\WPMLIntegration;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class BriefRenderer {

	/** @var ContextBuilder */
	private $context_builder;

	/** @var PromptEngine */
	private $prompt_engine;

	/** @var PromptManager */
	private $prompt_manager;

	/** @var ProviderRegistry */
	private $providers;

	/** @var SummaryManager */
	private $summary_manager;

	public function __construct(
		ContextBuilder $context_builder,
		PromptEngine $prompt_engine,
		ProviderRegistry $providers,
		SummaryManager $summary_manager
	) {
		$this->context_builder = $context_builder;
		$this->prompt_engine   = $prompt_engine;
		$this->prompt_manager  = new PromptManager();
		$this->providers       = $providers;
		$this->summary_manager = $summary_manager;
	}

	/**
	 * Renders the full AI Travel Brief card for a post.
	 *
	 * @param int $post_id Post ID.
	 * @return string HTML.
	 */
	public function render( $post_id ) {
		$settings = get_option( 'topersia_ai_settings', array() );

		if ( empty( $settings['summary_enabled'] ) ) {
			return '';
		}

		$post_type = get_post_type( $post_id );

		if ( ! $post_type || ! $this->summary_manager->is_enabled_for( $post_type ) ) {
			return '';
		}

		$context = $this->context_builder->build( $post_id );

		if ( empty( $context ) ) {
			return '';
		}

		$summary       = $this->summary_manager->get_summary( $post_id );
		$has_generated = $summary && ! empty( $summary['content'] );

		$summary_text  = $has_generated ? $summary['content'] : $context['excerpt'];
		$key_points    = $has_generated ? $this->summary_manager->decode_key_points( $summary ) : array();
		$itinerary     = $has_generated && ! empty( $summary['itinerary'] ) ? $summary['itinerary'] : '';
		$active_engine = $has_generated ? $summary['provider'] : 'internal';
		$is_rtl        = WPMLIntegration::is_rtl_language( $context['language'] );

		$export_json = wp_json_encode(
			array(
				'title'       => $context['title'],
				'url'         => $context['url'],
				'entity_type' => $context['entity_type'],
				'breadcrumb'  => $context['breadcrumb'],
				'summary'     => $summary_text,
				'key_points'  => $key_points,
				'itinerary'   => $itinerary,
			),
			JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT
		);

		ob_start();
		?>
		<div class="topersia-ai-brief" dir="<?php echo esc_attr( $is_rtl ? 'rtl' : 'ltr' ); ?>" data-post-id="<?php echo esc_attr( $post_id ); ?>">
			<div class="topersia-ai-brief__eyebrow">
				<span class="topersia-ai-brief__eyebrow-badge"><?php esc_html_e( 'AI TRAVEL BRIEF', 'topersia-ai' ); ?></span>
				<span class="topersia-ai-brief__eyebrow-text"><?php esc_html_e( 'این مقصد را در یک نگاه بفهمید', 'topersia-ai' ); ?></span>
			</div>

			<h2 class="topersia-ai-brief__title"><?php esc_html_e( 'این مقصد را در یک نگاه بفهمید', 'topersia-ai' ); ?></h2>

			<?php if ( ! empty( $context['breadcrumb'] ) ) : ?>
				<p class="topersia-ai-brief__breadcrumb">
					<?php echo esc_html( implode( ' ← ', array_reverse( $context['breadcrumb'] ) ) ); ?>
					<?php // Displayed reversed above to read as e.g. "Province ← City ← Attraction" in RTL flow; LTR sites can flip via the topersia_ai_breadcrumb filter order instead. ?>
				</p>
			<?php endif; ?>

			<div class="topersia-ai-brief__tabs" role="tablist">
				<button type="button" class="topersia-ai-brief__tab is-active" role="tab" data-panel="summary">
					<?php esc_html_e( 'خلاصه مقصد', 'topersia-ai' ); ?>
				</button>
				<button type="button" class="topersia-ai-brief__tab" role="tab" data-panel="points">
					<?php esc_html_e( 'نکات کلیدی', 'topersia-ai' ); ?>
				</button>
				<button type="button" class="topersia-ai-brief__tab" role="tab" data-panel="itinerary">
					<?php esc_html_e( 'پیشنهاد برنامه سفر', 'topersia-ai' ); ?>
				</button>
				<button type="button" class="topersia-ai-brief__tab" role="tab" data-panel="export">
					<?php esc_html_e( 'کپی خروجی', 'topersia-ai' ); ?>
				</button>
			</div>

			<div class="topersia-ai-brief__engines">
				<span class="topersia-ai-brief__engines-label"><?php esc_html_e( 'موتور:', 'topersia-ai' ); ?></span>
				<?php echo $this->render_engine_pills( $post_id, $context, $active_engine ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- pre-escaped below. ?>
			</div>

			<div class="topersia-ai-brief__panels">
				<div class="topersia-ai-brief__panel is-active" data-panel="summary">
					<p><?php echo esc_html( $summary_text ? $summary_text : __( 'هنوز خلاصه‌ای تولید نشده است.', 'topersia-ai' ) ); ?></p>
				</div>
				<div class="topersia-ai-brief__panel" data-panel="points">
					<?php if ( $key_points ) : ?>
						<ul>
							<?php foreach ( $key_points as $point ) : ?>
								<li><?php echo esc_html( $point ); ?></li>
							<?php endforeach; ?>
						</ul>
					<?php else : ?>
						<p><?php esc_html_e( 'هنوز نکته کلیدی‌ای تولید نشده است.', 'topersia-ai' ); ?></p>
					<?php endif; ?>
				</div>
				<div class="topersia-ai-brief__panel" data-panel="itinerary">
					<p><?php echo esc_html( $itinerary ? $itinerary : __( 'هنوز پیشنهاد برنامه سفری تولید نشده است.', 'topersia-ai' ) ); ?></p>
				</div>
				<div class="topersia-ai-brief__panel" data-panel="export">
					<pre class="topersia-ai-brief__json"><?php echo esc_html( $export_json ); ?></pre>
					<button type="button" class="topersia-ai-brief__copy-btn" data-copy-target="brief-json-<?php echo esc_attr( $post_id ); ?>">
						<?php esc_html_e( 'کپی JSON', 'topersia-ai' ); ?>
					</button>
				</div>
			</div>

			<p class="topersia-ai-brief__footer">
				<?php
				echo esc_html(
					sprintf(
						/* translators: 1: output type label, 2: engine label. */
						__( 'نوع خروجی: %1$s — موتور: %2$s', 'topersia-ai' ),
						__( 'خلاصه مقصد', 'topersia-ai' ),
						$this->engine_label( $active_engine )
					)
				);
				?>
				<?php if ( 'internal' === $active_engine ) : ?>
					— <?php esc_html_e( 'این خروجی صرفاً از دادهٔ موجود همین صفحه ساخته شده؛ بدون تماس با هیچ سرویس خارجی.', 'topersia-ai' ); ?>
				<?php else : ?>
					— <?php esc_html_e( 'در نسخهٔ وردپرس، هر موتور به API اختصاصی خود متصل می‌شود.', 'topersia-ai' ); ?>
				<?php endif; ?>
			</p>
		</div>
		<?php
		return (string) ob_get_clean();
	}

	/**
	 * Renders the engine pill row: one pill per enabled AI provider (as a
	 * real external link, same as Ask AI) plus one non-link pill for the
	 * built-in internal engine, with the pill matching the currently
	 * displayed content's actual source highlighted.
	 *
	 * @param int                  $post_id       Post ID.
	 * @param array<string,mixed>  $context       Context array.
	 * @param string               $active_engine Provider/engine ID currently shown.
	 * @return string HTML.
	 */
	private function render_engine_pills( $post_id, array $context, $active_engine ) {
		$language = isset( $context['language'] ) ? $context['language'] : WPMLIntegration::current_language();
		$template = $this->prompt_manager->get_template( $context['entity_type'], 'ask_ai', $language );
		$prompt   = $this->prompt_engine->render( $template, $context );

		ob_start();

		printf(
			'<span class="topersia-ai-brief__pill topersia-ai-brief__pill--internal%s">%s%s</span>',
			'internal' === $active_engine ? ' is-active' : '',
			esc_html__( 'موتور داخلی', 'topersia-ai' ),
			'internal' === $active_engine ? ' <span class="topersia-ai-brief__pill-check" aria-hidden="true">✓</span>' : ''
		);

		foreach ( $this->providers->available() as $provider ) {
			$url    = $provider->build_external_url( $prompt, $context );
			$active = ( $provider->get_id() === $active_engine );
			printf(
				'<a class="topersia-ai-brief__pill%1$s" href="%2$s" target="_blank" rel="noopener noreferrer nofollow" data-provider="%3$s" data-post-id="%4$s">%5$s%6$s</a>',
				$active ? ' is-active' : '',
				esc_url( $url ),
				esc_attr( $provider->get_id() ),
				esc_attr( $post_id ),
				esc_html( $provider->get_name() ),
				$active ? ' <span class="topersia-ai-brief__pill-check" aria-hidden="true">✓</span>' : ''
			);
		}

		return (string) ob_get_clean();
	}

	/**
	 * Human-readable label for an engine/provider ID.
	 *
	 * @param string $engine_id Engine ID ("internal", or a provider ID).
	 * @return string
	 */
	private function engine_label( $engine_id ) {
		if ( 'internal' === $engine_id || empty( $engine_id ) ) {
			return __( 'موتور داخلی ToPersia', 'topersia-ai' );
		}

		$provider = $this->providers->get( $engine_id );

		return $provider ? $provider->get_name() : ucfirst( $engine_id );
	}
}
