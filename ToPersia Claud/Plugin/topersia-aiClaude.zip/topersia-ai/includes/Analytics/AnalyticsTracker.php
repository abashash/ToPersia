<?php
/**
 * Privacy-safe analytics: aggregate counts of Ask AI clicks and summary
 * views per post/provider. No IP address, user agent, or user identifier
 * is ever stored, and nothing is sent to a third party (see the plugin's
 * "no external tracking" requirement).
 *
 * @package ToPersia\AI\Analytics
 */

namespace ToPersia\AI\Analytics;

use ToPersia\AI\Database\Database;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AnalyticsTracker {

	/**
	 * Records an event.
	 *
	 * @param int         $post_id    Post ID.
	 * @param string      $event_type e.g. "ask_ai_click", "summary_view".
	 * @param string|null $provider   Provider ID, if applicable.
	 * @param string      $module     Module slug, e.g. "ask_ai" or "summary".
	 * @return bool
	 */
	public function record( $post_id, $event_type, $provider = null, $module = 'ask_ai' ) {
		if ( ! $this->is_enabled() ) {
			return false;
		}

		global $wpdb;
		$table = Database::analytics_table();

		return (bool) $wpdb->insert(
			$table,
			array(
				'post_id'    => (int) $post_id,
				'event_type' => sanitize_key( $event_type ),
				'provider'   => $provider ? sanitize_key( $provider ) : null,
				'module'     => sanitize_key( $module ),
				'created_at' => current_time( 'mysql' ),
			)
		);
	}

	/**
	 * Whether analytics collection is enabled in settings.
	 *
	 * @return bool
	 */
	private function is_enabled() {
		$settings = get_option( 'topersia_ai_settings', array() );

		return ! empty( $settings['analytics_enabled'] );
	}

	/**
	 * Returns click counts per provider for a date range, for the admin
	 * dashboard.
	 *
	 * @param string $event_type Event type to aggregate.
	 * @param int    $days       Look-back window in days.
	 * @return array<string,int>
	 */
	public function counts_by_provider( $event_type = 'ask_ai_click', $days = 30 ) {
		global $wpdb;
		$table = Database::analytics_table();

		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT provider, COUNT(*) as total FROM {$table}
				 WHERE event_type = %s AND created_at >= DATE_SUB(NOW(), INTERVAL %d DAY)
				 GROUP BY provider ORDER BY total DESC",
				$event_type,
				(int) $days
			),
			ARRAY_A
		);

		$result = array();
		foreach ( (array) $rows as $row ) {
			$result[ $row['provider'] ? $row['provider'] : 'n/a' ] = (int) $row['total'];
		}

		return $result;
	}

	/**
	 * Returns the top posts by event count for a date range.
	 *
	 * @param string $event_type Event type to aggregate.
	 * @param int    $days       Look-back window in days.
	 * @param int    $limit      Max rows.
	 * @return array<int,array>
	 */
	public function top_posts( $event_type = 'ask_ai_click', $days = 30, $limit = 10 ) {
		global $wpdb;
		$table = Database::analytics_table();

		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT post_id, COUNT(*) as total FROM {$table}
				 WHERE event_type = %s AND created_at >= DATE_SUB(NOW(), INTERVAL %d DAY)
				 GROUP BY post_id ORDER BY total DESC LIMIT %d",
				$event_type,
				(int) $days,
				(int) $limit
			),
			ARRAY_A
		);

		return is_array( $rows ) ? $rows : array();
	}
}
