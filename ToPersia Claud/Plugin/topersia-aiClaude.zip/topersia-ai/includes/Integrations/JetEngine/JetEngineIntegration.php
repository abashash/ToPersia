<?php
/**
 * JetEngine / Crocoblock integration.
 *
 * JetEngine is fully optional. Every method here defends against JetEngine
 * being absent, mismatched, or partially loaded, and never throws a fatal
 * error - the plugin must keep working on a vanilla WordPress install.
 *
 * @package ToPersia\AI\Integrations\JetEngine
 */

namespace ToPersia\AI\Integrations\JetEngine;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class JetEngineIntegration {

	/**
	 * Registers JetEngine-related hooks. Currently JetEngine data is pulled
	 * on demand by ContextBuilder rather than pushed, so this constructor
	 * only exposes an extensibility point for future modules.
	 */
	public function __construct() {
		/**
		 * Fires after the JetEngine integration has been constructed,
		 * regardless of whether JetEngine itself is active.
		 */
		do_action( 'topersia_ai_jetengine_integration_ready', $this );
	}

	/**
	 * Whether JetEngine is active and usable.
	 *
	 * @return bool
	 */
	public static function is_available() {
		return function_exists( 'jet_engine' ) || class_exists( '\\Jet_Engine' );
	}

	/**
	 * Whether JetEngine's meta box / custom fields component is available.
	 *
	 * @return bool
	 */
	public static function has_meta_boxes() {
		return self::is_available() && function_exists( 'jet_engine' ) && isset( jet_engine()->meta_boxes );
	}

	/**
	 * Whether JetEngine Relations is available.
	 *
	 * @return bool
	 */
	public static function has_relations() {
		return self::is_available() && function_exists( 'jet_engine' ) && isset( jet_engine()->relations );
	}

	/**
	 * Returns a normalised bundle of JetEngine-sourced entity data for a
	 * post: custom fields, taxonomy-based attributes already covered by
	 * ContextBuilder are skipped here, and related posts via JetEngine
	 * Relations.
	 *
	 * @param int    $post_id   Post ID.
	 * @param string $post_type Post type slug (unused directly, kept for
	 *                          future per-post-type field maps).
	 * @return array<string,mixed>
	 */
	public static function get_entity_data( $post_id, $post_type ) {
		if ( ! self::is_available() ) {
			return array();
		}

		$data = array(
			'meta_fields' => self::get_meta_fields( $post_id ),
			'relations'   => self::get_relations( $post_id ),
		);

		/**
		 * Filters the JetEngine-derived entity data before it is merged
		 * into the shared context array.
		 *
		 * @param array  $data      JetEngine data.
		 * @param int    $post_id   Post ID.
		 * @param string $post_type Post type.
		 */
		return apply_filters( 'topersia_ai_jetengine_entity_data', $data, $post_id, $post_type );
	}

	/**
	 * Reads JetEngine custom meta field definitions (where registered) and
	 * their current values for a post, skipping empty values.
	 *
	 * @param int $post_id Post ID.
	 * @return array<string,mixed>
	 */
	private static function get_meta_fields( $post_id ) {
		if ( ! self::has_meta_boxes() ) {
			return array();
		}

		$fields = array();

		try {
			$stores = jet_engine()->meta_boxes->get_meta_fields_for_object( get_post_type( $post_id ) );
		} catch ( \Throwable $e ) {
			// JetEngine internals can change between versions; never fatal.
			return array();
		}

		if ( ! is_array( $stores ) ) {
			return array();
		}

		foreach ( $stores as $field ) {
			if ( empty( $field['name'] ) ) {
				continue;
			}

			$key   = $field['name'];
			$value = get_post_meta( $post_id, $key, true );

			if ( '' === $value || null === $value ) {
				continue;
			}

			$fields[ $key ] = is_scalar( $value ) ? $value : wp_json_encode( $value );
		}

		return $fields;
	}

	/**
	 * Reads related posts through JetEngine Relations, returning a compact
	 * array of { relation_id => [ { id, title } ] }.
	 *
	 * @param int $post_id Post ID.
	 * @return array<string,array>
	 */
	private static function get_relations( $post_id ) {
		if ( ! self::has_relations() ) {
			return array();
		}

		$result = array();

		try {
			$relations = jet_engine()->relations->get_active_relations();
		} catch ( \Throwable $e ) {
			return array();
		}

		if ( ! is_array( $relations ) ) {
			return array();
		}

		foreach ( $relations as $relation ) {
			if ( ! is_object( $relation ) || ! method_exists( $relation, 'get_related' ) ) {
				continue;
			}

			try {
				$related_ids = $relation->get_related( $post_id, 'both' );
			} catch ( \Throwable $e ) {
				continue;
			}

			if ( empty( $related_ids ) ) {
				continue;
			}

			$related_ids = array_slice( (array) $related_ids, 0, 20 );
			$items       = array();

			foreach ( $related_ids as $related_id ) {
				$title = get_the_title( $related_id );
				if ( $title ) {
					$items[] = array(
						'id'    => (int) $related_id,
						'title' => $title,
					);
				}
			}

			if ( $items ) {
				$slug             = method_exists( $relation, 'get_slug' ) ? $relation->get_slug() : (string) $relation->id;
				$result[ $slug ] = $items;
			}
		}

		return $result;
	}
}
