<?php
/**
 * Elementor widget: Ask AI buttons.
 *
 * @package ToPersia\AI\Integrations\Elementor\Widgets
 */

namespace ToPersia\AI\Integrations\Elementor\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use ToPersia\AI\Integrations\Elementor\ElementorModule;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AskAIWidget extends Widget_Base {

	public function get_name() {
		return 'topersia_ai_ask';
	}

	public function get_title() {
		return __( 'ToPersia — Ask AI', 'topersia-ai' );
	}

	public function get_icon() {
		return 'eicon-info-circle-o';
	}

	public function get_categories() {
		return array( 'general' );
	}

	public function get_keywords() {
		return array( 'ai', 'chatgpt', 'claude', 'topersia' );
	}

	protected function register_controls() {
		$this->start_controls_section(
			'section_content',
			array( 'label' => __( 'Content', 'topersia-ai' ) )
		);

		$this->add_control(
			'post_id',
			array(
				'label'       => __( 'Post ID (optional)', 'topersia-ai' ),
				'type'        => Controls_Manager::NUMBER,
				'description' => __( 'Leave empty to use the current post.', 'topersia-ai' ),
			)
		);

		$this->end_controls_section();
	}

	protected function render() {
		$settings = $this->get_settings_for_display();
		$post_id  = ! empty( $settings['post_id'] ) ? (int) $settings['post_id'] : get_the_ID();

		if ( ! $post_id ) {
			return;
		}

		echo ElementorModule::renderer()->render_ask_ai( $post_id ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- pre-escaped in FrontendRenderer/AskAIRenderer.
	}
}
