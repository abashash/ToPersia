<?php
/**
 * Elementor Pro integration: two lightweight widgets (Ask AI, AI Summary)
 * that delegate rendering to FrontendRenderer so markup never diverges
 * between shortcode, block, and Elementor output.
 *
 * Elementor is fully optional - this module no-ops when it is not active.
 *
 * @package ToPersia\AI\Integrations\Elementor
 */

namespace ToPersia\AI\Integrations\Elementor;

use ToPersia\AI\Frontend\FrontendRenderer;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class ElementorModule {

	/** @var FrontendRenderer|null */
	private static $renderer = null;

	public function __construct( FrontendRenderer $renderer ) {
		self::$renderer = $renderer;

		add_action( 'elementor/widgets/register', array( $this, 'register_widgets' ) );
	}

	/**
	 * Accessor used by widget classes, which Elementor instantiates itself
	 * (see register_widgets() below) and therefore cannot receive
	 * constructor-injected dependencies.
	 *
	 * @return FrontendRenderer
	 */
	public static function renderer() {
		if ( null === self::$renderer ) {
			self::$renderer = \ToPersia\AI\Core\Plugin::instance()->get( 'frontend' );
		}

		return self::$renderer;
	}

	/**
	 * Whether Elementor is active.
	 *
	 * @return bool
	 */
	public static function is_available() {
		return did_action( 'elementor/loaded' ) || class_exists( '\\Elementor\\Plugin' );
	}

	/**
	 * Registers the plugin's Elementor widgets.
	 *
	 * Widgets are registered by class name only (no constructor
	 * injection): Elementor re-instantiates widget classes internally as
	 * `new $class( $data, $args )` when rendering saved content, so any
	 * dependency the widget needs must be pulled from the plugin
	 * container at render time instead of being passed in here.
	 *
	 * @param \Elementor\Widgets_Manager $widgets_manager Elementor's widgets manager.
	 * @return void
	 */
	public function register_widgets( $widgets_manager ) {
		if ( ! self::is_available() || ! class_exists( '\\Elementor\\Widget_Base' ) ) {
			return;
		}

		require_once __DIR__ . '/Widgets/AskAIWidget.php';
		require_once __DIR__ . '/Widgets/SummaryWidget.php';
		require_once __DIR__ . '/Widgets/BriefWidget.php';

		$widgets_manager->register( new \ToPersia\AI\Integrations\Elementor\Widgets\AskAIWidget() );
		$widgets_manager->register( new \ToPersia\AI\Integrations\Elementor\Widgets\SummaryWidget() );
		$widgets_manager->register( new \ToPersia\AI\Integrations\Elementor\Widgets\BriefWidget() );
	}
}
