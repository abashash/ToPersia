<?php
/**
 * Registers two dynamic Gutenberg blocks (Ask AI, AI Summary). Both are
 * server-rendered so their markup always matches the shortcode/Elementor
 * output produced by FrontendRenderer - no duplicated templates to keep in
 * sync.
 *
 * The editor script is plain ES5/ES6 registered against WordPress's
 * bundled `wp-*` packages - no build step, no Node.js dependency, matching
 * the platform's zero-build-tool constraint for shipped plugin assets.
 *
 * @package ToPersia\AI\Integrations\Gutenberg
 */

namespace ToPersia\AI\Integrations\Gutenberg;

use ToPersia\AI\Core\Plugin;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class BlockRegistrar {

	public function __construct() {
		add_action( 'init', array( $this, 'register_blocks' ) );
	}

	/**
	 * Registers the block editor script and both dynamic block types.
	 *
	 * @return void
	 */
	public function register_blocks() {
		if ( ! function_exists( 'register_block_type' ) ) {
			return; // Block editor not available (very old WP core).
		}

		wp_register_script(
			'topersia-ai-blocks',
			TOPERSIA_AI_URL . 'assets/blocks/blocks.js',
			array( 'wp-blocks', 'wp-element', 'wp-block-editor', 'wp-components', 'wp-i18n', 'wp-server-side-render' ),
			TOPERSIA_AI_VERSION,
			true
		);

		wp_set_script_translations( 'topersia-ai-blocks', 'topersia-ai', TOPERSIA_AI_PATH . 'languages' );

		register_block_type(
			'topersia-ai/ask-ai',
			array(
				'editor_script'   => 'topersia-ai-blocks',
				'render_callback' => array( $this, 'render_ask_ai_block' ),
				'attributes'      => array(
					'postId' => array(
						'type'    => 'number',
						'default' => 0,
					),
				),
			)
		);

		register_block_type(
			'topersia-ai/summary',
			array(
				'editor_script'   => 'topersia-ai-blocks',
				'render_callback' => array( $this, 'render_summary_block' ),
				'attributes'      => array(
					'postId' => array(
						'type'    => 'number',
						'default' => 0,
					),
				),
			)
		);

		register_block_type(
			'topersia-ai/brief',
			array(
				'editor_script'   => 'topersia-ai-blocks',
				'render_callback' => array( $this, 'render_brief_block' ),
				'attributes'      => array(
					'postId' => array(
						'type'    => 'number',
						'default' => 0,
					),
				),
			)
		);
	}

	/**
	 * Server-render callback for the AI Travel Brief block.
	 *
	 * @param array $attributes Block attributes.
	 * @return string
	 */
	public function render_brief_block( $attributes ) {
		$post_id = ! empty( $attributes['postId'] ) ? (int) $attributes['postId'] : get_the_ID();

		if ( ! $post_id ) {
			return '';
		}

		return Plugin::instance()->get( 'frontend' )->render_brief( $post_id );
	}

	/**
	 * Server-render callback for the Ask AI block.
	 *
	 * @param array $attributes Block attributes.
	 * @return string
	 */
	public function render_ask_ai_block( $attributes ) {
		$post_id = ! empty( $attributes['postId'] ) ? (int) $attributes['postId'] : get_the_ID();

		if ( ! $post_id ) {
			return '';
		}

		return Plugin::instance()->get( 'frontend' )->render_ask_ai( $post_id );
	}

	/**
	 * Server-render callback for the AI Summary block.
	 *
	 * @param array $attributes Block attributes.
	 * @return string
	 */
	public function render_summary_block( $attributes ) {
		$post_id = ! empty( $attributes['postId'] ) ? (int) $attributes['postId'] : get_the_ID();

		if ( ! $post_id ) {
			return '';
		}

		return Plugin::instance()->get( 'frontend' )->render_summary( $post_id );
	}
}
