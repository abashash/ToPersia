<?php
/**
 * WPML integration.
 *
 * WPML is fully optional. When absent, the plugin falls back to the site
 * locale for language detection and behaves as a single-language site.
 *
 * @package ToPersia\AI\Integrations\WPML
 */

namespace ToPersia\AI\Integrations\WPML;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class WPMLIntegration {

	public function __construct() {
		if ( self::is_available() ) {
			add_action( 'init', array( $this, 'register_strings' ) );
		}
	}

	/**
	 * Whether WPML (or WPML String Translation) is active.
	 *
	 * @return bool
	 */
	public static function is_available() {
		return defined( 'ICL_SITEPRESS_VERSION' ) || function_exists( 'icl_object_id' );
	}

	/**
	 * Whether WPML String Translation is active, needed to register
	 * admin-authored strings (labels, prompt templates) for translation.
	 *
	 * @return bool
	 */
	public static function has_string_translation() {
		return function_exists( 'icl_register_string' );
	}

	/**
	 * Registers user-editable plugin strings (Ask AI label, etc.) with
	 * WPML String Translation so site owners can translate them per
	 * language without touching PHP or POT files.
	 *
	 * @return void
	 */
	public function register_strings() {
		if ( ! self::has_string_translation() ) {
			return;
		}

		$settings = get_option( 'topersia_ai_settings', array() );

		if ( ! empty( $settings['ask_ai_label'] ) ) {
			do_action( 'wpml_register_single_string', 'ToPersia AI', 'Ask AI Label', $settings['ask_ai_label'] );
		}
	}

	/**
	 * Returns the current WPML language code, or the site locale prefix
	 * when WPML is not active.
	 *
	 * @return string
	 */
	public static function current_language() {
		if ( self::is_available() ) {
			$lang = apply_filters( 'wpml_current_language', null );
			if ( $lang ) {
				return $lang;
			}
		}

		return substr( get_locale(), 0, 2 );
	}

	/**
	 * Returns all active WPML languages as [ code => native_name ], or a
	 * single-entry array with the site locale when WPML is inactive.
	 *
	 * @return array<string,string>
	 */
	public static function active_languages() {
		if ( self::is_available() ) {
			$languages = apply_filters( 'wpml_active_languages', array() );
			if ( is_array( $languages ) && $languages ) {
				$map = array();
				foreach ( $languages as $code => $lang ) {
					$map[ $code ] = isset( $lang['native_name'] ) ? $lang['native_name'] : $code;
				}
				return $map;
			}
		}

		$locale = substr( get_locale(), 0, 2 );
		return array( $locale => $locale );
	}

	/**
	 * True when the given language code reads right-to-left.
	 *
	 * @param string $lang_code Two-letter language code.
	 * @return bool
	 */
	public static function is_rtl_language( $lang_code ) {
		return in_array( $lang_code, array( 'fa', 'ar', 'he', 'ur' ), true );
	}
}
