<?php
/**
 * Fires only when the plugin is deleted from Plugins → Installed Plugins
 * (never on deactivation). Data is removed ONLY when the site owner has
 * explicitly opted in via Settings → "On uninstall" - by default,
 * uninstalling keeps all summaries, prompts, and analytics intact.
 *
 * @package ToPersia\AI
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

$settings = get_option( 'topersia_ai_settings', array() );

if ( empty( $settings['remove_data_on_uninstall'] ) ) {
	return;
}

global $wpdb;

$tables = array(
	$wpdb->prefix . 'topersia_ai_summaries',
	$wpdb->prefix . 'topersia_ai_prompts',
	$wpdb->prefix . 'topersia_ai_analytics',
);

foreach ( $tables as $table ) {
	$wpdb->query( "DROP TABLE IF EXISTS `{$table}`" ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- table name is a hard-coded, prefixed constant, never user input.
}

delete_option( 'topersia_ai_settings' );
delete_option( 'topersia_ai_db_version' );
delete_option( 'topersia_ai_version' );

// Clean up any lingering transients (non-object-cache installs).
$like = $wpdb->esc_like( '_transient_topersia_ai_' ) . '%';
$wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->options} WHERE option_name LIKE %s", $like ) ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared

$like_timeout = $wpdb->esc_like( '_transient_timeout_topersia_ai_' ) . '%';
$wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->options} WHERE option_name LIKE %s", $like_timeout ) ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
