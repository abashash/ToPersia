# ToPersia AI — Testing Notes

## What could not be run in this development environment

The plugin was built in a sandbox with **no outbound network access** and
**no PHP interpreter installed** (`php -v` → not found). Concretely, this
means the following were **not** run and must be done before/at deployment:

- `php -l` (syntax lint) on any file
- `phpcs --standard=WordPress` / `WordPress-Extra`
- `phpstan analyse`
- Any real WordPress bootstrap (no `wp-load.php`, no database, no
  `dbDelta()` execution) — the schema in `Database.php` has been reviewed
  by eye against MySQL `CREATE TABLE` syntax but never actually executed
- A live call to the OpenAI API from `OpenAIGenerator` (no network egress)
- Loading the plugin inside an actual WordPress + JetEngine + WPML +
  Elementor install to confirm no fatal errors, hook-order issues, or
  version-specific API mismatches

**Before going live**, at minimum:

1. Run `php -l` across every `.php` file (a one-line loop:
   `find . -name "*.php" -exec php -l {} \;`).
2. Activate on a staging copy of the ToPersia site and check
   `wp-content/debug.log` for notices/warnings with `WP_DEBUG` on.
3. Confirm the three tables are created correctly (`SHOW TABLES LIKE
   'wp_topersia_ai_%'`, then `DESCRIBE` each).
4. Add a real OpenAI API key and generate one summary manually from
   ToPersia AI → Summaries to confirm the end-to-end request/response
   parsing in `OpenAIGenerator` matches the live API's current response
   shape (double-check `choices[0].message.content` still matches the
   current Chat Completions response format).
5. Test Ask AI buttons actually open the intended provider with the prompt
   pre-filled — public AI web apps occasionally change their query-string
   contract, and each provider's base URL is filterable
   (`topersia_ai_provider_base_url_<id>`) specifically so this can be
   patched without a plugin update if a provider changes behaviour.

## What *was* reviewed

- Every file was read back after writing and manually checked for balanced
  braces/parens, correct namespace/use statements, and consistent method
  signatures against their call sites.
- A structural cross-check confirmed every class referenced via
  `use Foo\Bar;` or `new Foo\Bar()` has a corresponding file at the path
  the autoloader (`Core/Autoloader.php`) would resolve it to.
- All `$wpdb` queries were checked by eye for `prepare()` usage (see
  `docs/SECURITY-AUDIT.md` for the specific exceptions and why they're
  safe).
- Manual trace of the activation → boot → render request lifecycle to
  confirm service construction order in `Plugin::boot()` never references
  a service before it is constructed.

## Suggested test matrix once on a real WordPress install

| Area | Test |
|---|---|
| Activation | Activate on a clean install; confirm 3 tables + default options created, no PHP notices |
| Ask AI | Enable all 5 providers; confirm each button opens the right URL with the prompt visible/pre-filled |
| AI Summary | Add API key; generate a summary for one post of each enabled post type; confirm status transitions (generating → current) |
| Manual edit | Manually edit a summary via REST/admin; confirm status becomes "manual" and `save_post` no longer overwrites it |
| Staleness | Edit post content; confirm summary marked "stale" (auto-regenerate off) or regenerated (auto-regenerate on, after ~5s) |
| JetEngine | On a post type with JetEngine meta fields, confirm `{field_*}` placeholders resolve in a custom prompt template |
| WPML | Switch site language; confirm Ask AI label and prompt resolution follow the active language, and `dir="rtl"` is set for Persian |
| Elementor | Drag both widgets onto a template; confirm output matches shortcode output exactly |
| Gutenberg | Insert both blocks; confirm editor preview matches frontend |
| REST security | Attempt `PUT /summary/{id}` as a logged-out user and as a Subscriber; confirm 401/403 |
| Analytics | Click an Ask AI button; confirm one row in `wp_topersia_ai_analytics` with no IP/UA/user fields |
| Uninstall | Delete plugin with "remove data on uninstall" unchecked (data persists) and checked (tables dropped) |
