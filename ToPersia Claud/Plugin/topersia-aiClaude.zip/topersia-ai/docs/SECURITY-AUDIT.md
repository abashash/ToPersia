# ToPersia AI — Security Review

This is a **manual code review**, not an automated audit. PHP, PHPCS and
PHPStan were not available in the development sandbox (no outbound network,
no `php` binary installed) — see docs/TESTING.md for exactly what was and
was not verified. Run `phpcs --standard=WordPress` and `php -l` on every
file before deploying to production, and treat this document as a checklist
of what the code is *intended* to do, not a substitute for that.

## Database access

- Every table is created via `dbDelta()` only (`Database::install()`);
  no `CREATE TABLE` runs outside of it.
- Every query with a variable value uses `$wpdb->prepare()`. The only
  queries built with raw string interpolation are ones that interpolate a
  **table name constant** (never user input) — e.g.
  `"DELETE FROM {$wpdb->options} WHERE ..."` with the `WHERE` value itself
  passed through `%s` in `prepare()`. Search the codebase for
  `// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared` to review each
  occurrence; there are four, all table-name-only interpolations in
  `CacheManager::flush_all()` and `uninstall.php`.
- `uninstall.php` drops tables using `$wpdb->prefix`-derived names only,
  gated behind an explicit opt-in setting (`remove_data_on_uninstall`,
  default `false`).

## Output escaping

- All user-facing and admin-facing HTML uses `esc_html()`, `esc_attr()`,
  `esc_url()`, or `wp_kses_post()` and its cousins.
- Two deliberate, narrow exceptions, both documented inline with
  `// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped`:
  - `AskAIRenderer::render_icon()` — outputs `wp_kses()`-filtered SVG
    markup with a strict allow-list (`svg`, `path` tags; `d`, `fill`,
    `viewbox`, `width`, `height`, `aria-hidden`, `xmlns`, `fill-opacity`
    attributes only). Icon strings come exclusively from first-party
    provider classes, never from user or database input.
  - The Elementor widgets' `render()` methods echo pre-escaped HTML
    returned by `FrontendRenderer`, which itself escapes everything at the
    point of output.
- AI-generated summary text is passed through `wp_kses_post()` both when
  stored (`OpenAIGenerator::generate()`, `SummaryManager::save_manual()`)
  and when rendered (`FrontendRenderer::render_summary()`), so a
  prompt-injected AI response cannot inject arbitrary script tags even if
  the model tried to.

## Input handling

- Every `$_POST`/`$_GET` read is wrapped in the matching sanitizer
  (`sanitize_key()`, `sanitize_text_field()`, `absint()`, `wp_unslash()`)
  before use — see `PromptManagerPage` and `SummaryListPage`.
- The Settings API's `sanitize_callback` (`SettingsPage::sanitize()`)
  rebuilds the entire settings array field-by-field with an explicit
  allow-list of keys and types; nothing from `$_POST` is ever merged in
  unsanitized.

## Authentication & authorization

- Every admin screen checks `current_user_can( 'manage_options' )` before
  rendering or acting (`AdminMenu::CAPABILITY`).
- `admin-post.php` handlers (`PromptManagerPage`) call
  `check_admin_referer()` (nonce) **and** `current_user_can()` — nonce
  presence alone is never treated as authorization.
- REST routes that edit data (`generate_summary`, `save_manual_summary`)
  use `permission_callback` checking `current_user_can( 'edit_post', $post_id )`
  per-post, not a blanket capability — an editor cannot regenerate a
  summary for a post they cannot edit.
- The public `/track` REST route is intentionally `__return_true` (no
  auth): it accepts only a numeric `post_id` that must resolve to a real
  post and an `event_type` from a two-value allow-list
  (`ask_ai_click`, `summary_view`), and writes only an aggregate count row
  with no free-text or personal fields — see AnalyticsTracker's schema.

## Secrets handling

- The OpenAI API key lives in `wp_options` under `topersia_ai_settings`,
  the same storage tier as any other plugin option (equivalent to how
  WPML/JetEngine license keys are typically stored). It is read only
  inside `OpenAIGenerator::get_api_key()`, used only in a server-side
  `wp_remote_post()` `Authorization` header, and is never included in any
  REST response, localized script data, or HTML output.
- Consider a secrets-manager or `wp-config.php` constant override (e.g. via
  the `topersia_ai_summary_generator` filter with a custom generator) if
  your hosting policy requires API keys outside the database.

## External requests

- The only outbound HTTP call in the plugin is `OpenAIGenerator::generate()`
  via `wp_remote_post()` to `https://api.openai.com/v1/chat/completions`,
  with a 25-second timeout. Ask AI providers are opened directly by the
  visitor's browser (`target="_blank" rel="noopener noreferrer nofollow"`)
  and never fetched server-side.

## Known gaps / follow-ups before production

- No rate limiting on the public `/track` endpoint beyond WordPress's own
  REST API defaults — add a rate limiter (e.g. via a firewall rule or a
  transient-based counter) if click-spam becomes a concern.
- `OpenAIGenerator` has not been exercised against a live API key (no
  network access in the development sandbox) — test it end-to-end before
  relying on automatic summary generation in production.
- Run `phpcs --standard=WordPress-Extra` and `php -l` on every file; none
  of that tooling was available in this sandbox.
