# ToPersia AI — Configuration Guide

## 1. Installation

1. Upload the `topersia-ai` folder to `wp-content/plugins/` (or install the
   zip via Plugins → Add New → Upload Plugin).
2. Activate. This creates three tables (`wp_topersia_ai_summaries`,
   `wp_topersia_ai_prompts`, `wp_topersia_ai_analytics`) via `dbDelta` and
   seeds default options — nothing else on your site is touched.

## 2. Settings (ToPersia AI → Settings)

### Ask AI
- **Enable Ask AI** — master on/off switch.
- **Button group label** — heading text shown above the buttons.
- **Enabled providers** — pick any of ChatGPT, Claude, Gemini, Perplexity, Grok.
- **Placement** — "Automatically after content" appends the block to
  `the_content` on singular views; "Manual only" disables auto-placement so
  you control it entirely via shortcode/block/Elementor.

### AI Summary
- **Enable AI Summary** — master on/off switch.
- **Summary engine** — **Internal (default)**: the built-in offline extractive
  engine (see `docs/ARCHITECTURE.md` → "The internal (non-AI) engine") —
  works immediately, no API key, no external request. **AI provider**: uses
  whichever generator `topersia_ai_summary_generator` resolves to (the
  built-in OpenAI-compatible generator by default); falls back to the
  internal engine automatically if selected without a configured key.
- **Auto-regenerate on edit** — when on, saving a post with changed content
  schedules a background regeneration (via `wp_schedule_single_event`, 5
  seconds after save, so it never blocks the editor). When off, the existing
  summary is simply marked "stale" for an editor to regenerate manually.
- **Enabled post types** — tick every entity post type that should get
  summaries (e.g. attractions, hotels, cities — your 42 ToPersia post types
  are all listed here automatically since the list is built from
  `get_post_types()`).

### AI Provider (Summary generation)
- **OpenAI API key** — required for the built-in generator to produce new
  summaries. Stored in `wp_options`, read only server-side, never exposed to
  the frontend or REST responses.
- **Model** — defaults to `gpt-4o-mini`; set to any Chat Completions-
  compatible model your key has access to.

> Ask AI needs **no API key at all** — it only builds links to each
> provider's public web app.

### Appearance
- Icon style, button style, accent colour, and border radius. Accent colour
  and radius are applied via an inline `:root { --topersia-ai-accent: ...; }`
  stylesheet generated from your settings (see `Frontend/Assets.php`).

### Privacy & Performance
- **Analytics** — anonymous, aggregate click/view counts only. No IP
  address, user agent, cookie, or user identifier is ever stored (see
  `includes/Analytics/AnalyticsTracker.php`).
- **Cache lifetime** — TTL, in seconds, for anything cached via `CacheManager`.
- **On uninstall** — unchecked by default. Tick this if you want all
  ToPersia AI data permanently removed when the plugin is deleted (not
  merely deactivated) from Plugins → Installed Plugins.

## 3. Prompt Templates (ToPersia AI → Prompt Templates)

Templates are matched in this order for a given entity type + module +
language:

1. Exact match (entity type + module + language)
2. Entity type + module, any language
3. `entity_type = "other"` + module (a generic fallback you control)
4. The built-in default template (hard-coded, English)

Available placeholders in any template:

```
{title} {url} {excerpt} {content} {site} {entity_type} {post_type}
{language} {categories} {tags} {tax_<taxonomy_slug>} {field_<jetengine_field_key>}
```

`{content}` is the post's plain-text content, truncated to ~4000 characters
on a safe boundary before being inserted, so prompts never balloon
uncontrollably in length.

### Example: an "attraction" summary template

```
Write a 3-sentence factual summary in {language} of the tourist attraction
"{title}" located in {tax_region}. Categories: {categories}. Source
content: {content}
```

### Example: an "ask_ai" template for hotels

```
I'm looking at the hotel "{title}" on {site} ({url}). Based on the page
content, help me understand what it offers: {excerpt}
```

## 4. JetEngine integration

No configuration needed. When JetEngine is active, `JetEngineIntegration`
automatically:

- Reads registered meta box fields for the post's type and folds non-empty
  values into the context as `field_<key>` placeholders.
- Reads active JetEngine Relations and includes related post titles.

Every JetEngine call is wrapped in a `try/catch` against `\Throwable` and
returns an empty array on any internal API mismatch — a JetEngine update
that changes internals cannot fatal your site.

## 5. WPML integration

No configuration needed. When WPML is active:

- Summaries and prompt templates are resolved per WPML language code.
- The Ask AI label is registered with WPML String Translation
  (`icl_register_string`) so it can be translated per language from
  WPML → String Translation, no code changes required.
- `WPMLIntegration::is_rtl_language()` flags `fa`, `ar`, `he`, `ur` so the
  Ask AI block renders with `dir="rtl"`.

## 6. Elementor Pro

Two widgets are auto-registered under the "General" category when
Elementor is active: **ToPersia — Ask AI** and **ToPersia — AI Summary**.
Both accept an optional "Post ID" control; leave it empty to use the
current post (the common case for content inside a single template).

## 7. Gutenberg

Two dynamic blocks are available in the block inserter: **ToPersia — Ask AI**
and **ToPersia — AI Summary**. Both are server-rendered (via
`register_block_type()`'s `render_callback`), so the editor preview
(`ServerSideRender`) always matches the live frontend output exactly.

## 8. Shortcodes

```
[topersia_ai_brief]                 Full AI Travel Brief card (recommended)
[topersia_ai_brief post_id="123"]
[topersia_ai_ask]                   Standalone Ask AI buttons only
[topersia_ai_ask post_id="123"]
[topersia_ai_summary]               Standalone summary text only
[topersia_ai_summary post_id="123"]
```
