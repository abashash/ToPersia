# Changelog

## 1.0.0

Initial release.

- **Ask AI**: external-link buttons for ChatGPT, Claude, Gemini, Perplexity,
  and Grok, built from entity-aware, per-language prompt templates.
- **AI Summary**: stored, cacheable content summaries with manual
  edit/override, staleness detection on content change, and one-click
  regeneration; ships with a built-in OpenAI-compatible generator behind a
  swappable `SummaryGeneratorInterface`.
- Prompt Template manager (entity type × module × language).
- JetEngine integration (custom fields, relations) — optional, safe no-op
  when JetEngine is absent.
- WPML integration (per-language resolution, String Translation
  registration, RTL detection) — optional, safe no-op when WPML is absent.
- Elementor Pro widgets and Gutenberg blocks, both server-rendered against
  the same `FrontendRenderer` as the shortcode.
- Privacy-safe, opt-out analytics: aggregate counts only, no personal data.
- Non-destructive deactivation; opt-in-only data removal on uninstall.
