# ToPersia AI — Architecture

## Goals

- Zero hard dependency on JetEngine, WPML, or Elementor — every integration
  detects the host plugin and no-ops safely when it is absent.
- One source of truth for rendered markup: shortcode, Gutenberg block, and
  Elementor widget all call the same `FrontendRenderer` methods, so output
  never drifts between placement mechanisms.
- No build step for shipped assets: all JS/CSS is hand-written and enqueued
  directly, matching the plugin's zero-Node.js-at-runtime constraint.
- Prepared statements and `dbDelta` only for all database access; nonces +
  `current_user_can()` capability checks on every state-changing action.

## Module map

```
topersia-ai.php                  Bootstrap: constants, autoloader, hooks
includes/
  Core/
    Plugin.php                   Service container / boot order
    Autoloader.php                PSR-4-style autoloader (no Composer)
    Activator.php / Deactivator.php
  Database/
    Database.php                 dbDelta schema for 3 tables
  Context/
    ContextBuilder.php           Post → structured context array
  Prompt/
    PromptEngine.php              {placeholder} template rendering
    PromptManager.php             CRUD over stored prompt templates
  Providers/
    ProviderInterface.php / AbstractProvider.php
    ChatGPTProvider.php, ClaudeProvider.php, GeminiProvider.php,
    PerplexityProvider.php, GrokProvider.php, CopilotProvider.php
    ProviderRegistry.php          Discovery + `topersia_ai_register_providers`
  Summary/
    SummaryRepository.php         Low-level CRUD (summaries table)
    SummaryManager.php            Staleness, generation, manual overrides
    SummaryGeneratorInterface.php Pluggable AI backend contract
    OpenAIGenerator.php           Built-in OpenAI-compatible implementation
  AskAI/
    AskAIRenderer.php             Ask AI markup
  Frontend/
    FrontendRenderer.php          Auto-placement + shared render methods
    Assets.php                    Conditional enqueue + inline theming CSS
  Shortcode/Shortcode.php
  Integrations/
    JetEngine/JetEngineIntegration.php
    WPML/WPMLIntegration.php
    Elementor/ElementorModule.php + Widgets/
    Gutenberg/BlockRegistrar.php
  REST/RestController.php         topersia-ai/v1 namespace
  Admin/
    AdminMenu.php, SettingsPage.php, PromptManagerPage.php, SummaryListPage.php
  Analytics/AnalyticsTracker.php  Privacy-safe aggregate events
  Cache/CacheManager.php          Transients / object cache wrapper
```

## Data flow (AI Summary)

1. `ContextBuilder::build( $post_id )` gathers title, excerpt, plain-text
   content, taxonomies, and (if available) JetEngine meta fields/relations,
   plus the WPML language code.
2. `PromptManager::get_template()` resolves the best-matching stored
   template (entity type + module + language → entity type + module → "other"
   + module → built-in default).
3. `PromptEngine::render()` flattens the context into `{placeholder}` values
   and substitutes them into the template.
4. `SummaryManager::generate()` hands the rendered prompt to whichever
   `SummaryGeneratorInterface` is registered (default: `OpenAIGenerator`,
   swappable via the `topersia_ai_summary_generator` filter) and persists
   the result with status `current`.
5. `FrontendRenderer::render_summary()` reads the stored row — generation
   never happens on the frontend request path, keeping full-page caching
   safe.

## The internal (non-AI) engine

`Summary\InternalGenerator` implements the same `SummaryGeneratorInterface`
as `OpenAIGenerator`, but does classic extractive summarization instead of
calling any API:

1. Split content into sentences (Unicode-aware, handles Persian `؟` and
   Latin `. ! ?` terminators).
2. Tokenize each sentence (Unicode word matching + a compact FA/EN
   stopword list).
3. Score each sentence: summed token frequency across the document,
   normalized by sentence length, with a gentle lead-position bonus
   (earlier sentences tend to be more summary-worthy) and a title-overlap
   bonus.
4. Pick the top-N sentences for the summary, restored to original reading
   order; pick the next highest-scoring distinct sentences (plus any short
   JetEngine field values) as key points.

It is the default engine (`summary_engine = 'internal'` in settings)
specifically so AI Summary works immediately on a fresh install with zero
configuration and zero cost. `SummaryManager::get_generator()` also falls
back to it automatically if `summary_engine = 'ai'` is selected but no
provider is actually configured.

## The AI Travel Brief card

`Brief\BriefRenderer` is the primary, richer successor to the standalone
Ask AI / Summary blocks: one card combining a breadcrumb
(`ContextBuilder::build_breadcrumb()`), four content tabs (Summary, Key
Points, Itinerary Suggestion, JSON Export - all pre-rendered server-side
and toggled client-side, so it stays fully cache-safe per the platform's
full-page-cache rule), and a row of "engine pills": one non-link pill for
the internal engine plus one real external link per enabled AI provider
(reusing the same `ProviderInterface::build_external_url()` as Ask AI). The
footer states which engine actually produced the visible content, read
straight from the summary row's `provider` column.

Available via the `[topersia_ai_brief]` shortcode, the "ToPersia — AI
Travel Brief" Elementor widget, and the `topersia-ai/brief` Gutenberg
block; it is also what auto-placement now appends after content instead of
the separate Ask AI + Summary blocks.

## Data flow (Ask AI)

Ask AI never calls an AI API server-side. `AskAIRenderer` builds a prompt
the same way (context → template → render) and hands it to each enabled
`ProviderInterface::build_external_url()`, which returns a URL the visitor's
own browser opens directly. No content leaves your server until the visitor
clicks a button.

## Extensibility points

| Hook | Purpose |
|---|---|
| `topersia_ai_loaded` | Fires once the plugin container has booted. |
| `topersia_ai_register_providers` | Register additional AI providers. |
| `topersia_ai_summary_generator` (filter) | Swap the AI Summary backend. |
| `topersia_ai_context` (filter) | Adjust the built context array. |
| `topersia_ai_entity_type_map` (filter) | Adjust post-type → entity-type mapping. |
| `topersia_ai_prompt_replacements` (filter) | Add custom placeholder tokens. |
| `topersia_ai_jetengine_entity_data` (filter) | Adjust JetEngine-derived data. |

## Caching & performance

- Frontend assets are enqueued only on pages where they are actually used
  (`Frontend/Assets.php`), not sitewide.
- Summaries are stored, not computed on request — the frontend read path is
  a single indexed `wpdb` lookup.
- `CacheManager` wraps transients (or the external object cache, when
  present) for anything worth memoizing beyond the stored summary itself.
- `save_post` marks summaries stale (or schedules a deferred regeneration
  via `wp_schedule_single_event`, never inline) so editors are never
  blocked waiting on an AI API call.
