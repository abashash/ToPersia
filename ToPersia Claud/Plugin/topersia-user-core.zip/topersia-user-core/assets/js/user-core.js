(function(){
  'use strict';
  function ready(fn){document.readyState==='loading'?document.addEventListener('DOMContentLoaded',fn,{once:true}):fn();}
  ready(function(){
    var cfg=window.ToPersiaUserCore||{};
    function ajax(action,data){
      var payload=new URLSearchParams();payload.set('action',action);payload.set('nonce',cfg.nonce||'');
      Object.keys(data||{}).forEach(function(k){payload.set(k,data[k]==null?'':data[k]);});
      return fetch(cfg.ajaxUrl||'',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'},body:payload.toString(),credentials:'same-origin'})
        .then(function(r){if(!r.ok)throw new Error('HTTP '+r.status);return r.json();});
    }
    function setMessage(id,text,ok){var el=document.getElementById(id);if(!el)return;el.textContent=text||'';el.className='tp-message'+(ok?' success':' error');}
    function activateTab(root,tab,push){
      var target=null;
      root.querySelectorAll('[data-tp-panel]').forEach(function(panel){
        if(panel.getAttribute('data-tp-panel')===tab)target=panel;
      });
      if(!target){
        tab=root.getAttribute('data-tp-default-tab')||'overview';
        root.querySelectorAll('[data-tp-panel]').forEach(function(panel){
          if(panel.getAttribute('data-tp-panel')===tab)target=panel;
        });
      }
      if(!target){
        var first=root.querySelector('[data-tp-panel]');
        if(!first)return;
        tab=first.getAttribute('data-tp-panel');
      }
      root.querySelectorAll('[data-tp-panel]').forEach(function(panel){
        var on=panel.getAttribute('data-tp-panel')===tab;
        panel.classList.toggle('active',on);
        panel.hidden=!on;
        panel.setAttribute('aria-hidden',on?'false':'true');
      });
      root.querySelectorAll('[data-tp-tab][role="tab"]').forEach(function(button){
        var on=button.getAttribute('data-tp-tab')===tab;
        button.classList.toggle('active',on);
        button.setAttribute('aria-selected',on?'true':'false');
        button.setAttribute('tabindex',on?'0':'-1');
      });
      if(push){
        var u=window.location.href.split('#')[0];
        window.history.replaceState(null,'',u+'#'+encodeURIComponent(tab));
      }
      root.dispatchEvent(new CustomEvent('topersia:tab-change',{detail:{tab:tab},bubbles:false}));
    }
    document.querySelectorAll('[data-tp-dashboard]').forEach(function(root){
      root.addEventListener('click',function(e){var t=e.target.closest('[data-tp-tab]');if(!t||!root.contains(t))return;e.preventDefault();activateTab(root,t.getAttribute('data-tp-tab')||'overview',true);});
      root.addEventListener('keydown',function(e){var b=e.target.closest('[data-tp-tab][role="tab"]');if(!b||!root.contains(b))return;var a=[].slice.call(root.querySelectorAll('[data-tp-tab][role="tab"]')),i=a.indexOf(b),n=i;if(e.key==='ArrowRight'||e.key==='ArrowDown')n=(i+1)%a.length;if(e.key==='ArrowLeft'||e.key==='ArrowUp')n=(i-1+a.length)%a.length;if(e.key==='Home')n=0;if(e.key==='End')n=a.length-1;if(n!==i){e.preventDefault();a[n].focus();activateTab(root,a[n].getAttribute('data-tp-tab'),true);}});
      var h=window.location.hash.replace(/^#/,'');var initial='overview';try{if(h)initial=decodeURIComponent(h);}catch(_e){}activateTab(root,initial,false);
    });
    var saveHandler=function(e){var button=e.target.closest('.tp-save-entity');if(!button)return;var saved=button.classList.contains('is-saved');button.disabled=true;ajax(saved?'topersia_remove_saved_place':'topersia_save_place',{post_id:button.getAttribute('data-post-id')||'',post_type:button.getAttribute('data-post-type')||''}).then(function(r){if(!r.success)return;button.classList.toggle('is-saved',!saved);button.textContent=saved?'✓ '+(window.ToPersiaUserCore.removeSavedLabel||'Remove from saved'):'✓ '+(window.ToPersiaUserCore.savedLabel||'Saved');document.querySelectorAll('[data-tp-saved-count]').forEach(function(c){if(r.data&&typeof r.data.count!=='undefined')c.textContent=String(r.data.count);});}).catch(function(){}).finally(function(){button.disabled=false;});};
    document.addEventListener('click',saveHandler);
    var logout=document.getElementById('tp-logout');if(logout){logout.addEventListener('click',function(){logout.disabled=true;ajax('topersia_logout',{}).then(function(r){if(r.success)window.location.href=r.data.redirect;}).catch(function(){logout.disabled=false;});});}
    var profile=document.getElementById('tp-profile-form');if(profile){profile.addEventListener('submit',function(e){e.preventDefault();var btn=profile.querySelector('button[type="submit"]');if(btn)btn.disabled=true;var d={};new FormData(profile).forEach(function(v,k){d[k]=v;});ajax('topersia_save_profile',d).then(function(r){setMessage('tp-profile-message',(r.data&&r.data.message)||'',!!r.success);if(r.success&&d.language){document.documentElement.setAttribute('data-tp-user-lang',d.language);}}).catch(function(){setMessage('tp-profile-message','Error',false);}).finally(function(){if(btn)btn.disabled=false;});});}
    /* تمام‌صفحه — سه پله، چون position:fixed اگر یکی از نیاکان
       transform یا filter یا contain داشته باشد، به آن نیا قفل می‌شود
       و عنصر به جای دیدگاه، ته سند می‌نشیند. */
    var dash=document.querySelector('[data-tp-fullscreen="1"]');
    if(dash){
      var pinned=function(){
        var cs=window.getComputedStyle(dash);
        if(cs.position!=='fixed')return false;
        /* افقی سنجیده نمی‌شود: 100vw عرض نوار پیمایش را هم می‌شمارد و در
           RTL عنصر چند پیکسل به چپ می‌رود. ملاک، چسبیدن به بالای دیدگاه است. */
        return Math.abs(dash.getBoundingClientRect().top)<=2;
      };
      var report=function(step){
        try{
          if(window.ToPersiaUserCore&&window.ToPersiaUserCore.ajaxUrl){
            var b=new URLSearchParams();
            b.set('action','topersia_log_js');b.set('m','پنل کاربری تمام‌صفحه نشد — پلهٔ '+step);
            b.set('s',document.body.className);b.set('u',location.pathname);
            fetch(window.ToPersiaUserCore.ajaxUrl,{method:'POST',body:b,credentials:'same-origin',keepalive:true});
          }
        }catch(e){}
      };

      /* پلهٔ یک — انتقال به body و کلاس‌ها */
      if(dash.parentNode!==document.body)document.body.appendChild(dash);
      document.documentElement.classList.add('tp-usercore-fullscreen');
      document.body.classList.add('tp-usercore-open');

      /* پلهٔ دو — سبک درون‌خطی، اگر شیوه‌نامه‌ای بازنویسی کرده باشد */
      if(!pinned()){
        dash.style.setProperty('position','fixed','important');
        dash.style.setProperty('inset','0','important');
        dash.style.setProperty('height','100dvh','important');
        dash.style.setProperty('z-index','999999','important');
        dash.style.setProperty('overflow','auto','important');
      }

      /* پلهٔ سه — بیرون‌بردن از body، برای وقتی که خود body بلوک احاطه‌کننده
         ساخته است. آن‌وقت هیچ نیایی جز html نمی‌ماند. */
      if(!pinned()){
        document.documentElement.appendChild(dash);
        if(!pinned())report(3);else report(2);
      }
    }
  });
})();
