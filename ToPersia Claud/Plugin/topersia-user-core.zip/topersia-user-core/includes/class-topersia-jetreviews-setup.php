<?php
/**
 * راه‌اندازی یک‌کلیکی JetReviews روی همهٔ نوع‌پست‌های ToPersia.
 *
 * این کلاس هیچ کد JetReviews را کپی/بازنویسی نمی‌کند؛ فقط همان گزینهٔ
 * تنظیماتی که خودِ JetReviews در پیشخوان می‌خواند و می‌نویسد
 * (`jet-reviews-settings`) را به‌صورت برنامه‌ریزی‌شده پر می‌کند — دقیقاً
 * همان کاری که با کلیک‌کردن ۴۲ باره روی چک‌باکس‌های تنظیمات آن انجام
 * می‌شد، اما یک‌جا و بدون خطای انسانی.
 *
 * اگر JetReviews بعداً روی همین گزینه چیز دیگری هم ذخیره کند (مثلاً
 * تنظیمات Integrations)، این کلاس آن را پاک نمی‌کند — فقط کلیدهای مربوط
 * به «کدام نوع‌پست‌ها مجازند» و «تنظیمات هر نوع‌پست» را ادغام می‌کند.
 *
 * @package ToPersia
 */

defined( 'ABSPATH' ) || exit;

final class ToPersia_JetReviews_Setup {

	const OPTION_KEY = 'jet-reviews-settings';
	const NONCE_ACTION = 'topersia_setup_jetreviews';

	public static function instance(): self {
		static $instance = null;
		return $instance ??= new self();
	}

	private function __construct() {
		add_action( 'admin_post_topersia_setup_jetreviews', array( $this, 'handle_submit' ) );
	}

	/**
	 * ۴۲ نوع‌پست اختصاصی ToPersia که با JetEngine ساخته شده‌اند.
	 *
	 * @return array<string,string> slug => برچسب فارسی
	 */
	public static function post_types(): array {
		return array(
			'tp_country'         => 'G1 — کشور',
			'tp_province'        => 'G3 — استان',
			'tp_county'          => 'G4 — شهرستان',
			'tp_city'            => 'G5 — شهر',
			'tp_district'        => 'G6 — محله',
			'tp_region'          => 'G2 — منطقه جغرافیایی',
			'tp_village'         => 'G7 — روستا',
			'tp_island'          => 'G8 — جزیره',
			'tp_mountain'        => 'G9 — کوه',
			'tp_water_body'      => 'G10 — پهنه آبی',
			'tp_desert'          => 'G11 — کویر',
			'tp_forest_plain'    => 'G12 — جنگل/دشت',
			'tp_border_crossing' => 'G13 — گذرگاه مرزی',
			'tp_monument'        => 'A2 — بنای تاریخی',
			'tp_religious_site'  => 'A3 — مکان مذهبی',
			'tp_museum'          => 'A7 — موزه',
			'tp_protected_area'  => 'A9 — پارک ملی',
			'tp_natural_feature' => 'A10 — عارضه طبیعی',
			'tp_ancient_site'    => 'A12 — محوطه باستانی',
			'tp_landscape'       => 'A13 — منظر فرهنگی',
			'tp_handicraft'      => 'C1 — صنایع دستی',
			'tp_local_food'      => 'C2 — غذای محلی',
			'tp_costume'         => 'C5 — لباس سنتی',
			'tp_music'           => 'C6 — موسیقی محلی',
			'tp_dance'           => 'C7 — رقص محلی',
			'tp_language'        => 'C8 — زبان / گویش',
			'tp_ethnic_group'    => 'C9 — قوم / فرهنگ',
			'tp_ritual'          => 'C10 — آیین / مراسم سنتی',
			'tp_figure'          => 'C12 — شخصیت تاریخی',
			'tp_historical_era'  => 'C13 — دوره / سلسلهٔ تاریخی',
			'tp_designation'     => 'D — تعیین رسمی',
			'tp_visa'            => 'P1 — ویزا و شرایط ورود',
			'tp_currency'        => 'P2 — ارز و روش‌های پرداخت',
			'tp_health_safety'   => 'P4 — سلامت و ایمنی',
			'tp_travel_etiquette'=> 'P5 — فرهنگ سفر و آداب',
			'tp_calendar'        => 'P6 — تقویم و مناسبت‌های رسمی',
			'tp_transport'       => 'P7 — حمل‌ونقل عمومی',
			'tp_route'           => 'P9 — مسیرهای گردشگری',
			'tp_festival'        => 'E1 — جشنواره و رویداد',
			'tp_sports_event'    => 'E3 — رویداد ورزشی',
			'tp_religious_event' => 'E5 — مراسم مذهبی عمومی',
			'tp_seasonal_event'  => 'E6 — رویداد طبیعی و فصلی',
		);
	}

	/**
	 * وضعیت فعلی، برای نمایش در صفحهٔ تنظیمات — بدون تغییر چیزی.
	 *
	 * @return array{plugin_active:bool,total:int,configured:int}
	 */
	public static function status(): array {
		$settings = get_option( self::OPTION_KEY, array() );
		$allowed  = is_array( $settings ) && isset( $settings['allowed-post-types'] ) && is_array( $settings['allowed-post-types'] )
			? $settings['allowed-post-types']
			: array();

		$configured = 0;

		foreach ( array_keys( self::post_types() ) as $slug ) {
			if ( isset( $allowed[ $slug ] ) && filter_var( $allowed[ $slug ], FILTER_VALIDATE_BOOLEAN ) ) {
				++$configured;
			}
		}

		return array(
			'plugin_active' => function_exists( 'jet_reviews' ),
			'total'         => count( self::post_types() ),
			'configured'    => $configured,
		);
	}

	/**
	 * اجرای واقعی: هر ۴۲ نوع‌پست را در گزینهٔ تنظیمات JetReviews مجاز و
	 * پیکربندی می‌کند. نوع‌پستی که هنوز در سایت ثبت نشده رد می‌شود (بی‌خطر).
	 *
	 * @return int تعداد نوع‌پستی که واقعاً تنظیم شد.
	 */
	public static function run( bool $need_approve ): int {

		if ( ! current_user_can( 'manage_options' ) ) {
			return 0;
		}

		$settings = get_option( self::OPTION_KEY, array() );
		if ( ! is_array( $settings ) ) {
			$settings = array();
		}

		$allowed = isset( $settings['allowed-post-types'] ) && is_array( $settings['allowed-post-types'] )
			? $settings['allowed-post-types']
			: array( 'post' => 'true' );

		$updated = 0;

		foreach ( self::post_types() as $slug => $label ) {

			if ( ! post_type_exists( $slug ) ) {
				continue; // JetEngine هنوز این نوع‌پست را ثبت نکرده — بی‌سروصدا رد شو.
			}

			$allowed[ $slug ] = 'true';

			$type_key = $slug . '-type-settings';
			$existing = isset( $settings[ $type_key ] ) && is_array( $settings[ $type_key ] ) ? $settings[ $type_key ] : array();
			$pt       = get_post_type_object( $slug );

			$settings[ $type_key ] = array_merge(
				$existing,
				array(
					'allowed'               => true,
					'name'                  => $pt && $pt->labels ? $pt->labels->name : $label,
					'slug'                  => $slug,
					'review_type'           => $existing['review_type'] ?? 'default',
					'need_approve'          => $need_approve,
					'comments_allowed'      => true,
					'comments_need_approve' => $need_approve,
					'approval_allowed'      => true,
				)
			);

			++$updated;
		}

		$settings['allowed-post-types'] = $allowed;

		update_option( self::OPTION_KEY, $settings );

		return $updated;
	}

	/**
	 * مدیریت‌کنندهٔ فرم — نانس، سطح دسترسی، سپس اجرا و بازگشت با پیام.
	 */
	public function handle_submit(): void {

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'دسترسی مجاز نیست.', 'topersia-user-core' ) );
		}

		check_admin_referer( self::NONCE_ACTION );

		$need_approve = ! empty( $_POST['need_approve'] );
		$count        = self::run( $need_approve );

		$redirect = add_query_arg(
			array(
				'page'                => 'topersia-user-core',
				'tp_jetreviews_setup' => '1',
				'tp_jetreviews_count' => $count,
			),
			admin_url( 'admin.php' )
		);

		wp_safe_redirect( $redirect );
		exit;
	}
}
