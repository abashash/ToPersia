<?php
defined('ABSPATH') || exit;

/**
 * پل فقط-خواندنی به جدول‌های افزونه JetReviews (Crocoblock).
 *
 * این کلاس هیچ داده‌ای در جدول‌های JetReviews نمی‌نویسد و هیچ فرم ثبت/ویرایش
 * نظری ارائه نمی‌دهد؛ ثبت و مدیریت نظر همچنان کاملاً به عهده خود JetReviews
 * است (فرم‌ها، AJAX، REST). کار این کلاس فقط این است: نظرات هر کاربر و
 * پاسخ‌هایی که دیگران به آن‌ها داده‌اند را برای نمایش در پنل ToPersia واکشی کند.
 *
 * اگر JetReviews نصب/فعال نباشد، جدول‌ها وجود نخواهند داشت و available()
 * به‌سادگی false برمی‌گرداند؛ بقیه متدها هم آرایه خالی می‌دهند، نه خطا.
 */
final class ToPersia_Reviews {
    private static ?self $instance = null;

    public static function instance(): self {
        return self::$instance ??= new self();
    }

    private function __construct() {}

    private static function table(string $key): string {
        global $wpdb;
        // پیشوند «jet_» دقیقاً همان چیزی‌ست که خود JetReviews در
        // includes/db/manager.php برای نام‌گذاری جدول‌هایش استفاده می‌کند.
        return $wpdb->prefix . 'jet_' . $key;
    }

    public static function available(): bool {
        static $cached = null;
        if ($cached !== null) return $cached;

        global $wpdb;
        $table = self::table('reviews');
        $found = $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $table));

        return $cached = ($found === $table);
    }

    private static function is_approved($value): bool {
        return ((int) $value) > 0;
    }

    private static function resolve_author_name(int $user_id): string {
        if ($user_id <= 0) return ToPersia_I18n::t('reviews_guest_author', 'کاربر مهمان');
        $user = get_userdata($user_id);
        if (!$user) return ToPersia_I18n::t('reviews_deleted_author', 'کاربر حذف‌شده');
        return $user->display_name ?: $user->user_login;
    }

    /**
     * تمام نظرات کاربر جاری، هرکجای سایت که ثبت شده باشد، به‌همراه
     * پاسخ‌های تأییدشده‌ای که دیگران (نه خودش) به آن نظرات داده‌اند.
     *
     * @return array<int,array<string,mixed>>
     */
    public function my_reviews(int $user_id, int $limit = 100): array {
        if ($user_id <= 0 || !self::available()) return [];

        global $wpdb;
        $reviews_table = self::table('reviews');

        $rows = $wpdb->get_results($wpdb->prepare(
            "SELECT id, post_id, post_type, title, content, rating, approved, date
             FROM {$reviews_table}
             WHERE author = %d
             ORDER BY date DESC
             LIMIT %d",
            $user_id,
            max(1, $limit)
        ), ARRAY_A);

        if (!$rows) return [];

        $review_ids = array_map(static fn(array $row): int => (int) $row['id'], $rows);
        $replies_by_review = $this->replies_for_reviews($review_ids, $user_id);

        $out = [];
        foreach ($rows as $row) {
            $review_id = (int) $row['id'];
            $post_id = (int) $row['post_id'];
            $post_exists = $post_id > 0 && get_post_status($post_id) !== false;

            $out[] = [
                'id'         => $review_id,
                'post_id'    => $post_id,
                'post_title' => $post_exists
                    ? (class_exists('ToPersia_JetEngine') ? ToPersia_JetEngine::display_name($post_id) : (string) get_the_title($post_id))
                    : ToPersia_I18n::t('reviews_deleted_entity', 'موجودیت حذف‌شده'),
                'post_url'   => $post_exists ? (string) get_permalink($post_id) : '',
                'title'      => (string) $row['title'],
                'content'    => (string) $row['content'],
                'rating'     => (float) $row['rating'],
                'approved'   => self::is_approved($row['approved']),
                'date'       => (string) $row['date'],
                'replies'    => $replies_by_review[$review_id] ?? [],
            ];
        }

        return $out;
    }

    /**
     * پاسخ‌های تأییدشده روی مجموعه‌ای از نظرات، به‌جز پاسخ‌هایی که
     * خودِ صاحب نظر داده (که «پاسخ دیگران» محسوب نمی‌شود).
     *
     * @param array<int,int> $review_ids
     * @return array<int,array<int,array<string,mixed>>> کلید = review_id
     */
    private function replies_for_reviews(array $review_ids, int $owner_user_id): array {
        $review_ids = array_values(array_unique(array_filter(array_map('absint', $review_ids))));
        if (!$review_ids || !self::available()) return [];

        global $wpdb;
        $comments_table = self::table('review_comments');
        $placeholders = implode(',', array_fill(0, count($review_ids), '%d'));

        $sql = "SELECT id, review_id, author, content, date, approved
                FROM {$comments_table}
                WHERE review_id IN ({$placeholders})
                ORDER BY date ASC";

        $rows = $wpdb->get_results($wpdb->prepare($sql, $review_ids), ARRAY_A);
        if (!$rows) return [];

        $grouped = [];
        foreach ($rows as $row) {
            if (!self::is_approved($row['approved'])) continue;

            $author_id = (int) $row['author'];
            if ($author_id === $owner_user_id) continue; // پاسخ به نظر خودش، نه از طرف دیگران

            $grouped[(int) $row['review_id']][] = [
                'id'          => (int) $row['id'],
                'author_name' => self::resolve_author_name($author_id),
                'content'     => (string) $row['content'],
                'date'        => (string) $row['date'],
            ];
        }

        return $grouped;
    }

    /**
     * تعداد کل پاسخ‌های دریافتی روی نظرات کاربر — برای نشان کوچک روی تب.
     */
    public function replies_received_count(int $user_id): int {
        $count = 0;
        foreach ($this->my_reviews($user_id) as $review) {
            $count += count($review['replies']);
        }
        return $count;
    }
}
