<?php
defined('ABSPATH') || exit;

final class ToPersia_JetEngine {
    private static ?self $instance = null;

    public static function instance(): self {
        return self::$instance ??= new self();
    }

    private function __construct() {
        add_shortcode('topersia_save_button', [$this, 'save_button_shortcode']);
        add_action('wp_ajax_topersia_save_place', [$this, 'save_place']);
        add_action('wp_ajax_topersia_remove_saved_place', [$this, 'remove_saved_place']);
    }

    public static function display_name(int $post_id): string {
        foreach (['name_fa', 'name_en', 'name_ar', 'name_local'] as $key) {
            $value = trim((string) get_post_meta($post_id, $key, true));
            if ($value !== '') return $value;
        }
        return get_the_title($post_id) ?: ('#' . $post_id);
    }

    public static function summary(int $post_id): string {
        foreach (['short_summary', 'overview_text'] as $key) {
            $value = trim(wp_strip_all_tags((string) get_post_meta($post_id, $key, true)));
            if ($value !== '') return wp_trim_words($value, 22);
        }
        return '';
    }

    public static function image(int $post_id): string {
        $thumb = get_the_post_thumbnail_url($post_id, 'medium');
        if ($thumb) return $thumb;

        $hero = get_post_meta($post_id, 'hero_image', true);
        if (is_numeric($hero)) {
            $url = wp_get_attachment_image_url((int) $hero, 'medium');
            if ($url) return $url;
        }
        return '';
    }

    /**
     * مکان‌های ذخیره‌شدهٔ کاربر — از جدول اختصاصی (نه دیگر از یک آرایهٔ
     * سریال‌شده در user_meta). اولین فراخوانی برای هر کاربر، اگر متای
     * قدیمی هنوز مانده باشد، یک‌بار آن را به جدول منتقل می‌کند.
     *
     * اعتبارسنجی زنده (پست هنوز منتشر است؟ نوع پستش عوض نشده؟) هنوز اینجا
     * انجام می‌شود چون فقط این کلاس معنای «موجودیت معتبر ToPersia» را
     * می‌داند — اما حالا با یک کوئری روی همهٔ آیتم‌ها به‌جای یکی به ازای هر
     * آیتم.
     *
     * @return array<int,array{post_id:int,post_type:string}>
     */
    public function saved_ids(int $user_id): array {
        if (!class_exists('ToPersia_DB')) return [];

        ToPersia_DB::maybe_migrate_saved($user_id);

        $rows = ToPersia_DB::saved_rows($user_id);
        if (!$rows) return [];

        $by_id = [];
        foreach ($rows as $row) {
            if ($row['post_id'] > 0 && $row['post_type'] !== '' && str_starts_with($row['post_type'], 'tp_')) {
                $by_id[$row['post_id']] = $row['post_type'];
            }
        }
        if (!$by_id) return [];

        $published = get_posts([
            'post_type'      => array_unique(array_values($by_id)),
            'post__in'       => array_keys($by_id),
            'post_status'    => 'publish',
            'posts_per_page' => -1,
            'fields'         => 'ids',
            'no_found_rows'  => true,
            'orderby'        => 'post__in',
        ]);

        $clean = [];
        foreach ($published as $post_id) {
            $post_id = (int) $post_id;
            // اگر نوع پست از زمان ذخیره‌شدن عوض شده باشد، دیگر معتبر نیست.
            if (get_post_type($post_id) === $by_id[$post_id]) {
                $clean[] = ['post_id' => $post_id, 'post_type' => $by_id[$post_id]];
            }
        }

        return $clean;
    }

    public function save_button_shortcode($atts): string {
        if (!is_user_logged_in()) return '';

        $atts = shortcode_atts([
            'id'    => get_the_ID(),
            'label' => 'ذخیره در مکان‌های من',
        ], $atts, 'topersia_save_button');

        $post_id = absint($atts['id']);
        $post = get_post($post_id);

        if (!$post || !str_starts_with($post->post_type, 'tp_') || $post->post_status !== 'publish') {
            return '';
        }

        $saved = $this->saved_ids(get_current_user_id());
        $active = false;
        foreach ($saved as $item) {
            if ((int) $item['post_id'] === $post_id) {
                $active = true;
                break;
            }
        }

        return sprintf(
            '<button type="button" class="tp-save-entity%s" data-post-id="%d" data-post-type="%s">%s</button>',
            $active ? ' is-saved' : '',
            $post_id,
            esc_attr($post->post_type),
            esc_html($active ? '✓ ذخیره‌شده' : $atts['label'])
        );
    }

    public function save_place(): void {
        $nonce = sanitize_text_field(wp_unslash($_POST['nonce'] ?? ''));
        if (!is_user_logged_in() || !wp_verify_nonce($nonce, 'topersia_user_core')) {
            wp_send_json_error(['message' => 'درخواست نامعتبر است.'], 403);
        }

        $post_id = absint($_POST['post_id'] ?? 0);
        $type = sanitize_key(wp_unslash($_POST['post_type'] ?? ''));
        $post = get_post($post_id);

        if (!$post || $post->post_status !== 'publish' || $post->post_type !== $type || !str_starts_with($type, 'tp_')) {
            wp_send_json_error(['message' => 'موجودیت معتبر نیست.'], 400);
        }

        $user_id = get_current_user_id();

        if (!class_exists('ToPersia_DB')) {
            wp_send_json_error(['message' => 'خطای داخلی.'], 500);
        }

        ToPersia_DB::maybe_migrate_saved($user_id);
        ToPersia_DB::saved_add($user_id, $post_id, $type);

        wp_send_json_success([
            'message' => 'به مکان‌های ذخیره‌شده اضافه شد.',
            'count'   => ToPersia_DB::saved_count($user_id),
        ]);
    }

    public function remove_saved_place(): void {
        $nonce = sanitize_text_field(wp_unslash($_POST['nonce'] ?? ''));
        if (!is_user_logged_in() || !wp_verify_nonce($nonce, 'topersia_user_core')) {
            wp_send_json_error(['message' => 'درخواست نامعتبر است.'], 403);
        }

        $post_id = absint($_POST['post_id'] ?? 0);
        $user_id = get_current_user_id();

        if (!class_exists('ToPersia_DB')) {
            wp_send_json_error(['message' => 'خطای داخلی.'], 500);
        }

        ToPersia_DB::maybe_migrate_saved($user_id);
        ToPersia_DB::saved_remove($user_id, $post_id);

        wp_send_json_success([
            'message' => 'از مکان‌های ذخیره‌شده حذف شد.',
            'count'   => ToPersia_DB::saved_count($user_id),
        ]);
    }
}
