<?php
defined('ABSPATH') || exit;

/**
 * دارایی‌های فرانت‌اند (CSS/JS) فقط جایی بار می‌شوند که واقعاً لازم‌اند:
 * صفحهٔ حساب کاربری، صفحهٔ ورود، و صفحات تک هر نوع‌پست ToPersia (چون دکمهٔ
 * «ذخیره» می‌تواند آنجا باشد). قبلاً روی هر صفحهٔ سایت بار می‌شد — با
 * ۲۱٬۶۰۰ صفحهٔ برنامه‌ریزی‌شده، این یعنی ~۳۰ کیلوبایت CSS/JS اضافه روی هر
 * بازدید، برای چیزی که اکثر صفحات اصلاً لازمش ندارند.
 */
final class ToPersia_Assets {
    private static ?self $instance = null;

    public static function instance(): self {
        return self::$instance ??= new self();
    }

    private function __construct() {
        add_action('wp_enqueue_scripts', [$this, 'enqueue'], 25);
    }

    /**
     * شورت‌کدهایی که به CSS/JS این افزونه نیاز دارند.
     */
    private const SHORTCODES = ['topersia_login', 'topersia_user_dashboard', 'topersia_save_button'];

    public function enqueue(): void {
        if (!$this->should_load()) {
            return;
        }

        wp_enqueue_style(
            'topersia-user-core',
            TOPERSIA_USER_CORE_URL . 'assets/css/user-core.css',
            [],
            TOPERSIA_USER_CORE_VERSION
        );

        wp_enqueue_script(
            'topersia-user-core',
            TOPERSIA_USER_CORE_URL . 'assets/js/user-core.js',
            [],
            TOPERSIA_USER_CORE_VERSION,
            true
        );

        wp_localize_script('topersia-user-core', 'ToPersiaUserCore', [
            'ajaxUrl'   => admin_url('admin-ajax.php'),
            'nonce'     => wp_create_nonce('topersia_user_core'),
            'accountUrl'=> class_exists('ToPersia_Admin') ? ToPersia_Admin::account_url() : home_url('/'),
            'homeUrl'   => apply_filters('wpml_home_url', home_url('/')),
            'savedLabel' => class_exists('ToPersia_I18n') ? ToPersia_I18n::t('saved_badge') : 'Saved',
            'removeSavedLabel' => class_exists('ToPersia_I18n') ? ToPersia_I18n::t('remove_saved') : 'Remove from saved',
        ]);
    }

    /**
     * تشخیص اینکه آیا صفحهٔ جاری واقعاً به این دارایی‌ها نیاز دارد.
     *
     * چهار راه برای «بله» وجود دارد:
     * ۱) یکی از شورت‌کدهای این افزونه در متن نوشته باشد (روش معمول).
     * ۲) نشانی صفحهٔ جاری همان نشانی تنظیم‌شدهٔ حساب کاربری باشد (برای
     *    مواردی که صفحه‌ساز محتوا را به‌شکلی غیر از شورت‌کد ساده نگه می‌دارد).
     * ۳) صفحه، تکِ یکی از نوع‌پست‌های ToPersia باشد — چون دکمهٔ «ذخیره» با
     *    قالب Listing/Elementor روی این صفحات می‌نشیند و معمولاً داخل
     *    post_content واقعی نیست تا با has_shortcode() دیده شود.
     * ۴) متای المنتور صفحه (اگر با المنتور ساخته شده) به‌صورت متنی حاوی
     *    یکی از نام‌های شورت‌کد باشد — چون ویجت Shortcode/Text المنتور هم
     *    محتوایش را در post_content معمولی ذخیره نمی‌کند.
     *
     * برای هر حالت پیش‌بینی‌نشده، فیلتر `topersia_user_core_load_assets`
     * راه فرار همیشگی است.
     */
    private function should_load(): bool {
        global $post;

        $load = false;

        if ($post instanceof WP_Post) {
            foreach (self::SHORTCODES as $shortcode) {
                if (has_shortcode((string) $post->post_content, $shortcode)) {
                    $load = true;
                    break;
                }
            }

            if (!$load && post_type_exists($post->post_type) && strpos($post->post_type, 'tp_') === 0) {
                $load = true;
            }

            if (!$load && did_action('elementor/loaded')) {
                $elementor_data = get_post_meta($post->ID, '_elementor_data', true);
                if (is_string($elementor_data) && $elementor_data !== '') {
                    foreach (self::SHORTCODES as $shortcode) {
                        if (strpos($elementor_data, $shortcode) !== false) {
                            $load = true;
                            break;
                        }
                    }
                }
            }
        }

        if (!$load && class_exists('ToPersia_Admin')) {
            $account_url = untrailingslashit((string) ToPersia_Admin::account_url());
            $current_url = untrailingslashit(home_url(add_query_arg([], $GLOBALS['wp']->request ?? '')));
            if ($account_url !== '' && $current_url !== '' && $account_url === $current_url) {
                $load = true;
            }
        }

        /**
         * فیلتر فرار برای هر موردی که این تشخیص خودکار نتواند پوشش دهد
         * (مثلاً یک ویجت سایدبار سراسری که دکمهٔ ذخیره را جای دیگری می‌گذارد).
         */
        return (bool) apply_filters('topersia_user_core_load_assets', $load);
    }
}
