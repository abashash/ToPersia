<?php
defined('ABSPATH') || exit;

final class ToPersia_I18n {
    private static ?self $instance = null;

    /** @var array<string,array{fa:string,en:string,ar:string}> */
    private array $strings = [
        'account_menu' => ['fa'=>'منوی حساب کاربری','en'=>'Account menu','ar'=>'قائمة الحساب'],
        'account_sections' => ['fa'=>'بخش‌های حساب','en'=>'Account sections','ar'=>'أقسام الحساب'],
        'back_to_site' => ['fa'=>'بازگشت به سایت','en'=>'Back to site','ar'=>'العودة إلى الموقع'],
        'overview' => ['fa'=>'نمای کلی','en'=>'Overview','ar'=>'نظرة عامة'],
        'profile' => ['fa'=>'پروفایل من','en'=>'My Profile','ar'=>'ملفي الشخصي'],
        'saved' => ['fa'=>'مکان‌های ذخیره‌شده','en'=>'Saved Places','ar'=>'الأماكن المحفوظة'],
        'trips' => ['fa'=>'سفرهای من','en'=>'My Trips','ar'=>'رحلاتي'],
        'reviews' => ['fa'=>'نظرات و امتیازها','en'=>'Reviews & Ratings','ar'=>'التقييمات والمراجعات'],
        'notifications' => ['fa'=>'اعلان‌ها','en'=>'Notifications','ar'=>'الإشعارات'],
        'settings' => ['fa'=>'تنظیمات','en'=>'Settings','ar'=>'الإعدادات'],
        'logout' => ['fa'=>'خروج از حساب','en'=>'Log out','ar'=>'تسجيل الخروج'],
        'welcome' => ['fa'=>'سلام، %s 👋','en'=>'Hello, %s 👋','ar'=>'مرحباً، %s 👋'],
        'welcome_sub' => ['fa'=>'همه‌چیز برای مدیریت سفر شما، بدون شلوغی.','en'=>'Everything you need to manage your travel, without the clutter.','ar'=>'كل ما تحتاجه لإدارة رحلتك، دون تعقيد.'],
        'new_trip' => ['fa'=>'ساخت سفر جدید','en'=>'Create a trip','ar'=>'إنشاء رحلة'],
        'saved_count' => ['fa'=>'مکان‌های ذخیره‌شده','en'=>'Saved places','ar'=>'الأماكن المحفوظة'],
        'trips_count' => ['fa'=>'سفرهای من','en'=>'My trips','ar'=>'رحلاتي'],
        'reviews_count' => ['fa'=>'نظرات ثبت‌شده','en'=>'Reviews','ar'=>'المراجعات'],
        'places_and_experiences' => ['fa'=>'مکان و تجربه','en'=>'Places & experiences','ar'=>'أماكن وتجارب'],
        'planned' => ['fa'=>'برنامه‌ریزی شده','en'=>'Planned','ar'=>'مخططة'],
        'recent_order' => ['fa'=>'سفارش اخیر','en'=>'Recent order','ar'=>'آخر طلب'],
        'your_experiences' => ['fa'=>'تجربه‌های شما','en'=>'Your experiences','ar'=>'تجاربك'],
        'quick_start' => ['fa'=>'شروع سریع','en'=>'Quick start','ar'=>'بدء سريع'],
        'for_traveler' => ['fa'=>'برای مهمان','en'=>'For travelers','ar'=>'للمسافر'],
        'favorites' => ['fa'=>'مکان‌های موردعلاقه','en'=>'Favorite places','ar'=>'الأماكن المفضلة'],
        'plan_trip' => ['fa'=>'برنامه‌ریزی سفر','en'=>'Plan a trip','ar'=>'خطط لرحلة'],
        'write_review' => ['fa'=>'ثبت تجربه','en'=>'Write a review','ar'=>'اكتب مراجعة'],
        'complete_profile' => ['fa'=>'تکمیل پروفایل','en'=>'Complete profile','ar'=>'أكمل ملفك الشخصي'],
        'traveler_info' => ['fa'=>'اطلاعات مهمان','en'=>'Traveler information','ar'=>'معلومات المسافر'],
        'edit' => ['fa'=>'ویرایش','en'=>'Edit','ar'=>'تعديل'],
        'mobile' => ['fa'=>'موبایل','en'=>'Mobile','ar'=>'الهاتف المحمول'],
        'email' => ['fa'=>'ایمیل','en'=>'Email','ar'=>'البريد الإلكتروني'],
        'country' => ['fa'=>'کشور','en'=>'Country','ar'=>'الدولة'],
        'profile_title' => ['fa'=>'پروفایل من','en'=>'My Profile','ar'=>'ملفي الشخصي'],
        'profile_desc' => ['fa'=>'اطلاعاتی که تجربه سفر ToPersia را شخصی‌تر می‌کند.','en'=>'Information that makes your ToPersia travel experience more personal.','ar'=>'معلومات تجعل تجربة سفرك مع ToPersia أكثر تخصيصاً.'],
        'first_name' => ['fa'=>'نام','en'=>'First name','ar'=>'الاسم الأول'],
        'last_name' => ['fa'=>'نام خانوادگی','en'=>'Last name','ar'=>'اسم العائلة'],
        'language' => ['fa'=>'زبان','en'=>'Language','ar'=>'اللغة'],
        'travel_style' => ['fa'=>'سبک سفر','en'=>'Travel style','ar'=>'نمط السفر'],
        'select' => ['fa'=>'انتخاب کنید','en'=>'Select','ar'=>'اختر'],
        'culture' => ['fa'=>'فرهنگی','en'=>'Culture','ar'=>'ثقافي'],
        'nature' => ['fa'=>'طبیعت‌گردی','en'=>'Nature','ar'=>'طبيعة'],
        'food' => ['fa'=>'غذا و تجربه محلی','en'=>'Food & local experiences','ar'=>'الطعام والتجارب المحلية'],
        'luxury' => ['fa'=>'لوکس','en'=>'Luxury','ar'=>'فاخر'],
        'adventure' => ['fa'=>'ماجراجویانه','en'=>'Adventure','ar'=>'مغامرات'],
        'save_changes' => ['fa'=>'ذخیره تغییرات','en'=>'Save changes','ar'=>'حفظ التغييرات'],
        'saved_desc' => ['fa'=>'فقط مواردی که خودتان ذخیره کرده‌اید در اینجا نمایش داده می‌شوند.','en'=>'Only the places you save are shown here.','ar'=>'تظهر هنا فقط الأماكن التي حفظتها.'],
        'saved_badge' => ['fa'=>'ذخیره‌شده','en'=>'Saved','ar'=>'محفوظ'],
        'view' => ['fa'=>'مشاهده','en'=>'View','ar'=>'عرض'],
        'remove_saved' => ['fa'=>'حذف از ذخیره‌ها','en'=>'Remove from saved','ar'=>'إزالة من المحفوظات'],
        'nothing_saved' => ['fa'=>'هنوز چیزی ذخیره نکرده‌اید','en'=>'You have not saved anything yet','ar'=>'لم تحفظ أي شيء بعد'],
        'save_hint' => ['fa'=>'روی دکمه ذخیره در صفحات مقصد بزنید تا موارد موردعلاقه‌تان اینجا جمع شوند.','en'=>'Use the save button on destination pages to collect places you like here.','ar'=>'استخدم زر الحفظ في صفحات الوجهات لجمع الأماكن التي تعجبك هنا.'],
        'trips_title' => ['fa'=>'سفرهای من','en'=>'My Trips','ar'=>'رحلاتي'],
        'trips_desc' => ['fa'=>'اینجا محل سفرهای برنامه‌ریزی‌شده شماست.','en'=>'This is where your planned trips will appear.','ar'=>'هنا ستظهر رحلاتك المخططة.'],
        'reviews_title' => ['fa'=>'نظرات و امتیازها','en'=>'Reviews & Ratings','ar'=>'التقييمات والمراجعات'],
        'reviews_desc' => ['fa'=>'تمام نظراتی که در سراسر ToPersia ثبت کرده‌اید، همراه پاسخ‌هایی که دریافت کرده‌اید.','en'=>'Every review you have posted across ToPersia, along with any replies you received.','ar'=>'جميع مراجعاتك عبر ToPersia، إلى جانب أي ردود تلقيتها.'],
        'reviews_empty' => ['fa'=>'هنوز نظری ثبت نکرده‌اید','en'=>'You have not written any reviews yet','ar'=>'لم تكتب أي مراجعة بعد'],
        'reviews_empty_hint' => ['fa'=>'وقتی از صفحه یک مکان یا تجربه نظری ثبت کنید، همین‌جا نمایش داده می‌شود.','en'=>'Reviews you leave on any place or experience page will appear here.','ar'=>'ستظهر هنا المراجعات التي تتركها في صفحة أي مكان أو تجربة.'],
        'reviews_pending' => ['fa'=>'در انتظار تأیید','en'=>'Awaiting approval','ar'=>'بانتظار الموافقة'],
        'reviews_replies_heading' => ['fa'=>'پاسخ‌ها','en'=>'Replies','ar'=>'الردود'],
        'reviews_no_replies' => ['fa'=>'هنوز کسی پاسخ نداده است.','en'=>'No one has replied yet.','ar'=>'لم يرد أحد بعد.'],
        'reviews_view_entity' => ['fa'=>'مشاهده مورد بازبینی‌شده','en'=>'View reviewed item','ar'=>'عرض العنصر الذي تمت مراجعته'],
        'reviews_new_replies_badge' => ['fa'=>'پاسخ دریافت شده','en'=>'Replies received','ar'=>'تم استلام ردود'],
        'reviews_guest_author' => ['fa'=>'کاربر مهمان','en'=>'Guest user','ar'=>'مستخدم زائر'],
        'reviews_deleted_author' => ['fa'=>'کاربر حذف‌شده','en'=>'Deleted user','ar'=>'مستخدم محذوف'],
        'reviews_deleted_entity' => ['fa'=>'موجودیت حذف‌شده','en'=>'Deleted entity','ar'=>'عنصر محذوف'],
        'notifications_title' => ['fa'=>'اعلان‌ها','en'=>'Notifications','ar'=>'الإشعارات'],
        'notifications_desc' => ['fa'=>'اعلان‌های مرتبط با سفرها و پیشنهادهای شخصی‌سازی‌شده اینجا قرار می‌گیرند.','en'=>'Travel updates and personalized recommendations will appear here.','ar'=>'ستظهر هنا تحديثات السفر والتوصيات الشخصية.'],
        'settings_title' => ['fa'=>'تنظیمات','en'=>'Settings','ar'=>'الإعدادات'],
        'account_language' => ['fa'=>'زبان حساب','en'=>'Account language','ar'=>'لغة الحساب'],
        'language_hint' => ['fa'=>'از بخش پروفایل قابل تغییر است.','en'=>'You can change it from your profile.','ar'=>'يمكنك تغييرها من ملفك الشخصي.'],
        'privacy' => ['fa'=>'حریم خصوصی','en'=>'Privacy','ar'=>'الخصوصية'],
        'privacy_hint' => ['fa'=>'کنترل اطلاعات حساب.','en'=>'Control your account information.','ar'=>'التحكم في معلومات حسابك.'],
        'display_settings_title' => ['fa'=>'شخصی‌سازی نمایش','en'=>'Display Personalization','ar'=>'تخصيص العرض'],
        'display_settings_hint' => ['fa'=>'حالت رنگ، اندازهٔ متن، فاصله و پهنای متن، و راحتی چشم را برای خودتان تنظیم کنید — روی حساب شما ذخیره می‌شود و روی هر دستگاهی که وارد شوید همراهتان می‌آید.','en'=>'Set your color mode, text size, spacing and width, and eye comfort — saved to your account and applied on every device you sign in from.','ar'=>'اضبط وضع الألوان وحجم النص وتباعده وعرضه وراحة العين — يُحفظ في حسابك ويُطبَّق على أي جهاز تسجّل الدخول منه.'],
        'display_mode_label' => ['fa'=>'حالت رنگ','en'=>'Color mode','ar'=>'وضع الألوان'],
        'display_mode_auto' => ['fa'=>'خودکار','en'=>'Auto','ar'=>'تلقائي'],
        'display_mode_light' => ['fa'=>'روز','en'=>'Day','ar'=>'نهار'],
        'display_mode_evening' => ['fa'=>'بعدازظهر','en'=>'Evening','ar'=>'مساء'],
        'display_mode_dark' => ['fa'=>'شب','en'=>'Night','ar'=>'ليل'],
        'display_scale_label' => ['fa'=>'اندازهٔ متن','en'=>'Text size','ar'=>'حجم النص'],
        'display_contrast_label' => ['fa'=>'کنتراست بالا','en'=>'High contrast','ar'=>'تباين عالٍ'],
        'display_spacing_label' => ['fa'=>'فاصلهٔ متن','en'=>'Text spacing','ar'=>'تباعد النص'],
        'display_spacing_compact' => ['fa'=>'فشرده','en'=>'Compact','ar'=>'مضغوط'],
        'display_spacing_normal' => ['fa'=>'استاندارد','en'=>'Standard','ar'=>'قياسي'],
        'display_spacing_loose' => ['fa'=>'باز','en'=>'Loose','ar'=>'واسع'],
        'display_measure_label' => ['fa'=>'پهنای ستون متن','en'=>'Text column width','ar'=>'عرض عمود النص'],
        'display_measure_narrow' => ['fa'=>'باریک','en'=>'Narrow','ar'=>'ضيق'],
        'display_measure_standard' => ['fa'=>'استاندارد','en'=>'Standard','ar'=>'قياسي'],
        'display_comfort_label' => ['fa'=>'راحتی چشم','en'=>'Eye comfort','ar'=>'راحة العين'],
        'display_calm_label' => ['fa'=>'کاهش شدت رنگ و نور','en'=>'Reduce color & glare intensity','ar'=>'تقليل شدة اللون والوهج'],
        'display_motion_label' => ['fa'=>'توقف حرکت و پخش خودکار','en'=>'Stop motion & autoplay','ar'=>'إيقاف الحركة والتشغيل التلقائي'],
        'display_saved_confirmation' => ['fa'=>'ذخیره شد ✓','en'=>'Saved ✓','ar'=>'تم الحفظ ✓'],
        'active' => ['fa'=>'فعال','en'=>'Active','ar'=>'نشط'],
        'success_saved' => ['fa'=>'پروفایل با موفقیت ذخیره شد.','en'=>'Profile saved successfully.','ar'=>'تم حفظ الملف الشخصي بنجاح.'],
        'invalid_request' => ['fa'=>'درخواست نامعتبر است.','en'=>'Invalid request.','ar'=>'طلب غير صالح.'],
    ];

    public static function instance(): self { return self::$instance ??= new self(); }

    private function __construct() {
        add_action('init', [$this, 'register_wpml_strings'], 5);
    }

    public static function current_language(): string {
        $lang = function_exists('apply_filters') ? apply_filters('wpml_current_language', null) : null;
        if (!is_string($lang) || $lang === '') {
            $locale = function_exists('determine_locale') ? determine_locale() : get_locale();
            $lang = str_starts_with($locale, 'ar') ? 'ar' : (str_starts_with($locale, 'en') ? 'en' : 'fa');
        }
        $lang = strtolower(substr($lang, 0, 2));
        return in_array($lang, ['fa','en','ar'], true) ? $lang : 'en';
    }

    public static function direction(): string {
        return in_array(self::current_language(), ['fa','ar'], true) ? 'rtl' : 'ltr';
    }

    public function register_wpml_strings(): void {
        if (!function_exists('do_action')) return;
        foreach ($this->strings as $key => $values) {
            foreach (['fa', 'en', 'ar'] as $lang) {
                if (!isset($values[$lang]) || $values[$lang] === '') continue;
                do_action('wpml_register_single_string', 'ToPersia User Core', $key . '_' . $lang, $values[$lang]);
            }
        }
    }

    /**
     * قبلاً یک اصل واحد (فارسی) به نام یکسان کلید ثبت می‌شد، اما هنگام
     * ترجمه، مقدارِ زبانِ جاری (مثلاً متن انگلیسی) به همان نام فرستاده
     * می‌شد — یعنی اصل ثبت‌شده با اصل ترجمه‌خواسته‌شده یکی نبود و WPML
     * چیزی برای تطبیق پیدا نمی‌کرد؛ خروجی همیشه از آرایهٔ داخلی می‌آمد،
     * نه از ترجمهٔ واقعی در وردپرس.
     *
     * حالا دقیقاً همان الگویی که برای عنوان تب‌ها اثبات شده به کار
     * می‌رود: هر زبان با نام مخصوص به خودش (`key_fa`، `key_en`، `key_ar`)
     * ثبت می‌شود و همان نام برای ترجمه‌خواستن هم استفاده می‌شود.
     */
    public static function t(string $key, ?string $default = null): string {
        $self = self::instance();
        $lang = self::current_language();
        $value = $self->strings[$key][$lang] ?? $default ?? $self->strings[$key]['fa'] ?? $key;

        if (function_exists('apply_filters')) {
            $translated = apply_filters('wpml_translate_single_string', $value, 'ToPersia User Core', $key . '_' . $lang);
            if (is_string($translated) && $translated !== '') {
                return $translated;
            }
        }

        return $value;
    }

    public static function format(string $key, ...$args): string {
        $text = self::t($key);
        return $args ? vsprintf($text, $args) : $text;
    }
}
