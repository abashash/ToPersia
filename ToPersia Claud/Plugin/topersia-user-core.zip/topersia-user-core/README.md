# ToPersia User Core 1.8.1

- Fullscreen frontend user dashboard with site-independent shell.
- Fixed runtime resilience around dashboard rendering.
- Font Awesome 5.15.4 bundled locally; tab icons use Font Awesome classes.
- Icon colors inherit ToPersia design tokens via currentColor.
- Built-in tabs and custom shortcode tabs are supported.
- Admin UI is a standalone WordPress admin menu, not a Settings submenu.
- Persian/Arabic use RTL content; English uses LTR content while dashboard navigation remains on the right.
- Uses ToPersia Render design tokens when present.
