<?php defined('ABSPATH') || exit; ?>
<div class="tp-auth-wrap" dir="rtl">
  <div class="tp-auth-card">
    <div class="tp-brand-large">ToPersia</div>
    <span class="tp-eyebrow">ACCOUNT</span>
    <h2>ورود به حساب کاربری</h2>
    <p class="tp-muted">شماره موبایل خود را وارد کنید.</p>
    <div class="tp-field"><label for="tp-mobile">شماره موبایل</label><input id="tp-mobile" type="tel" inputmode="numeric" autocomplete="tel" placeholder="09123456789"></div>
    <button class="tp-btn" id="tp-send-otp" type="button">دریافت کد ورود</button>
    <div id="tp-otp-box" class="tp-hidden">
      <div class="tp-field"><label for="tp-otp">کد تأیید</label><input id="tp-otp" type="text" inputmode="numeric" maxlength="6" autocomplete="one-time-code" placeholder="••••••"></div>
      <button class="tp-btn" id="tp-verify-otp" type="button">تأیید و ورود</button>
    </div>
    <div id="tp-auth-message" class="tp-message" aria-live="polite"></div>
  </div>
</div>
