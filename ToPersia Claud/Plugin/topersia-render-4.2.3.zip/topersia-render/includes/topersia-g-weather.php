<?php
/**
 * قرارداد آداپتور هوا — واژگان وضعیت.  P5-D196
 *
 * آداپتور فقط دما نمی‌دهد؛ یک وضعیتِ نرمال‌شده هم می‌دهد. لایهٔ نمایش
 * هرگز کد خام ارائه‌دهنده را نمی‌بیند و هیچ‌جا `if ( 95 === $code )`
 * نوشته نمی‌شود.
 *
 * هر ارائه‌دهنده جدول ترجمه‌اش را **داخل خودش** نگه می‌دارد. اگر جدول
 * بیرون می‌آمد، افزودن ارائه‌دهندهٔ دوم یعنی ویرایش یک فایل مشترک و
 * همان‌جاست که واژگان بی‌صدا از هم می‌پاشد.
 *
 * ⚠ نقطهٔ REST و انتخاب سرویس‌دهنده هنوز تصمیم محصول‌اند و اینجا نیستند.
 * این فایل فقط قرارداد و نگاشت است؛ چیزی را واکشی نمی‌کند.
 *
 * @package topersia-render
 */

if ( ! defined( 'ABSPATH' ) && ! defined( 'TP_PLUGIN_DIR' ) ) {
	return;
}

/**
 * نُه وضعیت. هیچ‌چیز دیگری از هیچ ارائه‌دهنده‌ای بیرون نمی‌آید.
 *
 * `dust` عمداً جداست. گردوغبار در ایران وضعیت واقعی و پرتکرار است و اگر
 * زیر `fog` پنهان شود، هم توصیه‌های سفر غلط می‌شوند هم انیمیشن سربرگ
 * چیز اشتباهی نشان می‌دهد.  P5-D196
 *
 * `cold` متقارنِ `hot` است و هیچ انیمیشنی ندارد. `snow` فقط بارش را
 * می‌گیرد، نه سرمای خشک — اردبیل و سبلان و کوهرنگ روزهای بسیاری
 * بی‌بارش و به‌شدت سردند.  P5-D196
 */
if ( ! function_exists( 'topersia_g_wx_states' ) ) {
	function topersia_g_wx_states() {
		return array( 'clear', 'cloudy', 'rain', 'snow', 'storm', 'fog', 'dust', 'hot', 'cold' );
	}
}

/** آیا این رشته یکی از هشت وضعیت است؟ */
if ( ! function_exists( 'topersia_g_wx_is_state' ) ) {
	function topersia_g_wx_is_state( $state ) {
		return in_array( $state, topersia_g_wx_states(), true );
	}
}

/**
 * ارائه‌دهندهٔ Open-Meteo.
 *
 * کد هوا را به شکل WMO می‌دهد، ولی زیرمجموعه‌ای از آن. دو چیز در این
 * زیرمجموعه **نیست** و از جای دیگری می‌آید:
 *
 *   hot   دمایی است، نه کد. از `temperature_2m_max` درمی‌آید.
 *   dust  در کدهای پیش‌بینی Open-Meteo اصلاً وجود ندارد. از نقطهٔ
 *         کیفیت هوا (`dust` بر حسب میکروگرم بر مترمکعب) می‌آید.
 *
 * یعنی این ارائه‌دهنده به‌تنهایی شش وضعیت از هشت را از کد می‌سازد و دو
 * تای دیگر را از سیگنال جدا. این را صریح می‌نویسم چون اگر کسی بعداً
 * دنبال «کد WMO گردوغبار» بگردد، پیدا نمی‌کند و وسوسه می‌شود آن را
 * زیر `fog` بگذارد — دقیقاً همان چیزی که `P5-D196` منع کرده.
 */
if ( ! class_exists( 'TP_Wx_Open_Meteo' ) ) {
	class TP_Wx_Open_Meteo {

		const NAME = 'open-meteo';

		/**
		 * آستانهٔ `hot` بر حسب سلسیوس.
		 *
		 * ۳۸ بود و به ۴۲ رسید: تهران معمولاً از ۳۸ رد می‌شود و وضعیتی که
		 * چهار ماه سال روشن بماند، دیگر وضعیت نیست.
		 *
		 * ⚠ با دادهٔ واقعی ایران اعتبارسنجی نشده.
		 */
		const HOT_C = 42.0;

		/**
		 * آستانهٔ `cold` بر حسب سلسیوس — متقارنِ `hot`.
		 *
		 * ⚠ با دادهٔ واقعی ایران اعتبارسنجی نشده.
		 */
		const COLD_C = -5.0;

		/**
		 * آستانهٔ `dust` بر حسب میکروگرم بر مترمکعب.
		 *
		 * ۵۰ بود و به ۱۵۰ رسید: ۵۰ یک روز غبارآلود معمولی است و ۱۵۰
		 * همان‌جایی است که دید واقعاً می‌افتد.
		 *
		 * ⚠ با دادهٔ واقعی ایران اعتبارسنجی نشده.
		 */
		const DUST_UGM3 = 150.0;

		/*
		 * شبکه و کش — دو فراخوان، دو دانه‌بندی.
		 *
		 * غبار پدیده‌ای منطقه‌ای است نه محلی، پس کیفیت هوا روی شبکهٔ
		 * درشت‌تر و با کش بلندتر خوانده می‌شود. اگر هر دو روی یک شبکه
		 * می‌رفتند، فراخوان دوم حجم را دو برابر می‌کرد و به سقف ده هزار
		 * نزدیک می‌شدیم.
		 */
		const GRID_FORECAST = 0.25;
		const GRID_AIR      = 0.5;
		const TTL_FORECAST  = 10800;   /* سه ساعت */
		const TTL_AIR       = 21600;   /* شش ساعت */

		/**
		 * جدول ترجمه — کد WMO به وضعیت.
		 *
		 * داخل همین کلاس می‌ماند.  P5-D196
		 */
		public static function codes() {

			return array(
				/* صاف و ابری */
				0  => 'clear',
				1  => 'clear',
				2  => 'cloudy',
				3  => 'cloudy',

				/* مه */
				45 => 'fog',
				48 => 'fog',

				/* نم‌نم — باران است، نه چیز دیگر */
				51 => 'rain',
				53 => 'rain',
				55 => 'rain',
				56 => 'rain',
				57 => 'rain',

				/* باران */
				61 => 'rain',
				63 => 'rain',
				65 => 'rain',
				66 => 'rain',
				67 => 'rain',

				/* برف */
				71 => 'snow',
				73 => 'snow',
				75 => 'snow',
				77 => 'snow',

				/* رگبار باران */
				80 => 'rain',
				81 => 'rain',
				82 => 'rain',

				/* رگبار برف */
				85 => 'snow',
				86 => 'snow',

				/* تندر */
				95 => 'storm',
				96 => 'storm',
				99 => 'storm',
			);
		}

		/** کد را به وضعیت می‌برد. هرگز `hot` یا `dust` برنمی‌گرداند. */
		public static function map( $code ) {

			$table = self::codes();
			$code  = (int) $code;

			return isset( $table[ $code ] ) ? $table[ $code ] : 'clear';
		}

		/**
		 * یک ردیف خام را به وضعیت نرمال‌شده می‌برد.
		 *
		 * ترتیب اولویت عمدی است: هوای خطرناک بر هوای ناخوشایند مقدم است،
		 * و گردوغبار بر مه — وگرنه یک روز غبارآلود «مه» گزارش می‌شود.
		 *
		 *   storm · snow · rain   از کد، بی‌چون‌وچرا
		 *   dust                  اگر سیگنال غبار از آستانه گذشت
		 *   fog                   از کد
		 *   hot                   اگر دما از آستانه گذشت
		 *   cloudy · clear        باقی‌مانده
		 *
		 * @param array $row کلیدهای شناخته‌شده: code · temp_c · dust_ugm3
		 * @return string یکی از هشت وضعیت
		 */
		public static function from( $row ) {

			$code  = isset( $row['code'] ) ? (int) $row['code'] : 0;
			$state = self::map( $code );

			if ( in_array( $state, array( 'storm', 'snow', 'rain' ), true ) ) {
				return $state;
			}

			if ( isset( $row['dust_ugm3'] ) && (float) $row['dust_ugm3'] >= self::DUST_UGM3 ) {
				return 'dust';
			}

			if ( 'fog' === $state ) {
				return 'fog';
			}

			if ( isset( $row['temp_c'] ) ) {

				$temp = (float) $row['temp_c'];

				if ( $temp >= self::HOT_C ) {
					return 'hot';
				}
				if ( $temp <= self::COLD_C ) {
					return 'cold';
				}
			}

			return $state;
		}

		/**
		 * یک مختصات را به مرکز سلول شبکه می‌برد.
		 *
		 * دو موجودیت نزدیک به هم یک سلول می‌گیرند و یک فراخوان. همین
		 * است که مصرف را زیر سقف نگه می‌دارد.
		 */
		public static function snap( $value, $grid ) {
			$grid = (float) $grid;
			if ( $grid <= 0 ) { return (float) $value; }
			return round( (float) $value / $grid ) * $grid;
		}

		/** کلید سلول برای یک جفت مختصات. */
		public static function cell( $lat, $lon, $grid ) {
			return sprintf(
				'%.4f,%.4f',
				self::snap( $lat, $grid ),
				self::snap( $lon, $grid )
			);
		}

		/** کلید کش — سلول به‌اضافهٔ نوع فراخوان. */
		public static function cache_key( $kind, $lat, $lon ) {

			$grid = 'air' === $kind ? self::GRID_AIR : self::GRID_FORECAST;

			return 'tp-wx-' . self::NAME . '-' . $kind . '-' . self::cell( $lat, $lon, $grid );
		}

		/** عمر کش بر حسب ثانیه. */
		public static function ttl( $kind ) {
			return 'air' === $kind ? self::TTL_AIR : self::TTL_FORECAST;
		}
	}
}

/**
 * ارائه‌دهندگان ثبت‌شده.
 *
 * فعلاً یکی. وقتی دومی آمد، همین‌جا اضافه می‌شود و ادعای آزمون بدون
 * تغییر جدولش را هم می‌سنجد.
 */
if ( ! function_exists( 'topersia_g_wx_providers' ) ) {
	function topersia_g_wx_providers() {

		$providers = array( 'TP_Wx_Open_Meteo' );

		if ( function_exists( 'apply_filters' ) ) {
			$providers = apply_filters( 'topersia_g_wx_providers', $providers );
		}

		return $providers;
	}
}

/**
 * نقطهٔ REST هوا — `topersia/v1/weather`.  P5-D219
 *
 * کارت «هوای این روزها» تا حالا همیشه در حالت بارگیری می‌ماند چون این
 * نقطه وجود نداشت. حالا دارد.
 *
 * چرا REST و نه HTML سرور: صفحه کش تمام‌صفحه می‌شود، و هوای روزِ ساختِ
 * کش تا روزها روی صفحه می‌ماند.  همان دلیلی که مرجع هم نوشته بود.
 *
 * کش نیم‌ساعته روی سلولِ شبکه است، نه روی مختصات خام: دو موجودیت نزدیک
 * هم یک فراخوان می‌گیرند و مصرف زیر سقف می‌ماند.
 */
if ( ! defined( 'TP_WX_REST_TTL' ) ) {
	define( 'TP_WX_REST_TTL', 1800 );   /* نیم ساعت */
}

if ( ! function_exists( 'topersia_g_wx_rest' ) ) {

	/** کد WMO به آیکون کارت. آیکون‌ها همان‌های مرجع‌اند. */
	function topersia_g_wx_icon( $state ) {

		$map = array(
			'clear'  => 'sun',
			'cloudy' => 'part',
			'fog'    => 'part',
			'rain'   => 'rain',
			'storm'  => 'rain',
			'snow'   => 'snow',
			'dust'   => 'wind',
			'hot'    => 'sun',
			'cold'   => 'snow',
		);

		return isset( $map[ $state ] ) ? $map[ $state ] : 'sun';
	}

	/** برچسب فارسی وضعیت — از واژه‌نامهٔ خود پروژه، نه رشتهٔ تازه. */
	function topersia_g_wx_label( $state ) {

		$map = array(
			'clear'  => 'آفتابی',
			'cloudy' => 'کمی ابری',
			'fog'    => 'مه',
			'rain'   => 'بارانی',
			'storm'  => 'رعدوبرق',
			'snow'   => 'برفی',
			'dust'   => 'گردوغبار',
			'hot'    => 'گرم',
			'cold'   => 'سرد',
		);

		return isset( $map[ $state ] ) ? $map[ $state ] : 'آفتابی';
	}

	function topersia_g_wx_rest( $request ) {

		$coords = (string) $request->get_param( 'coords' );
		$parts  = array_map( 'trim', explode( ',', $coords ) );

		if ( count( $parts ) < 2 || ! is_numeric( $parts[0] ) || ! is_numeric( $parts[1] ) ) {
			return new WP_Error( 'tp_wx_coords', 'مختصات نامعتبر است.', array( 'status' => 400 ) );
		}

		$lat = (float) $parts[0];
		$lon = (float) $parts[1];

		$key    = TP_Wx_Open_Meteo::cache_key( 'card', $lat, $lon );
		$cached = get_transient( $key );

		if ( false !== $cached ) {
			return rest_ensure_response( $cached );
		}

		$cell = explode( ',', TP_Wx_Open_Meteo::cell( $lat, $lon, TP_Wx_Open_Meteo::GRID_FORECAST ) );

		$url = add_query_arg(
			array(
				'latitude'   => $cell[0],
				'longitude'  => $cell[1],
				'daily'      => 'weather_code,temperature_2m_max,temperature_2m_min',
				'timezone'   => 'auto',
				'forecast_days' => 3,
			),
			'https://api.open-meteo.com/v1/forecast'
		);

		$response = wp_remote_get( $url, array( 'timeout' => 6 ) );

		if ( is_wp_error( $response ) || 200 !== (int) wp_remote_retrieve_response_code( $response ) ) {
			return new WP_Error( 'tp_wx_upstream', 'سرویس هوا در دسترس نیست.', array( 'status' => 503 ) );
		}

		$body = json_decode( wp_remote_retrieve_body( $response ), true );

		if ( ! isset( $body['daily']['time'] ) || ! is_array( $body['daily']['time'] ) ) {
			return new WP_Error( 'tp_wx_shape', 'پاسخ سرویس هوا شکل مورد انتظار را ندارد.', array( 'status' => 502 ) );
		}

		$names = array( 'امروز', 'فردا', 'پس‌فردا' );
		$days  = array();

		foreach ( $body['daily']['time'] as $n => $ignored ) {

			if ( $n > 2 ) {
				break;
			}

			$high  = isset( $body['daily']['temperature_2m_max'][ $n ] ) ? (float) $body['daily']['temperature_2m_max'][ $n ] : 0.0;
			$state = TP_Wx_Open_Meteo::from( array(
				'code'   => isset( $body['daily']['weather_code'][ $n ] ) ? (int) $body['daily']['weather_code'][ $n ] : 0,
				'temp_c' => $high,
			) );

			$days[] = array(
				'd' => isset( $names[ $n ] ) ? $names[ $n ] : '',
				't' => (int) round( $high ),
				'n' => (int) round( isset( $body['daily']['temperature_2m_min'][ $n ] ) ? (float) $body['daily']['temperature_2m_min'][ $n ] : 0.0 ),
				'i' => topersia_g_wx_icon( $state ),
				's' => topersia_g_wx_label( $state ),
			);
		}

		$out = array( 'days' => $days, 'note' => 'به‌روزرسانی: چند دقیقه پیش' );

		set_transient( $key, $out, TP_WX_REST_TTL );

		return rest_ensure_response( $out );
	}
}

if ( function_exists( 'add_action' ) ) {

	add_action( 'rest_api_init', function () {

		register_rest_route( 'topersia/v1', '/weather', array(
			'methods'             => 'GET',
			'callback'            => 'topersia_g_wx_rest',
			'permission_callback' => '__return_true',
			'args'                => array(
				'coords' => array( 'required' => true, 'type' => 'string' ),
			),
		) );
	} );
}
