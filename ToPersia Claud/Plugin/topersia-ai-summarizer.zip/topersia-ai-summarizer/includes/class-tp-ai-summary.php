<?php
/**
 * Handles AJAX generation, caching and rate-limiting for the AI panel.
 *
 * @package TP_AI_Summarizer
 */

defined( 'ABSPATH' ) || exit;

/**
 * Nonce-protected bridge between the JS panel and TP_AI_API.
 */
class TP_AI_Summary {

	/**
	 * Register hooks.
	 */
	public static function init() {
		add_action( 'wp_ajax_tpas_ai_generate', array( __CLASS__, 'handle_ajax' ) );
		// wp_ajax_nopriv_tpas_ai_generate intentionally NOT registered: AI
		// generation is authenticated-only (logged-in ToPersia users). See
		// handle_ajax()'s explicit is_user_logged_in() check below, which
		// stays even though the nopriv hook is gone - defense in depth if
		// something else ever calls this method directly.
		add_action( 'save_post', array( __CLASS__, 'mark_stale' ), 20, 1 );
	}

	/**
	 * Invalidate stored summaries whenever the post is edited.
	 *
	 * @param int $post_id Post id.
	 * @return void
	 */
	public static function mark_stale( $post_id ) {
		if ( ! $post_id || wp_is_post_revision( $post_id ) || wp_is_post_autosave( $post_id ) ) {
			return;
		}

		TP_AI_DB::delete_post_summaries( $post_id );

		global $wpdb;

		$wpdb->query(
			$wpdb->prepare(
				"DELETE FROM {$wpdb->postmeta} WHERE post_id = %d AND meta_key LIKE %s",
				$post_id,
				$wpdb->esc_like( '_tpas_ai_' ) . '%'
			)
		);
	}

	/**
	 * Whether the internal engine should be used for generation.
	 *
	 * @return bool
	 */
	public static function engine_is_internal() {
		if ( ! TP_AI_Options::just_flag( 'internal_enabled' ) ) {
			return false;
		}

		$mode = (string) TP_AI_Options::get_field( 'internal_engine', 'auto' );

		if ( 'internal' === $mode ) {
			return true;
		}

		if ( TP_AI_API::is_configured() ) {
			return false;
		}

		return in_array( $mode, array( 'auto', 'ai' ), true );
	}

	/**
	 * Process a generate or regenerate request from the front-end.
	 */
	public static function handle_ajax() {
		if ( ! is_user_logged_in() ) {
			// No details beyond a generic rejection - do not reveal whether
			// the nonce/post/etc. would otherwise have been valid.
			wp_send_json_error( array( 'message' => 'Authentication required.' ), 401 );
		}

		check_ajax_referer( 'tpas_ai', 'nonce' );

		$lang = self::sanitize_lang( wp_unslash( $_POST['lang'] ?? '' ) );
		$type = self::sanitize_type( wp_unslash( $_POST['type'] ?? '' ) );
		$post = absint( $_POST['post'] ?? 0 );
		$url  = esc_url_raw( wp_unslash( $_POST['url'] ?? '' ) );

		if ( ! $post && ! $url ) {
			wp_send_json_error( array( 'message' => 'Missing post or URL.' ) );
		}

		if ( $post && ! self::content_type_allowed( $post ) ) {
			wp_send_json_error( array( 'message' => 'AI is not available for this content type.' ) );
		}

		$user_id = get_current_user_id();

		if ( self::rate_limited( $user_id, self::client_ip(), $type ) ) {
			wp_send_json_error( array( 'message' => 'Rate limit. Please wait a minute.' ) );
		}

		// Serve the existing cache if still valid.
		$cached = self::get_cached( $post, $type, $lang );

		if ( $cached ) {
			wp_send_json_success( array(
				'text'     => $cached['text'],
				'html'     => TP_AI_Render::format_ai_text( $cached['text'] ),
				'cached'   => true,
				'provider' => $cached['provider'] ?? '',
				'model'    => $cached['model'] ?? '',
			) );
		}

		// Internal engine path: deterministic, no rate limit, no API call.
		if ( self::engine_is_internal() ) {
			$text = self::internal_text( $post, $type, $lang );

			if ( '' === trim( $text ) ) {
				wp_send_json_error( array( 'message' => 'Not enough content to summarize.' ) );
			}

			wp_send_json_success( array(
				'text'     => $text,
				'html'     => TP_AI_Render::format_ai_text( $text ),
				'cached'   => true,
				'provider' => '',
				'model'    => '',
				'engine'   => 'internal',
			) );
		}

		if ( ! TP_AI_API::is_configured() ) {
			wp_send_json_error( array( 'message' => 'No internal engine configured.' ) );
		}

		// Build the prompt the user actually requested.
		$url_key   = $url ? $url : TP_AI_Render::current_url( $post );
		$title     = TP_AI_Render::current_title( $post );
		$base      = TP_AI_Prompt_Manager::get( $lang, $type );
		$user_msg  = TP_AI_Render::build_prompt( $base, $url_key, $title, $post, $lang );

		// Attach the page context.
		$context   = self::page_context( $post, $url_key );
		$user_full = $user_msg . "\n\n" . $context;

		$system    = TP_AI_Localize::context_system( $lang );

		$result = TP_AI_API::chat( $system, $user_full );

		if ( ! $result['ok'] ) {
			wp_send_json_error( array( 'message' => $result['message'] ) );
		}

		$text  = $result['data'];
		$label = $result['provider'] ?? '';

		self::store( $post, $type, $lang, $text, $label, $result['model'] ?? '' );

		wp_send_json_success( array(
			'text'     => $text,
			'html'     => TP_AI_Render::format_ai_text( $text ),
			'cached'   => false,
			'provider' => $label,
			'model'    => $result['model'] ?? '',
		) );
	}

	// -----------------------------------------------------------------
	// Caching helpers
	// -----------------------------------------------------------------

	/**
	 * Return the cached summary for a post/type/lang, or null if missing/expired.
	 *
	 * @param int    $post_id Post id.
	 * @param string $type    Output type.
	 * @param string $lang    Language code.
	 * @return array|null
	 */
	public static function get_cached( $post_id, $type, $lang ) {
		if ( ! $post_id ) {
			return null;
		}

		// Persisted archive row first.
		$row = TP_AI_DB::get_summary( $post_id, $type, $lang );

		if ( $row && '' !== trim( (string) $row->content ) ) {
			return array(
				'text'     => (string) $row->content,
				'provider' => (string) $row->provider,
				'model'    => (string) $row->model,
				'created'  => strtotime( (string) $row->updated_at ),
			);
		}

		// Legacy post-meta cache (pre-1.1 installs).
		$key   = '_tpas_ai_' . $type . '_' . $lang;
		$cache = get_post_meta( $post_id, $key, true );

		if ( ! is_array( $cache ) || empty( $cache['text'] ) ) {
			return null;
		}

		$hours = absint( TP_AI_Options::get_field( 'internal_cache_hours', 168 ) );

		if ( $hours && isset( $cache['created'] ) && ( time() - (int) $cache['created'] ) > $hours * 3600 ) {
			delete_post_meta( $post_id, $key );

			return null;
		}

		return $cache;
	}

	/**
	 * Generate (or reuse) text for a post without any API call. Safe to run
	 * during page render — fast and fully deterministic.
	 *
	 * @param int    $post_id Post id.
	 * @param string $type    Output type.
	 * @param string $lang    Language code.
	 * @return string
	 */
	public static function internal_text( $post_id, $type, $lang ) {
		if ( ! $post_id ) {
			return '';
		}

		$cached = self::get_cached( $post_id, $type, $lang );

		if ( $cached ) {
			return (string) $cached['text'];
		}

		$engine   = new TP_AI_Internal();
		$context  = TP_AI_Context::build( $post_id );
		$text     = $engine->generate( $type, $context );

		if ( '' !== trim( $text ) ) {
			self::store( $post_id, $type, $lang, $text, '', '', 'internal' );
		}

		return $text;
	}

	/**
	 * Write a generated summary into the DB archive and post meta.
	 *
	 * @param int    $post_id Post id.
	 * @param string $type    Output type.
	 * @param string $lang    Language code.
	 * @param string $text    Content.
	 * @param string $provider Provider label.
	 * @param string $model    Model label.
	 * @param string $source   'ai' or 'internal'.
	 */
	private static function store( $post_id, $type, $lang, $text, $provider, $model, $source = 'ai' ) {
		if ( ! $post_id ) {
			return;
		}

		if ( $post_id ) {
			TP_AI_DB::save_summary( $post_id, $type, $lang, $text, $provider, $model, $source );
		}

		$key = '_tpas_ai_' . $type . '_' . $lang;

		update_post_meta( $post_id, $key, array(
			'text'     => $text,
			'provider' => $provider,
			'model'    => $model,
			'created'  => time(),
		) );
	}

	// -----------------------------------------------------------------
	// Rate-limiting
	// -----------------------------------------------------------------

	/**
	 * Per-user (primary) + per-IP (secondary) transient throttle. Since AI
	 * generation is authenticated-only, the primary key is the WordPress
	 * user ID rather than IP - this avoids unfairly throttling every user
	 * behind a shared office/NAT IP together, while the IP check remains
	 * as a defense-in-depth layer against one compromised/scripted account
	 * hammering the endpoint from many requests per minute.
	 *
	 * @param int    $user_id Logged-in user ID.
	 * @param string $ip      Client IP (secondary layer).
	 * @param string $type    Requested feature type ("summary", "plan", ...).
	 * @return bool True when the request should be blocked.
	 */
	private static function rate_limited( $user_id, $ip, $type ) {
		$limit = absint( TP_AI_Options::get_field( 'internal_throttle', 10 ) );

		if ( $limit <= 0 ) {
			return false;
		}

		if ( $user_id && self::bump_counter( 'tpas_rt_u_' . $user_id . '_' . $type, $limit ) ) {
			return true;
		}

		// Secondary, more permissive IP layer (catches many accounts from
		// one abusive source without being the primary fairness mechanism).
		if ( $ip && self::bump_counter( 'tpas_rt_ip_' . md5( $ip ), $limit * 5 ) ) {
			return true;
		}

		return false;
	}

	/**
	 * Increments an hourly transient counter and reports whether it has
	 * reached the given limit.
	 *
	 * @param string $key   Transient key.
	 * @param int    $limit Max allowed count within the window.
	 * @return bool True once the limit is reached (request blocked).
	 */
	private static function bump_counter( $key, $limit ) {
		$current = get_transient( $key );

		if ( false === $current ) {
			set_transient( $key, 1, HOUR_IN_SECONDS );
			return false;
		}

		if ( (int) $current >= $limit ) {
			return true;
		}

		set_transient( $key, (int) $current + 1, HOUR_IN_SECONDS );

		return false;
	}

	// -----------------------------------------------------------------
	// Helpers
	// -----------------------------------------------------------------

	/**
	 * Plain-text excerpt from the current or requested page.
	 *
	 * @param int    $post_id Post id.
	 * @param string $url     Page URL (fallback).
	 * @return string
	 */
	private static function page_context( $post_id, $url ) {
		$chars = absint( TP_AI_Options::get_field( 'internal_context_chars', 40000 ) );

		/**
		 * Filter the maximum context characters fed to the model.
		 *
		 * @param int    $chars    Max chars.
		 * @param int    $post_id  Post id.
		 * @param string $url      Page URL.
		 */
		$chars = apply_filters( 'tpas_context_chars', $chars, $post_id, $url );

		$text = '';

		if ( $post_id ) {
			$post  = get_post( $post_id );
			if ( $post ) {
				$text = $post->post_title . "\n\n" . wp_strip_all_tags( $post->post_content );
			}

			// Append structured data (JetEngine facts + related items).
			$structured = TP_AI_Context::structured_block( TP_AI_Context::build( $post_id ) );

			if ( '' !== $structured ) {
				$text .= "\n\n" . $structured;
			}
		}

		$text = preg_replace( '/[\t ]+/', ' ', $text );
		$text = trim( $text );

		if ( $chars > 0 && function_exists( 'mb_strlen' ) && mb_strlen( $text, 'UTF-8' ) > $chars ) {
			$text = mb_substr( $text, 0, $chars, 'UTF-8' ) . '…';
		}

		/**
		 * Filter the context text fed to the model.
		 *
		 * @param string $text     Context string.
		 * @param int    $post_id  Post id.
		 * @param string $url      Page URL.
		 */
		return apply_filters( 'tpas_context', $text, $post_id, $url );
	}

	/**
	 * Normalise the language code against the registered set.
	 *
	 * @param string $lang Raw language code.
	 * @return string Sanitised code.
	 */
	private static function sanitize_lang( $lang ) {
		$lang  = preg_replace( '/[^a-z0-9_-]/i', '', strtolower( $lang ) );
		$langs = TP_AI_Localize::languages();

		return in_array( $lang, $langs, true ) ? $lang : TP_AI_Localize::sanitize( get_locale() );
	}

	/**
	 * Whether AI is enabled for a given post's type, per the admin's
	 * "post_types" setting. The frontend already avoids rendering the
	 * panel for disallowed types, but the AJAX endpoint re-checks this
	 * server-side since a logged-in user could otherwise POST an arbitrary
	 * post ID directly.
	 *
	 * @param int $post_id Post id.
	 * @return bool
	 */
	private static function content_type_allowed( $post_id ) {
		$post_type = get_post_type( $post_id );

		if ( ! $post_type ) {
			return false;
		}

		$allowed = array_map( 'sanitize_key', (array) TP_AI_Options::get_field( 'post_types', array() ) );

		return in_array( $post_type, $allowed, true );
	}

	/**
	 * Constrain the output type to the allowed list.
	 *
	 * @param string $type Raw output type.
	 * @return string Sanitised type.
	 */
	private static function sanitize_type( $type ) {
		$slug  = preg_replace( '/[^a-z_]/i', '', strtolower( $type ) );
		$valid = TP_AI_Options::panel_types();

		return in_array( $slug, $valid, true ) ? $slug : 'summary';
	}

	/**
	 * Best-effort IP extraction for rate-limiting.
	 *
	 * @return string
	 */
	private static function client_ip() {
		$checks = array(
			'HTTP_X_FORWARDED_FOR',
			'HTTP_X_REAL_IP',
			'HTTP_CF_CONNECTING_IP',
			'REMOTE_ADDR',
		);

		foreach ( $checks as $header ) {
			if ( empty( $_SERVER[ $header ] ) ) {
				continue;
			}

			$raw = explode( ',', wp_unslash( $_SERVER[ $header ] ) );
			$ip  = trim( $raw[0] );

			if ( filter_var( $ip, FILTER_VALIDATE_IP ) ) {
				return $ip;
			}
		}

		return '';
	}
}