<?php

/*
 * Copyright 2014 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
namespace VendorDuplicator\Google\Service\Drive;

class GeneratedIds extends \VendorDuplicator\Google\Collection
{
    protected $collection_key = 'ids';
    /**
     * @var string[]
     */
    public $ids;
    /**
     * @var string
     */
    public $kind;
    /**
     * @var string
     */
    public $space;
    /**
     * @param string[]
     */
    public function setIds($ids)
    {
        $this->ids = $ids;
    }
    /**
     * @return string[]
     */
    public function getIds()
    {
        return $this->ids;
    }
    /**
     * @param string
     */
    public function setKind($kind)
    {
        $this->kind = $kind;
    }
    /**
     * @return string
     */
    public function getKind()
    {
        return $this->kind;
    }
    /**
     * @param string
     */
    public function setSpace($space)
    {
        $this->space = $space;
    }
    /**
     * @return string
     */
    public function getSpace()
    {
        return $this->space;
    }
}
// Adding a class alias for backwards compatibility with the previous class name.
class_alias(GeneratedIds::class, 'VendorDuplicator\Google_Service_Drive_GeneratedIds');
